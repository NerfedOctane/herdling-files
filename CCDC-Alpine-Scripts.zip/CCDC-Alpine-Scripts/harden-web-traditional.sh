#!/bin/sh
# --- Alpine guard (POSIX sh until the second "fi") -----------------------------
# This is the Alpine Linux version. It needs bash: if this was started with
# BusyBox sh (ash), bash is installed with apk when missing and the script
# re-runs itself under it.
if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi
if [ -z "${BASH_VERSION:-}" ]; then
    if ! command -v bash >/dev/null 2>&1; then
        echo "[*] bash is not installed; installing it with apk..." >&2
        apk add --no-cache bash >/dev/null 2>&1 || {
            echo "[!] Could not install bash (no repository access?). Install it first: apk add bash" >&2
            exit 1
        }
    fi
    exec bash "$0" "$@"
fi
# --------------------------------------------------------------------------------
# ============================================================
# harden-web-traditional.sh
# CCDC Web Hardening Script — Traditional Services
# Alpine Linux version (apache2 / nginx / tomcat / caddy under OpenRC)
#
#   Apache: /etc/apache2/httpd.conf + /etc/apache2/conf.d/*.conf, binary httpd,
#           service apache2, web root /var/www/localhost/htdocs
#   Nginx:  /etc/nginx/nginx.conf + /etc/nginx/http.d/*.conf, web root /var/lib/nginx/html
#   Every config change is tested (httpd -t / nginx -t) before a restart and
#   rolled back automatically if the test fails.
# ============================================================
#
# FUNCTIONS:
#   detect_os           — Checks for Alpine and sets the Alpine config paths
#   print_banner        — Prints script banner
#   print_result        — Prints [OK] or [SKIP] status for each action
#   harden_apache       — Hardens Apache if installed
#     - Disables ServerSignature
#     - Sets ServerTokens Prod
#     - Disables unnecessary modules (autoindex, status, cgi, userdir)
#     - Removes default welcome page
#     - Restricts .htaccess overrides
#     - Adds security headers
#     - Disables TRACE method
#     - Disables directory listing
#   harden_nginx        — Hardens Nginx if installed
#     - Sets server_tokens off
#     - Removes default site
#     - Adds rate limiting
#     - Restricts allowed HTTP methods
#     - Disables autoindex
#     - Adds security headers
#   harden_tomcat       — Hardens Tomcat if installed
#     - Removes default webapps (manager, host-manager, examples, docs, ROOT)
#     - Changes SHUTDOWN string to random value
#     - Disables AJP connector
#     - Removes server version from error pages
#     - Restricts manager to localhost
#   harden_caddy        — Hardens Caddy if installed
#     - Adds security headers
#     - Disables file browsing
#   set_file_permissions — Sets restrictive permissions on webroot and config files
#   restart_services     — Restarts only services that were modified
#   print_summary        — Prints a summary of all changes made
#
# ============================================================

set -euo pipefail

# ---------- Tracking ----------
CHANGES=()

# ---------- Output helpers ----------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

print_banner() {
    echo -e "${CYAN}"
    echo "============================================"
    echo "  CCDC Web Hardening — Traditional Services"
    echo "============================================"
    echo -e "${NC}"
}

print_result() {
    local status="$1"
    local msg="$2"
    if [[ "$status" == "ok" ]]; then
        echo -e "  ${GREEN}[OK]${NC}    $msg"
    elif [[ "$status" == "skip" ]]; then
        echo -e "  ${YELLOW}[SKIP]${NC}  $msg"
    elif [[ "$status" == "fail" ]]; then
        echo -e "  ${RED}[FAIL]${NC}  $msg"
    fi
}

# ---------- OS Detection ----------
detect_os() {
    echo -e "${CYAN}[*] Detecting OS...${NC}"
    if [[ ! -f /etc/alpine-release && ${SKIP_ALPINE_CHECK:-0} != 1 ]]; then
        echo -e "${RED}[!] Not Alpine Linux - use the original script${NC}"
        exit 1
    fi
    OS_FAMILY="alpine"
    PKG_MGR="apk"
    APACHE_SERVICE="apache2"
    APACHE_CONF="/etc/apache2/httpd.conf"
    APACHE_CONF_DIR="/etc/apache2/conf.d"
    APACHE_MODULES_DIR="/etc/apache2/conf.d"
    NGINX_CONF="/etc/nginx/nginx.conf"
    NGINX_CONF_DIR="/etc/nginx/http.d"
    [[ -d $NGINX_CONF_DIR ]] || NGINX_CONF_DIR="/etc/nginx/conf.d"
    NGINX_DEFAULT="$NGINX_CONF_DIR/default.conf"
    BACKUP_DIR="/root/web-hardening-backup-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    echo -e "  OS: ${GREEN}Alpine Linux $(cat /etc/alpine-release 2>/dev/null)${NC}"
    echo -e "  Package manager: ${GREEN}$PKG_MGR${NC}"
    echo -e "  Backups: ${GREEN}$BACKUP_DIR${NC}"
}

# backup_dir_once DIR: copy a config tree into $BACKUP_DIR before the first change
backup_dir_once() {
    local d=$1
    [[ -e $d ]] || return 0
    [[ -e "$BACKUP_DIR$d" ]] && return 0
    mkdir -p "$BACKUP_DIR$(dirname "$d")"
    cp -a "$d" "$BACKUP_DIR$d"
}

# restore_dir DIR: put a backed-up config tree back
restore_dir() {
    local d=$1
    [[ -e "$BACKUP_DIR$d" ]] || return 1
    rm -rf "$d"
    cp -a "$BACKUP_DIR$d" "$d"
}

# ---------- File Permissions ----------
set_file_permissions() {
    echo -e "\n${CYAN}[*] Setting restrictive file permissions...${NC}"

    # Apache
    if [[ -d /etc/apache2 ]]; then
        chmod 750 /etc/apache2
        chmod 640 "$APACHE_CONF" 2>/dev/null || true
        print_result "ok" "Set /etc/apache2 permissions to 750, config to 640"
        CHANGES+=("Set Apache config permissions")
    fi

    # Nginx
    if [[ -f "$NGINX_CONF" ]]; then
        chmod 640 "$NGINX_CONF"
        print_result "ok" "Set nginx.conf permissions to 640"
        CHANGES+=("Set Nginx config permissions")
    fi

    # Web roots
    for webroot in /var/www/localhost/htdocs /var/lib/nginx/html /usr/share/nginx/html /var/www; do
        if [[ -d "$webroot" ]]; then
            chmod -R 755 "$webroot"
            print_result "ok" "Set $webroot permissions to 755"
            CHANGES+=("Set $webroot permissions")
        fi
    done
}

# ---------- Apache Hardening ----------
harden_apache() {
    echo -e "\n${CYAN}[*] Checking for Apache...${NC}"

    if ! command -v httpd &>/dev/null && ! command -v apache2 &>/dev/null; then
        print_result "skip" "Apache not installed"
        return
    fi

    echo -e "  ${GREEN}Apache found — hardening...${NC}"
    backup_dir_once /etc/apache2

    # Disable ServerSignature and set ServerTokens
    if [[ -f "$APACHE_CONF" ]]; then
        # ServerSignature Off
        if grep -qi "^ServerSignature" "$APACHE_CONF"; then
            sed -i 's/^ServerSignature.*/ServerSignature Off/' "$APACHE_CONF"
        else
            echo "ServerSignature Off" >> "$APACHE_CONF"
        fi
        print_result "ok" "ServerSignature Off"
        CHANGES+=("Apache: ServerSignature Off")

        # ServerTokens Prod
        if grep -qi "^ServerTokens" "$APACHE_CONF"; then
            sed -i 's/^ServerTokens.*/ServerTokens Prod/' "$APACHE_CONF"
        else
            echo "ServerTokens Prod" >> "$APACHE_CONF"
        fi
        print_result "ok" "ServerTokens Prod"
        CHANGES+=("Apache: ServerTokens Prod")

        # Disable TRACE method
        if ! grep -qi "TraceEnable" "$APACHE_CONF"; then
            echo "TraceEnable Off" >> "$APACHE_CONF"
        else
            sed -i 's/^TraceEnable.*/TraceEnable Off/' "$APACHE_CONF"
        fi
        print_result "ok" "TRACE method disabled"
        CHANGES+=("Apache: TRACE disabled")

        # Disable directory listing
        if grep -q "Options Indexes" "$APACHE_CONF"; then
            sed -i '/Options Indexes/s/.*/Options -Indexes/' "$APACHE_CONF"
        fi
        print_result "ok" "Directory listing disabled"
        CHANGES+=("Apache: Directory listing disabled")

        # Restrict .htaccess
        if grep -q "AllowOverride All" "$APACHE_CONF"; then
            sed -i 's/AllowOverride All/AllowOverride None/' "$APACHE_CONF"
        fi
        print_result "ok" ".htaccess overrides restricted"
        CHANGES+=("Apache: .htaccess restricted")
    fi

    # Security headers config
    HEADERS_CONF="$APACHE_CONF_DIR/security-headers.conf"
    cat > "$HEADERS_CONF" << 'HEADEREOF'
<IfModule mod_headers.c>
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Content-Security-Policy "default-src 'self';"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always unset X-Powered-By
</IfModule>
HEADEREOF
    print_result "ok" "Security headers added to $HEADERS_CONF"
    CHANGES+=("Apache: Security headers added")

    # Enable headers module (Alpine: LoadModule lines live in httpd.conf)
    if grep -qE '^[[:space:]]*#[[:space:]]*LoadModule[[:space:]]+headers_module' "$APACHE_CONF"; then
        sed -i -E 's/^[[:space:]]*#[[:space:]]*(LoadModule[[:space:]]+headers_module)/\1/' "$APACHE_CONF"
        print_result "ok" "Enabled mod_headers"
        CHANGES+=("Apache: Enabled mod_headers")
    fi

    # Disable unnecessary modules: comment out their LoadModule lines
    for mod in autoindex_module status_module cgi_module cgid_module userdir_module; do
        for conf_file in "$APACHE_CONF" "$APACHE_MODULES_DIR"/*.conf; do
            if [[ -f "$conf_file" ]] && grep -qE "^[[:space:]]*LoadModule[[:space:]]+$mod[[:space:]]" "$conf_file"; then
                sed -i -E "s/^([[:space:]]*)(LoadModule[[:space:]]+$mod[[:space:]])/\1#\2/" "$conf_file"
                print_result "ok" "Disabled module: $mod ($(basename "$conf_file"))"
                CHANGES+=("Apache: Disabled module $mod")
            fi
        done
    done

    # Remove the stock "It works!" page (only if it is still the untouched default)
    local idx=/var/www/localhost/htdocs/index.html
    if [[ -f $idx ]] && [[ $(wc -c < "$idx") -lt 200 ]] && grep -q "It works!" "$idx" 2>/dev/null; then
        mkdir -p "$BACKUP_DIR/var/www/localhost/htdocs"
        cp -a "$idx" "$BACKUP_DIR$idx"
        rm -f "$idx"
        print_result "ok" "Removed default index page"
        CHANGES+=("Apache: Removed default index")
    fi

    # Test the config now; a module whose directives are still used breaks Apache
    if httpd -t >/dev/null 2>"$BACKUP_DIR/httpd-t.err"; then
        print_result "ok" "httpd -t: Syntax OK"
    else
        print_result "fail" "httpd -t failed after hardening - restoring /etc/apache2:"
        sed 's/^/          /' "$BACKUP_DIR/httpd-t.err" | head -n 8
        restore_dir /etc/apache2 && print_result "ok" "Apache config restored from $BACKUP_DIR"
        CHANGES+=("Apache: changes ROLLED BACK (httpd -t failed)")
        return
    fi

    RESTART_APACHE=true
}

# ---------- Nginx Hardening ----------
harden_nginx() {
    echo -e "\n${CYAN}[*] Checking for Nginx...${NC}"

    if ! command -v nginx &>/dev/null; then
        print_result "skip" "Nginx not installed"
        return
    fi

    echo -e "  ${GREEN}Nginx found — hardening...${NC}"
    backup_dir_once /etc/nginx

    if [[ -f "$NGINX_CONF" ]]; then
        # server_tokens off
        if grep -q "server_tokens" "$NGINX_CONF"; then
            sed -i 's/.*server_tokens.*/    server_tokens off;/' "$NGINX_CONF"
        else
            # (BusyBox sed has no one-line "a\ text"; insert with awk)
            awk '{print} /^[[:space:]]*http[[:space:]]*\{/ && !done {print "    server_tokens off;"; done=1}' "$NGINX_CONF" > "$NGINX_CONF.tmp" \
                && cat "$NGINX_CONF.tmp" > "$NGINX_CONF" && rm -f "$NGINX_CONF.tmp"
        fi
        print_result "ok" "server_tokens off"
        CHANGES+=("Nginx: server_tokens off")

        # Disable autoindex globally
        if grep -q "autoindex on" "$NGINX_CONF"; then
            sed -i 's/autoindex on/autoindex off/g' "$NGINX_CONF"
        fi
        print_result "ok" "autoindex disabled"
        CHANGES+=("Nginx: autoindex off")
    fi

    # Default site: on Alpine, http.d/default.conf is a catch-all that returns 404
    # (that is the safe behaviour), and teams often put the real site in it.
    # So it is reported, never removed.
    if [[ -f "$NGINX_DEFAULT" ]]; then
        if grep -q "return 404" "$NGINX_DEFAULT" && ! grep -qE '^[[:space:]]*(root|proxy_pass|fastcgi_pass)[[:space:]]' "$NGINX_DEFAULT"; then
            print_result "skip" "Default site is Alpine's 404 catch-all - kept (it hides other vhosts from IP scans)"
        else
            print_result "skip" "$NGINX_DEFAULT serves content (probably the real site) - not removed"
        fi
    fi

    # Security headers and rate limiting config
    cat > "$NGINX_CONF_DIR/security-hardening.conf" << 'NGXEOF'
# Rate limiting
limit_req_zone $binary_remote_addr zone=general:10m rate=10r/s;

server {
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Content-Security-Policy "default-src 'self';" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Restrict HTTP methods
    if ($request_method !~ ^(GET|HEAD|POST)$) {
        return 405;
    }
}
NGXEOF
    if nginx -t >/dev/null 2>"$BACKUP_DIR/nginx-t.err"; then
        print_result "ok" "Security headers and rate limiting added"
        CHANGES+=("Nginx: Security headers added")
        CHANGES+=("Nginx: Rate limiting added")
        CHANGES+=("Nginx: HTTP methods restricted to GET/HEAD/POST")
    else
        print_result "fail" "nginx -t failed after hardening - restoring /etc/nginx:"
        sed 's/^/          /' "$BACKUP_DIR/nginx-t.err" | head -n 8
        restore_dir /etc/nginx && print_result "ok" "Nginx config restored from $BACKUP_DIR"
        CHANGES+=("Nginx: changes ROLLED BACK (nginx -t failed)")
        return
    fi

    RESTART_NGINX=true
}

# ---------- Tomcat Hardening ----------
harden_tomcat() {
    echo -e "\n${CYAN}[*] Checking for Tomcat...${NC}"

    # Find Tomcat installation
    TOMCAT_HOME=""
    for path in /opt/tomcat /usr/share/tomcat /usr/share/tomcat* /var/lib/tomcat* /opt/tomcat* /usr/local/tomcat; do
        if [[ -d "$path" && -f "$path/conf/server.xml" ]]; then
            TOMCAT_HOME="$path"
            break
        fi
    done

    if [[ -z "$TOMCAT_HOME" ]]; then
        print_result "skip" "Tomcat not installed"
        return
    fi

    echo -e "  ${GREEN}Tomcat found at $TOMCAT_HOME — hardening...${NC}"

    # Remove default webapps
    for app in manager host-manager examples docs ROOT; do
        if [[ -d "$TOMCAT_HOME/webapps/$app" ]]; then
            rm -rf "$TOMCAT_HOME/webapps/$app"
            print_result "ok" "Removed webapp: $app"
            CHANGES+=("Tomcat: Removed $app")
        else
            print_result "skip" "Webapp $app not present"
        fi
    done

    SERVER_XML="$TOMCAT_HOME/conf/server.xml"

    if [[ -f "$SERVER_XML" ]]; then
        # Change SHUTDOWN string
        RANDOM_SHUTDOWN=$( { head -c 512 /dev/urandom | tr -dc A-Za-z0-9 | head -c 16; } || true)
        sed -i "s/shutdown=\"SHUTDOWN\"/shutdown=\"$RANDOM_SHUTDOWN\"/" "$SERVER_XML"
        print_result "ok" "SHUTDOWN string changed to random value"
        CHANGES+=("Tomcat: SHUTDOWN string randomized")

        # Disable AJP connector
        if grep -q '<!-- *<Connector.*protocol="AJP' "$SERVER_XML"; then
            print_result "skip" "AJP connector already commented out"
        elif grep -q '<Connector.*protocol="AJP' "$SERVER_XML"; then
            sed -i 's|<Connector\(.*protocol="AJP\)|<!-- <Connector\1|' "$SERVER_XML"
            sed -i 's|\(protocol="AJP[^/]*\)/>\(.*\)|\1/> -->\2|' "$SERVER_XML"
            print_result "ok" "AJP connector disabled"
            CHANGES+=("Tomcat: AJP disabled")
        else
            print_result "skip" "No AJP connector found"
        fi

        # Remove server version from error pages
        if ! grep -q "showServerInfo" "$SERVER_XML"; then
            sed -i 's|<Host |<Host errorReportValveClass="org.apache.catalina.valves.ErrorReportValve" showServerInfo="false" showReport="false" |' "$SERVER_XML"
            print_result "ok" "Server version hidden from error pages"
            CHANGES+=("Tomcat: Version hidden from errors")
        fi
    fi

    # Restrict manager to localhost if context.xml exists
    CONTEXT_XML="$TOMCAT_HOME/conf/context.xml"
    if [[ -f "$CONTEXT_XML" ]]; then
        if ! grep -q "RemoteAddrValve" "$CONTEXT_XML"; then
            # (BusyBox sed has no one-line "i\ text"; insert with awk)
            awk '/<\/Context>/ && !done {print "    <Valve className=\"org.apache.catalina.valves.RemoteAddrValve\" allow=\"127\\.\\d+\\.\\d+\\.\\d+|::1\" />"; done=1} {print}' \
                "$CONTEXT_XML" > "$CONTEXT_XML.tmp" && cat "$CONTEXT_XML.tmp" > "$CONTEXT_XML" && rm -f "$CONTEXT_XML.tmp"
            print_result "ok" "Manager restricted to localhost"
            CHANGES+=("Tomcat: Manager localhost only")
        fi
    fi

    RESTART_TOMCAT=true
}

# ---------- Caddy Hardening ----------
harden_caddy() {
    echo -e "\n${CYAN}[*] Checking for Caddy...${NC}"

    if ! command -v caddy &>/dev/null; then
        print_result "skip" "Caddy not installed"
        return
    fi

    echo -e "  ${GREEN}Caddy found — hardening...${NC}"

    CADDY_CONF=""
    for path in /etc/caddy/Caddyfile /etc/caddy/caddy.conf; do
        if [[ -f "$path" ]]; then
            CADDY_CONF="$path"
            break
        fi
    done

    if [[ -z "$CADDY_CONF" ]]; then
        print_result "fail" "Caddy config not found"
        return
    fi

    mkdir -p "$BACKUP_DIR$(dirname "$CADDY_CONF")"; cp -a "$CADDY_CONF" "$BACKUP_DIR$CADDY_CONF"
    # Add security headers if not present
    if ! grep -q "X-Frame-Options" "$CADDY_CONF"; then
        cat >> "$CADDY_CONF" << 'CADDYEOF'

# Security headers
(security_headers) {
    header {
        X-Frame-Options "SAMEORIGIN"
        X-Content-Type-Options "nosniff"
        X-XSS-Protection "1; mode=block"
        Content-Security-Policy "default-src 'self';"
        Referrer-Policy "strict-origin-when-cross-origin"
        -Server
    }
}
CADDYEOF
        print_result "ok" "Security headers added"
        CHANGES+=("Caddy: Security headers added")
    fi

    # Disable file browsing
    if grep -q "file_server browse" "$CADDY_CONF"; then
        sed -i 's/file_server browse/file_server/' "$CADDY_CONF"
        print_result "ok" "File browsing disabled"
        CHANGES+=("Caddy: File browsing disabled")
    else
        print_result "skip" "File browsing already disabled or not set"
    fi

    RESTART_CADDY=true
}

# ---------- Restart Services ----------
svc_restart() {
    local svc=$1
    [[ -x /etc/init.d/$svc ]] || return 2
    rc-service "$svc" restart >/dev/null 2>&1
}

restart_services() {
    echo -e "\n${CYAN}[*] Restarting modified services...${NC}"

    if [[ "${RESTART_APACHE:-false}" == true ]]; then
        if httpd -t >/dev/null 2>&1 && svc_restart "$APACHE_SERVICE"; then
            print_result "ok" "Restarted $APACHE_SERVICE"
        else
            print_result "fail" "Failed to restart $APACHE_SERVICE — check: httpd -t ; tail /var/log/apache2/error.log"
        fi
    fi

    if [[ "${RESTART_NGINX:-false}" == true ]]; then
        if nginx -t &>/dev/null && svc_restart nginx; then
            print_result "ok" "Restarted nginx"
        else
            print_result "fail" "Failed to restart nginx — check config with: nginx -t"
        fi
    fi

    if [[ "${RESTART_TOMCAT:-false}" == true ]]; then
        TOMCAT_SVC=""
        for f in /etc/init.d/tomcat*; do
            [[ -x $f ]] && { TOMCAT_SVC=$(basename "$f"); break; }
        done
        if [[ -n "$TOMCAT_SVC" ]]; then
            if svc_restart "$TOMCAT_SVC"; then
                print_result "ok" "Restarted $TOMCAT_SVC"
            else
                print_result "fail" "Failed to restart $TOMCAT_SVC"
            fi
        else
            print_result "skip" "No Tomcat OpenRC service found — restart manually"
        fi
    fi

    if [[ "${RESTART_CADDY:-false}" == true ]]; then
        if caddy validate --config "$CADDY_CONF" --adapter caddyfile &>/dev/null || ! caddy help validate &>/dev/null; then
            if svc_restart caddy; then
                print_result "ok" "Restarted caddy"
            else
                print_result "fail" "Failed to restart caddy"
            fi
        else
            print_result "fail" "caddy validate failed — restoring $CADDY_CONF"
            cp -a "$BACKUP_DIR$CADDY_CONF" "$CADDY_CONF"
        fi
    fi
}

# ---------- Summary ----------
print_summary() {
    echo -e "\n${CYAN}============================================${NC}"
    echo -e "${CYAN}  HARDENING SUMMARY${NC}"
    echo -e "${CYAN}============================================${NC}"
    if [[ ${#CHANGES[@]} -eq 0 ]]; then
        echo -e "  ${YELLOW}No changes were made.${NC}"
    else
        echo -e "  ${GREEN}${#CHANGES[@]} changes applied:${NC}\n"
        for change in "${CHANGES[@]}"; do
            echo -e "    • $change"
        done
    fi
    echo -e "  Backups of every config touched: $BACKUP_DIR"
    echo -e "\n${CYAN}============================================${NC}"
}

# ---------- Main ----------
main() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}[!] This script must be run as root (use su or doas).${NC}"
        exit 1
    fi

    print_banner
    detect_os
    set_file_permissions
    harden_apache
    harden_nginx
    harden_tomcat
    harden_caddy
    restart_services
    print_summary
}

main "$@"
