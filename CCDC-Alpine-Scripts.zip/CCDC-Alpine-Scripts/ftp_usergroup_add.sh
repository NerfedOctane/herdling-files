#!/bin/sh
# ======================================================
# FTP USER GROUP CREATION SCRIPT - Alpine Linux version
# (POSIX sh / BusyBox ash, no bash needed)
# ------------------------------------------------------
# Description:
#   This script creates a dedicated 'ftp_users' group
#   and adds users (from a provided list file) to it.
#   Uses BusyBox addgroup (no shadow package needed).
#
# Requirements:
#   - Must be run with root privileges
#   - Takes one argument: the path to the user list file
#
# Usage:
#   ./ftp_usergroup_add.sh userlist.txt
# ======================================================

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

# Ensure an argument is provided
if [ -z "${1:-}" ]; then
    echo "ERROR: No user list file provided."
    echo "Usage: $0 <userlist.txt>"
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: run as root (use su or doas)." >&2
    exit 1
fi

filepath=$(readlink -f "$1")
[ -f "$filepath" ] || { echo "ERROR: user list not found: $1" >&2; exit 1; }

echo "CREATING FTP USERS GROUP (ftp_users)"
if getent group ftp_users >/dev/null 2>&1; then
    echo "Group 'ftp_users' already exists."
else
    addgroup ftp_users
fi
printf 'COMPLETE\n\n'

echo "ADDING USERS FROM '$filepath' TO ftp_users GROUP"
while IFS= read -r user || [ -n "$user" ]; do
    user=$(printf '%s' "$user" | tr -d ' \t\r')
    [ -z "$user" ] && continue
    if id "$user" >/dev/null 2>&1; then
        # BusyBox: "addgroup USER GROUP" adds an existing user to an existing group
        if id -nG "$user" | tr ' ' '\n' | grep -qx ftp_users; then
            echo "  Already a member: $user"
        elif addgroup "$user" ftp_users; then
            echo "  Added user: $user"
        else
            echo "  ERROR: could not add $user" >&2
        fi
    else
        echo "  WARNING: User '$user' does not exist on this system."
    fi
done < "$filepath"
printf 'COMPLETE\n\n'

# if for some reason you cannot list files as an authenticated user, uncomment the next three lines
#echo "ADDING FTP USER TO FTP_USERS GROUP"
#addgroup ftp ftp_users
#echo "COMPLETE"

echo "VERIFYING USERS IN ftp_users GROUP"
getent group ftp_users
printf 'COMPLETE\n\n'
