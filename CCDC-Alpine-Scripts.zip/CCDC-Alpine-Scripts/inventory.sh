#!/bin/sh
# inventory.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
# Quick service enumeration. Output is shown and saved to /root/services_<host>_<time>.txt

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

OUTPUT="/root/services_$(hostname)_$(date +%Y%m%d_%H%M).txt"

report() {
echo "================================================================="
echo "  CCDC Quick Service Enumeration - $(date)"
echo "  $(cat /etc/alpine-release 2>/dev/null | sed 's/^/Alpine Linux /')"
echo "================================================================="

printf '\n[1] HOSTNAME\n'
echo "-----------------------------------------------------------------"
hostname

printf '\n[2] IP ADDRESS\n'
echo "-----------------------------------------------------------------"
ip -4 addr 2>/dev/null | grep inet | grep -v '127.0.0.1' | awk '{print $2}' | cut -d/ -f1

printf '\n[3] SERVICES, PORTS & VERSIONS\n'
echo "-----------------------------------------------------------------"

if command -v nmap >/dev/null 2>&1; then
    echo "[*] Running nmap version scan on localhost..."
    nmap -sV -p- --open localhost 2>/dev/null | grep -E "^[0-9]+/|PORT" | awk '
    BEGIN { printf "%-10s %-15s %-20s %-40s\n", "PORT", "STATE", "SERVICE", "VERSION";
            print "-----------------------------------------------------------------" }
    /^PORT/ { next }
    /^[0-9]/ {
        port=$1;
        state=$2;
        service=$3;
        version="";
        for(i=4; i<=NF; i++) version=version" "$i;
        printf "%-10s %-15s %-20s %-40s\n", port, state, service, version
    }'
else
    echo "[!] nmap not installed - using fallback (no version detection)"
    echo "[!] Install with: apk add nmap"
    echo ""
    printf '%-10s %-20s %-30s\n' "PROTO" "PORT" "PROCESS"
    echo "-----------------------------------------------------------------"
    if command -v ss >/dev/null 2>&1; then
        # iproute2-ss: users:(("sshd",pid=123,fd=3))
        ss -tulpn 2>/dev/null | awk 'NR>1' | while read -r line; do
            proto=$(echo "$line" | awk '{print $1}')
            port=$(echo "$line" | awk '{print $5}' | awk -F: '{print $NF}')
            pid=$(echo "$line" | grep -oE 'pid=[0-9]+' | head -n1 | cut -d= -f2)
            [ -n "$pid" ] || continue
            proc=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null | awk '{print $1}')
            printf '%-10s %-20s %-30s\n' "$proto" "$port" "$(basename "${proc:-Unknown}")"
        done
    else
        # BusyBox netstat: tcp 0 0 0.0.0.0:22 0.0.0.0:* LISTEN 1234/sshd
        netstat -tulpn 2>/dev/null | awk '$1 ~ /^(tcp|udp)/' | while read -r line; do
            proto=$(echo "$line" | awk '{print $1}')
            port=$(echo "$line" | awk '{print $4}' | awk -F: '{print $NF}')
            pp=$(echo "$line" | awk '{print $NF}')
            pid=${pp%%/*}
            case "$pid" in ''|*[!0-9]*) continue ;; esac
            proc=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null | awk '{print $1}')
            printf '%-10s %-20s %-30s\n' "$proto" "$port" "$(basename "${proc:-Unknown}")"
        done
    fi
fi

printf '\n[4] CCDC TARGET SERVICES STATUS (OpenRC)\n'
echo "-----------------------------------------------------------------"
TARGETS="sshd dovecot postfix exim nginx apache2 lighttpd mariadb mysql postgresql named unbound dnsmasq vsftpd proftpd samba snmpd nfs openvpn telnetd caddy gitea courier-imap slapd sssd docker containerd php-fpm7 php-fpm8 php-fpm81 php-fpm82 php-fpm83 php-fpm84 redis haproxy squid fail2ban crond auditd rsyslog syslog iptables ip6tables nftables chronyd"
for svc in $TARGETS; do
    [ -x "/etc/init.d/$svc" ] || continue
    status=$(rc-service "$svc" status 2>/dev/null | sed -n 's/.*status: *//p' | head -n1)
    levels=$(rc-update show -v 2>/dev/null | awk -v s="$svc" '$1==s {for(i=3;i<=NF;i++) printf "%s ", $i}')
    case "$status" in
        started) echo "[+] $svc - RUNNING   (runlevels: ${levels:-none})" ;;
        *)       echo "[ ] $svc - ${status:-stopped}   (runlevels: ${levels:-none})" ;;
    esac
done
echo ""
echo "All OpenRC services and their state:"
rc-status --servicelist 2>/dev/null || rc-status -a 2>/dev/null

printf '\n[5] ADMIN USERS\n'
echo "-----------------------------------------------------------------"
grep -E '^(sudo|wheel|admin):' /etc/group
if [ -f /etc/doas.conf ] || [ -d /etc/doas.d ]; then
    echo "doas rules:"
    grep -hvE '^[[:space:]]*(#|$)' /etc/doas.conf /etc/doas.d/*.conf 2>/dev/null | sed 's/^/    /'
fi
if [ -f /etc/sudoers ]; then
    echo "sudoers rules:"
    grep -hvE '^[[:space:]]*(#|$|Defaults)' /etc/sudoers /etc/sudoers.d/* 2>/dev/null | sed 's/^/    /'
fi
echo "UID 0 accounts:"
awk -F: '$3==0 {print "    " $1}' /etc/passwd

printf '\n[6] FIREWALL STATUS\n'
echo "-----------------------------------------------------------------"
if command -v awall >/dev/null 2>&1; then
    echo "awall policies:"; awall list 2>/dev/null | head -20
fi
if command -v nft >/dev/null 2>&1 && nft list ruleset 2>/dev/null | grep -q .; then
    nft list ruleset 2>/dev/null | head -40
elif command -v iptables >/dev/null 2>&1; then
    iptables -L -n 2>/dev/null | head -20
else
    echo "No firewall tools installed (apk add iptables, or nftables)"
fi

printf '\n=================================================================\n'
echo "  Report saved: $OUTPUT"
echo "================================================================="
}

report 2>&1 | tee -a "$OUTPUT"
