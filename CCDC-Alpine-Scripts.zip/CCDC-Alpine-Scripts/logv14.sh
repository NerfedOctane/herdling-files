#!/bin/sh
#
#  logv14.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
#  Sets up auditd (with a competition rule set), rsyslog (or tunes BusyBox
#  syslogd if rsyslog can't be installed), process accounting, and the
#  `syshealth` query helper. Packages come from apk; services are OpenRC.
#
#  NOTE: The first batch of audit events after running this script will be
#  noise from the setup itself (writing to /etc/audit/, /etc/rsyslog.d/, etc).
#  This is expected and can be ignored.
#
#  Alpine differences worth knowing:
#   * Most commands are BusyBox applets (symlinks to /bin/busybox). An audit
#     "-w <applet> -p x" watch can't tell them apart, so those watches are
#     commented out at install time; the execve rules still log every command.
#   * Without PAM's pam_loginuid (stock Alpine sshd has no PAM), the audit
#     login UID (auid) is never set. The "human user" rules then match on uid
#     instead, and root's commands get their own rule (key exec-root).
# ============================================================================

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

# --- Colors for output ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# --- Helper functions ---
log_info()    { printf "${GREEN}[+]${NC} %s\n" "$1"; }
log_warn()    { printf "${YELLOW}[!]${NC} %s\n" "$1"; }
log_error()   { printf "${RED}[-]${NC} %s\n" "$1"; }
log_section() { printf "\n${CYAN}=== %s ===${NC}\n" "$1"; }

# --- Root check ---
if [ "$(id -u)" -ne 0 ]; then
    log_error "This script must be run as root (or with doas/sudo)."
    exit 1
fi

install_pkg() {
    apk add --no-cache "$@" >/dev/null 2>&1
}

svc_enable_start() {
    _svc="$1"; _lvl="${2:-default}"
    [ -x "/etc/init.d/$_svc" ] || { log_warn "No OpenRC service '$_svc'"; return 1; }
    rc-update add "$_svc" "$_lvl" >/dev/null 2>&1 || true
    rc-service "$_svc" restart >/dev/null 2>&1 || rc-service "$_svc" start >/dev/null 2>&1
}

svc_started() { rc-service "$1" status 2>/dev/null | grep -q 'status: started'; }

# ============================================================================
# MAIN EXECUTION
# ============================================================================

log_section "Linux Logging Setup (Alpine $(cat /etc/alpine-release 2>/dev/null))"
log_info "Starting at $(date)"

# --- Check for previous run ---
if [ -f /etc/audit/rules.d/99-ccdc.rules ] || grep -q "Competition Configuration" /etc/audit/auditd.conf 2>/dev/null; then
    log_warn "This script appears to have already run."
    log_warn "Re-running will overwrite current config. Previous backups preserved."
fi

BACKUP_DIR="/root/logging_backup_$(date +%Y%m%d%H%M%S)"
mkdir -p "$BACKUP_DIR"
log_info "Backup directory: $BACKUP_DIR"

# ============================================================================
# STEP 1: Install required packages
# ============================================================================
log_section "Installing Packages"

if ! command -v auditctl >/dev/null 2>&1; then
    log_info "Installing audit..."
    install_pkg audit audit-openrc || install_pkg audit || log_error "Could not install audit (apk add audit). Audit steps will fail."
else
    log_info "auditd already installed."
fi

if ! command -v lastcomm >/dev/null 2>&1; then
    log_info "Installing process accounting (acct)..."
    install_pkg acct || log_warn "Could not install process accounting."
else
    log_info "Process accounting already installed."
fi

if ! command -v rsyslogd >/dev/null 2>&1; then
    log_info "Installing rsyslog..."
    install_pkg rsyslog rsyslog-openrc || install_pkg rsyslog || log_warn "Could not install rsyslog. Will tune BusyBox syslogd instead."
else
    log_info "rsyslog already installed."
fi

# Kernel support: /proc/self/loginuid only exists when the kernel has audit syscall support
if [ ! -e /proc/self/loginuid ]; then
    log_warn "This kernel doesn't expose /proc/self/loginuid - it may be built without audit support."
    log_warn "auditd will be configured anyway; check 'auditctl -s' at the end."
fi

# Is the audit login UID (auid) actually tracked for logins on this box?
AUID_TRACKED=1
if [ "$(cat /proc/self/loginuid 2>/dev/null)" = "4294967295" ] && ! grep -rqs 'pam_loginuid' /etc/pam.d 2>/dev/null; then
    AUID_TRACKED=0
    log_warn "Login UID (auid) is not set for logins here (no pam_loginuid). Human-user rules will match on uid instead."
fi

# ============================================================================
# STEP 2: Configure auditd.conf
# ============================================================================
log_section "Configuring auditd.conf"

mkdir -p /etc/audit /var/log/audit
AUDITD_CONF="/etc/audit/auditd.conf"
[ -f "$AUDITD_CONF" ] && cp -p "$AUDITD_CONF" "$BACKUP_DIR/"

# NOTE: log_format=ENRICHED requires auditd >=2.8 (every supported Alpine release has 3.x or 4.x).
cat > "$AUDITD_CONF" << 'AUDITD_CONF_EOF'
#
# auditd.conf - Competition Configuration
#

local_events = yes
log_file = /var/log/audit/audit.log
log_format = ENRICHED
log_group = root
priority_boost = 4
flush = INCREMENTAL_ASYNC
freq = 50
num_logs = 10
max_log_file = 50
max_log_file_action = ROTATE
space_left = 75
space_left_action = SYSLOG
admin_space_left = 50
admin_space_left_action = SYSLOG
disk_full_action = SYSLOG
disk_error_action = SYSLOG

# DO NOT halt the system on audit failure during competition.
# Losing logs is bad. Losing the box is worse.
overflow_action = SYSLOG

name_format = HOSTNAME
AUDITD_CONF_EOF

log_info "auditd.conf written."

# ============================================================================
# STEP 3: Deploy Audit Rules
# ============================================================================
log_section "Deploying Audit Rules"

# Always use rules.d so augenrules (which rebuilds audit.rules from rules.d) keeps them
RULES_DIR="/etc/audit/rules.d"
mkdir -p "$RULES_DIR"
for f in "$RULES_DIR"/*.rules /etc/audit/audit.rules; do
    [ -f "$f" ] && cp -p "$f" "$BACKUP_DIR/" 2>/dev/null
done
RULES_FILE="$RULES_DIR/99-ccdc.rules"

log_info "Writing rules to: $RULES_FILE"

cat > "$RULES_FILE" << 'AUDIT_RULES_EOF'
# ============================================================================
# Audit Rules - Competition Configuration
# ============================================================================
# Organized: Exclusions first (first-match-wins), then watches by priority.
# All rules tagged with -k keys for searching via ausearch -k <key>.
# ============================================================================

# Clear existing rules
-D

# Buffer: large enough for competition load
-b 8192

# Backlog wait: max time (ms) kernel blocks when backlog is full.
# 60000 = 60s. Prevents indefinite hangs under heavy load.
--backlog_wait_time 60000

# Failure mode: 1 = printk (log and continue). NEVER use 2 (panic) in competition.
-f 1

# Rate limit: 0 = unlimited. We want everything.
-r 0

# Ignore errors from paths that don't exist on this system
-i

# ============================================================================
# NOISE REDUCTION (first-match-wins, so exclusions go first)
# ============================================================================

-a always,exclude -F msgtype=EOE
-a always,exclude -F msgtype=AVC
-a always,exclude -F msgtype=CRYPTO_KEY_USER

# (Alpine: no cron-daemon exclusion. crond is a BusyBox applet, so its exe is
#  /bin/busybox and excluding it would hide every BusyBox command.)

# ============================================================================
# SELF-AUDITING - Protect the audit trail
# T1070.002 - Clear Linux Logs / T1562.001 - Impair Defenses
# ============================================================================

-w /var/log/audit/ -p wra -k audit-log-tamper
-w /etc/audit/ -p wa -k audit-config-tamper
-w /etc/libaudit.conf -p wa -k audit-config-tamper
-w /etc/audisp/ -p wa -k audit-config-tamper

-w /sbin/auditctl -p x -k audit-tools
-w /sbin/auditd -p x -k audit-tools
-w /usr/sbin/auditctl -p x -k audit-tools
-w /usr/sbin/auditd -p x -k audit-tools
-w /usr/sbin/augenrules -p x -k audit-tools
-w /usr/sbin/ausearch -p x -k audit-tools
-w /usr/sbin/aureport -p x -k audit-tools

# Log files
-w /var/log/syslog -p wa -k log-tamper
-w /var/log/messages -p wa -k log-tamper
-w /var/log/auth.log -p wa -k log-tamper
-w /var/log/secure -p wa -k log-tamper
-w /var/log/kern.log -p wa -k log-tamper
-w /var/log/wtmp -p wa -k log-tamper
-w /var/log/btmp -p wa -k log-tamper
-w /var/run/utmp -p wa -k log-tamper
-w /var/log/lastlog -p wa -k log-tamper
-w /var/log/faillog -p wa -k log-tamper
-w /var/log/tallylog -p wa -k log-tamper

# Syslog config
-w /etc/rsyslog.conf -p wa -k syslog-config
-w /etc/rsyslog.d/ -p wa -k syslog-config
-w /etc/conf.d/syslog -p wa -k syslog-config
-w /etc/syslog-ng/ -p wa -k syslog-config
-w /etc/syslog.conf -p wa -k syslog-config

# ============================================================================
# AUTHENTICATION & CREDENTIAL ACCESS
# T1078 - Valid Accounts / T1110 - Brute Force / T1003 - Credential Dumping
# ============================================================================

-w /etc/passwd -p wa -k identity-modify
-w /etc/shadow -p wa -k identity-modify
-w /etc/group -p wa -k identity-modify
-w /etc/gshadow -p wa -k identity-modify
-w /etc/security/opasswd -p wa -k identity-modify

-w /var/log/faillock/ -p wa -k login-tracking
-w /var/run/faillock/ -p wa -k login-tracking

-w /etc/pam.d/ -p wa -k pam-config
-w /etc/security/ -p wa -k pam-config
-w /etc/nsswitch.conf -p wa -k nss-config
-w /etc/nss_ldap.conf -p wa -k nss-config
-w /etc/ldap.conf -p wa -k nss-config

# User/group management commands
-w /usr/sbin/useradd -p x -k user-modify
-w /usr/sbin/userdel -p x -k user-modify
-w /usr/sbin/usermod -p x -k user-modify
-w /usr/sbin/groupadd -p x -k group-modify
-w /usr/sbin/groupdel -p x -k group-modify
-w /usr/sbin/groupmod -p x -k group-modify
-w /usr/sbin/adduser -p x -k user-modify
-w /usr/sbin/addgroup -p x -k group-modify
-w /usr/bin/passwd -p x -k passwd-change
-w /usr/bin/chpasswd -p x -k passwd-change
-w /usr/bin/chage -p x -k passwd-change
-w /usr/bin/gpasswd -p x -k passwd-change
-w /usr/sbin/newusers -p x -k user-modify

# SSH configuration and keys (root + all users)
-w /etc/ssh/ -p wa -k ssh-config
-w /root/.ssh/ -p wa -k ssh-keys
# Per-user .ssh/ watches are appended dynamically below (see DYNAMIC RULES)

# Sudoers
-w /etc/sudoers -p wa -k sudo-config
-w /etc/sudoers.d/ -p wa -k sudo-config
-w /etc/doas.conf -p wa -k sudo-config
-w /etc/doas.d/ -p wa -k sudo-config

# Privilege escalation commands
-w /usr/bin/sudo -p x -k priv-escalation
-w /usr/bin/doas -p x -k priv-escalation
-w /usr/bin/pkexec -p x -k priv-escalation
# BusyBox su/passwd/login all run through the setuid helper /bin/bbsuid
-w /bin/bbsuid -p x -k priv-escalation

# ============================================================================
# PRIVILEGE ESCALATION
# T1548 - Abuse Elevation Control / T1068 - Exploitation for Privesc
# ============================================================================

# Permission changes (SUID bit setting, etc.)
-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=-1 -k perm-change
-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=-1 -k perm-change

# Ownership changes
-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=-1 -k owner-change
-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=-1 -k owner-change

# Extended attributes
-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=-1 -k xattr-change
-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=-1 -k xattr-change

# ptrace - process injection / debugging (T1055)
# Watch dangerous operations:
#   0x4  = PTRACE_POKETEXT (write to process code)
#   0x5  = PTRACE_POKEDATA (write to process data)
#   0x6  = PTRACE_POKEUSR  (write to process user area)
#   0x10 = PTRACE_ATTACH   (attach to process - precedes injection/credential dump)
# No catch-all — general ptrace (e.g. strace, gdb) is too noisy and the specific
# operations above cover the injection/hijack cases that matter.
-a always,exit -F arch=b64 -S ptrace -F a0=0x4 -k process-inject
-a always,exit -F arch=b32 -S ptrace -F a0=0x4 -k process-inject
-a always,exit -F arch=b64 -S ptrace -F a0=0x5 -k process-inject
-a always,exit -F arch=b32 -S ptrace -F a0=0x5 -k process-inject
-a always,exit -F arch=b64 -S ptrace -F a0=0x6 -k process-inject
-a always,exit -F arch=b32 -S ptrace -F a0=0x6 -k process-inject
-a always,exit -F arch=b64 -S ptrace -F a0=0x10 -k process-inject
-a always,exit -F arch=b32 -S ptrace -F a0=0x10 -k process-inject

# ============================================================================
# PERSISTENCE MECHANISMS
# T1053 - Scheduled Tasks / T1037 - Boot Scripts / T1543 - System Process
# ============================================================================

# Cron
-w /etc/crontab -p wa -k cron-persist
-w /etc/cron.d/ -p wa -k cron-persist
-w /etc/cron.daily/ -p wa -k cron-persist
-w /etc/cron.hourly/ -p wa -k cron-persist
-w /etc/cron.weekly/ -p wa -k cron-persist
-w /etc/cron.monthly/ -p wa -k cron-persist
-w /var/spool/cron/ -p wa -k cron-persist
-w /var/spool/cron/crontabs/ -p wa -k cron-persist
-w /etc/crontabs/ -p wa -k cron-persist
-w /etc/periodic/ -p wa -k cron-persist
-w /etc/periodic/15min/ -p wa -k cron-persist
-w /etc/periodic/hourly/ -p wa -k cron-persist
-w /etc/periodic/daily/ -p wa -k cron-persist
-w /etc/periodic/weekly/ -p wa -k cron-persist
-w /etc/periodic/monthly/ -p wa -k cron-persist

# at
-w /var/spool/at/ -p wa -k at-persist
-w /etc/at.allow -p wa -k at-persist
-w /etc/at.deny -p wa -k at-persist
-w /usr/bin/at -p x -k at-persist

# OpenRC (Alpine's init): service scripts, their settings, runlevels and
# /etc/local.d/*.start scripts that run at every boot
-w /etc/init.d/ -p wa -k init-persist
-w /etc/conf.d/ -p wa -k init-persist
-w /etc/runlevels/ -p wa -k init-persist
-w /etc/runlevels/default/ -p wa -k init-persist
-w /etc/runlevels/boot/ -p wa -k init-persist
-w /etc/runlevels/sysinit/ -p wa -k init-persist
-w /etc/local.d/ -p wa -k init-persist
-w /etc/inittab -p wa -k init-persist
-w /etc/rc.conf -p wa -k init-persist
-w /etc/modules -p wa -k init-persist
-w /etc/modules-load.d/ -p wa -k init-persist

# Shell profiles (login persistence)
-w /etc/profile -p wa -k shell-persist
-w /etc/profile.d/ -p wa -k shell-persist
-w /etc/bash/ -p wa -k shell-persist
-w /root/.profile -p wa -k shell-persist
-w /root/.ashrc -p wa -k shell-persist
-w /etc/bashrc -p wa -k shell-persist
-w /etc/bash.bashrc -p wa -k shell-persist
-w /etc/environment -p wa -k shell-persist
-w /etc/shells -p wa -k shell-persist

# LD_PRELOAD / library hijacking (T1574.006)
-w /etc/ld.so.conf -p wa -k lib-hijack
-w /etc/ld.so.conf.d/ -p wa -k lib-hijack
-w /etc/ld.so.preload -p wa -k lib-hijack

# MOTD / login banner
-w /etc/motd -p wa -k motd-persist
-w /etc/securetty -p wa -k login-tracking

# ============================================================================
# KERNEL MODULES
# T1547.006 - Kernel Modules and Extensions
# ============================================================================

-w /usr/sbin/insmod -p x -k kernel-module
-w /usr/sbin/rmmod -p x -k kernel-module
-w /usr/sbin/modprobe -p x -k kernel-module
-w /sbin/insmod -p x -k kernel-module
-w /sbin/rmmod -p x -k kernel-module
-w /sbin/modprobe -p x -k kernel-module
-a always,exit -F arch=b64 -S init_module -S finit_module -S delete_module -k kernel-module
-a always,exit -F arch=b32 -S init_module -S finit_module -S delete_module -k kernel-module

-w /etc/modprobe.conf -p wa -k modprobe-config
-w /etc/modprobe.d/ -p wa -k modprobe-config

# kexec (T1014 - Rootkit)
-a always,exit -F arch=b64 -S kexec_load -S kexec_file_load -k kexec
-a always,exit -F arch=b32 -S sys_kexec_load -k kexec

# ============================================================================
# NETWORK CONFIGURATION
# T1016 / T1049
# ============================================================================

-w /etc/hosts -p wa -k network-config
-w /etc/hosts.allow -p wa -k network-config
-w /etc/hosts.deny -p wa -k network-config
-w /etc/hostname -p wa -k network-config
-w /etc/resolv.conf -p wa -k network-config
-w /etc/network/ -p wa -k network-config
-w /etc/networks -p wa -k network-config

# Firewall config files
-w /etc/iptables/ -p wa -k firewall-config
-w /etc/nftables.nft -p wa -k firewall-config
-w /etc/nftables.d/ -p wa -k firewall-config
-w /etc/awall/ -p wa -k firewall-config
-w /etc/conf.d/iptables -p wa -k firewall-config

# Firewall tools
-w /sbin/iptables -p x -k firewall-tools
-w /sbin/ip6tables -p x -k firewall-tools
-w /usr/sbin/iptables -p x -k firewall-tools
-w /usr/sbin/nft -p x -k firewall-tools
-w /usr/sbin/awall -p x -k firewall-tools

# ============================================================================
# TIME CHANGES
# T1070.006 - Timestomp
# ============================================================================

-a always,exit -F arch=b64 -S adjtimex -S settimeofday -S clock_settime -k time-change
-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -S clock_settime -k time-change
-w /etc/localtime -p wa -k time-change
-w /etc/timezone -p wa -k time-change
-w /etc/ntp.conf -p wa -k time-change
-w /etc/chrony.conf -p wa -k time-change
-w /etc/chrony/ -p wa -k time-change

# ============================================================================
# SUSPICIOUS TOOL EXECUTION
# T1018 Remote Discovery / T1046 Scanning / T1040 Sniffing / T1105 Transfer
# ============================================================================

# Recon
-w /usr/bin/nmap -p x -k recon-tools
-w /usr/bin/nc -p x -k recon-tools
-w /usr/bin/ncat -p x -k recon-tools
-w /usr/bin/netcat -p x -k recon-tools
-w /usr/bin/socat -p x -k recon-tools
-w /usr/bin/tcpdump -p x -k recon-tools
-w /usr/sbin/tcpdump -p x -k recon-tools
-w /usr/bin/tshark -p x -k recon-tools
-w /usr/bin/wireshark -p x -k recon-tools
-w /usr/bin/rawshark -p x -k recon-tools
-w /usr/bin/masscan -p x -k recon-tools
-w /usr/bin/nc.openbsd -p x -k recon-tools
-w /usr/bin/nc.traditional -p x -k recon-tools
-w /usr/bin/nping -p x -k recon-tools
-w /usr/bin/hping3 -p x -k recon-tools

# File transfer / exfiltration
# NOTE: curl/wget will fire on legitimate package management. This is expected
# and acceptable - the events provide useful forensic context.
-w /usr/bin/wget -p x -k exfil-tools
-w /usr/bin/curl -p x -k exfil-tools
-w /usr/bin/scp -p x -k exfil-tools
-w /usr/bin/sftp -p x -k exfil-tools
-w /usr/bin/ftp -p x -k exfil-tools
-w /usr/bin/rsync -p x -k exfil-tools
-w /usr/bin/base64 -p x -k exfil-tools

# Remote access
-w /usr/bin/ssh -p x -k remote-access
-w /usr/bin/telnet -p x -k remote-access
-w /usr/bin/rdesktop -p x -k remote-access
-w /usr/bin/xfreerdp -p x -k remote-access

# Compilers (attacker building exploits on-box)
-w /usr/bin/gcc -p x -k compile-tools
-w /usr/bin/cc -p x -k compile-tools
-w /usr/bin/make -p x -k compile-tools
-w /usr/bin/as -p x -k compile-tools

# Scripting interpreters
# NOTE: On boxes where Python is part of a scored service, these will be noisy.
# Disable selectively per-box if needed, but keep by default - red team
# frequently uses python/perl for reverse shells and exploit scripts.
-w /usr/bin/python -p x -k script-exec
-w /usr/bin/python2 -p x -k script-exec
-w /usr/bin/python3 -p x -k script-exec
-w /usr/bin/perl -p x -k script-exec
-w /usr/bin/ruby -p x -k script-exec

# Docker / containers
-w /usr/bin/docker -p x -k container-tools
-w /etc/docker/ -p wa -k container-tools
-w /usr/bin/dockerd -p x -k container-tools
-w /usr/bin/podman -p x -k container-tools

# ============================================================================
# SYSTEM CONFIGURATION
# T1082 - System Information Discovery
# ============================================================================

-w /etc/sysctl.conf -p wa -k sysctl-config
-w /etc/sysctl.d/ -p wa -k sysctl-config

-a always,exit -F arch=b64 -S sethostname -S setdomainname -k hostname-change
-a always,exit -F arch=b32 -S sethostname -S setdomainname -k hostname-change

-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=-1 -k mount-ops
-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=-1 -k mount-ops

# ============================================================================
# SOFTWARE INSTALLATION
# T1072 - Software Deployment Tools
# ============================================================================

-w /sbin/apk -p x -k software-install
-w /etc/apk/repositories -p wa -k software-install
-w /etc/apk/keys/ -p wa -k software-install
-w /etc/apk/world -p wa -k software-install
-w /usr/bin/pip -p x -k software-install
-w /usr/bin/pip3 -p x -k software-install
-w /usr/local/bin/pip -p x -k software-install
-w /usr/local/bin/pip3 -p x -k software-install

# ============================================================================
# COMMAND EXECUTION AUDITING
# Logs every command run by human-login users (auid >= 1000).
# Skips system daemons automatically. This is the single highest-value rule
# for catching red team activity.
# ============================================================================

-a always,exit -F arch=b64 -S execve -F auid>=1000 -F auid!=-1 -k exec-cmd
-a always,exit -F arch=b32 -S execve -F auid>=1000 -F auid!=-1 -k exec-cmd

# ============================================================================
# 32-BIT API EXPLOITATION (on 64-bit systems)
# Attackers may use 32-bit execve to bypass 64-bit-only monitoring.
# Only monitors execve, not all syscalls (which would flood logs).
# ============================================================================

-a always,exit -F arch=b32 -S execve -F auid<1000 -F auid!=-1 -k 32bit-api

# ============================================================================
# SPECIAL FILESYSTEM OPERATIONS
# ============================================================================

# Device nodes (rootkit indicator - T1014)
-a always,exit -F arch=b64 -S mknod -S mknodat -k special-files
-a always,exit -F arch=b32 -S mknod -S mknodat -k special-files

# File deletion (covering tracks - T1070.004)
# NOTE: These are noisy (every mv, rm, editor swap triggers them). With execve
# auditing enabled, most deletions are already visible via the command that ran.
# Disable these on high-noise boxes if log volume becomes a problem.
-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=-1 -k file-delete
-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=-1 -k file-delete

# Failed file access (permission denied)
-a always,exit -F arch=b64 -S open -S openat -F exit=-EACCES -F auid>=1000 -F auid!=-1 -k access-denied
-a always,exit -F arch=b32 -S open -S openat -F exit=-EACCES -F auid>=1000 -F auid!=-1 -k access-denied
-a always,exit -F arch=b64 -S open -S openat -F exit=-EPERM -F auid>=1000 -F auid!=-1 -k access-denied
-a always,exit -F arch=b32 -S open -S openat -F exit=-EPERM -F auid>=1000 -F auid!=-1 -k access-denied

# ============================================================================
# Outbound network connections (reverse shells, C2 callbacks)
# NOTE: Commented out by default - very noisy on boxes running web services,
# DNS, mail, etc. Enable on quiet boxes or when actively hunting for C2.
# ============================================================================
# -a always,exit -F arch=b64 -S connect -F auid>=1000 -F auid!=-1 -k network-connect
# -a always,exit -F arch=b32 -S connect -F auid>=1000 -F auid!=-1 -k network-connect

AUDIT_RULES_EOF

# --- Dynamic rules: per-user .ssh/ watches ---
for _home in /home/*/; do
    if [ -d "$_home" ]; then
        printf -- '-w %s.ssh/ -p wa -k ssh-keys\n' "$_home" >> "$RULES_FILE"
    fi
done

# --- Alpine: no auid without pam_loginuid -> match on uid, and log root's commands ---
if [ "$AUID_TRACKED" -eq 0 ]; then
    sed -i -e 's/-F auid>=1000 -F auid!=-1/-F uid>=1000 -F uid!=-1/g' \
           -e 's/-F auid<1000 -F auid!=-1/-F uid<1000/g' "$RULES_FILE"
    cat >> "$RULES_FILE" << 'ROOT_EXEC_EOF'

# ============================================================================
# ROOT COMMAND EXECUTION (Alpine without pam_loginuid)
# auid is never set here, so commands run as root (red team after privesc,
# or your own su/doas sessions) can't be told apart by login. Log them all.
# Comment these out if a scored service spawns many root processes.
# ============================================================================
-a always,exit -F arch=b64 -S execve -F euid=0 -k exec-root
-a always,exit -F arch=b32 -S execve -F euid=0 -k exec-root
ROOT_EXEC_EOF
fi

# --- Alpine: exec watches on BusyBox applets can't work; follow other symlinks ---
_tmp="$RULES_FILE.tmp"; _seen=" "
while IFS= read -r line; do
    case "$line" in
        "-w "*" -p x "*)
            _p=$(echo "$line" | awk '{print $2}')
            if [ -L "$_p" ]; then
                _real=$(readlink -f "$_p")
                case "$_real" in
                    /bin/busybox)
                        echo "# BusyBox applet, covered by the execve rules: $line"
                        continue ;;
                esac
                _key=${line#* -k }
                line="-w $_real -p x -k $_key"
                _p=$_real
            fi
            case "$_seen" in *" $_p "*) echo "# duplicate of an earlier watch: $line"; continue ;; esac
            _seen="$_seen$_p "
            ;;
    esac
    printf '%s\n' "$line"
done < "$RULES_FILE" > "$_tmp" && mv "$_tmp" "$RULES_FILE"

# Append immutable flag as the very last rule (must be last)
cat >> "$RULES_FILE" << 'IMMUTABLE_EOF'

# ============================================================================
# MAKE RULES IMMUTABLE (uncomment when config is finalized)
# Prevents rule changes without reboot. Stops red team from disabling logging.
# ============================================================================
# -e 2
IMMUTABLE_EOF

log_info "Audit rules written to $RULES_FILE"

# ============================================================================
# STEP 4: Configure syslog (rsyslog, or BusyBox syslogd as a fallback)
# ============================================================================
log_section "Configuring syslog"

RSYSLOG_CONF="/etc/rsyslog.conf"
RSYSLOG_ENHANCED="/etc/rsyslog.d/50-enhanced.conf"
SYSLOG_DAEMON="busybox"

if command -v rsyslogd >/dev/null 2>&1 && [ -f "$RSYSLOG_CONF" ]; then
    cp -p "$RSYSLOG_CONF" "$BACKUP_DIR/"
    mkdir -p /etc/rsyslog.d
    [ -f "$RSYSLOG_ENHANCED" ] && cp -p "$RSYSLOG_ENHANCED" "$BACKUP_DIR/"
    if ! grep -qE 'rsyslog\.d' "$RSYSLOG_CONF"; then
        echo '$IncludeConfig /etc/rsyslog.d/*.conf' >> "$RSYSLOG_CONF"
        log_info "Added an include for /etc/rsyslog.d to $RSYSLOG_CONF"
    fi
    cat > "$RSYSLOG_ENHANCED" << 'RSYSLOG_EOF'
# Enhanced Logging Configuration
auth,authpriv.*                 /var/log/auth.log
kern.*                          /var/log/kern.log
mail.*                          /var/log/mail.log
*.emerg                         :omusrmsg:*
cron.*                          /var/log/cron.log

# REMOTE FORWARDING: If you have a log server, uncomment and set the IP.
# This makes your audit trail survivable if red team gets root.
# *.* @@<logserver-ip>:514
RSYSLOG_EOF
    log_info "rsyslog drop-in written to $RSYSLOG_ENHANCED"
    SYSLOG_DAEMON="rsyslog"
elif command -v syslog-ng >/dev/null 2>&1; then
    log_warn "syslog-ng detected. Configure manually if needed."
    SYSLOG_DAEMON="syslog-ng"
else
    # BusyBox syslogd keeps only ~200 KB of /var/log/messages by default.
    # Keep 10 rotations of 10 MB instead.
    if [ -f /etc/conf.d/syslog ]; then
        cp -p /etc/conf.d/syslog "$BACKUP_DIR/conf.d_syslog"
        if grep -q '^SYSLOGD_OPTS=' /etc/conf.d/syslog; then
            sed -i 's/^SYSLOGD_OPTS=.*/SYSLOGD_OPTS="-t -s 10240 -b 9"/' /etc/conf.d/syslog
        else
            echo 'SYSLOGD_OPTS="-t -s 10240 -b 9"' >> /etc/conf.d/syslog
        fi
        log_info "BusyBox syslogd: /var/log/messages now rotates at 10 MB, 9 old copies kept"
        log_info "  (remote copy: add '-R <logserver-ip>:514 -L' to SYSLOGD_OPTS in /etc/conf.d/syslog)"
    fi
fi

# ============================================================================
# STEP 5: (journald is systemd-only - nothing to do on Alpine)
# ============================================================================

# ============================================================================
# STEP 6: Enable process accounting
# ============================================================================
log_section "Enabling Process Accounting"

if command -v accton >/dev/null 2>&1; then
    if [ -f /var/account/pacct ]; then
        ACCT_FILE="/var/account/pacct"
    elif [ -f /var/log/account/pacct ]; then
        ACCT_FILE="/var/log/account/pacct"
    else
        mkdir -p /var/account
        touch /var/account/pacct
        ACCT_FILE="/var/account/pacct"
    fi
    if accton "$ACCT_FILE" 2>/dev/null; then
        # No OpenRC service ships with acct: turn it back on at every boot via local.d
        mkdir -p /etc/local.d
        printf '#!/bin/sh\naccton %s\n' "$ACCT_FILE" > /etc/local.d/acct.start
        chmod 755 /etc/local.d/acct.start
        rc-update add local default >/dev/null 2>&1
        log_info "Process accounting enabled ($ACCT_FILE, re-enabled at boot). Use 'lastcomm' and 'sa' to query."
    else
        log_warn "accton failed - the kernel may lack process accounting (CONFIG_BSD_PROCESS_ACCT)."
    fi
else
    log_warn "Process accounting tools not found. Skipping."
fi

# ============================================================================
# STEP 7: Install syshealth monitoring helper
# ============================================================================
log_section "Installing Monitoring Helper"

cat > /usr/sbin/syshealth << 'LOGWATCH_EOF'
#!/bin/sh
# syshealth - quick audit/log queries (Alpine)
authlog() {
    if [ -f /var/log/auth.log ]; then tail -n 50 /var/log/auth.log
    else grep -E 'sshd|login|su:|doas|sudo|passwd' /var/log/messages 2>/dev/null | tail -n 50; fi
}
case "${1:-help}" in
    auth)
        echo "=== Authentication Events ==="
        ausearch -k identity-modify -k passwd-change -k user-modify -k login-tracking -ts recent 2>/dev/null || authlog
        ;;
    persist)
        echo "=== Persistence Changes ==="
        ausearch -k cron-persist -k init-persist -k shell-persist -k at-persist -ts recent 2>/dev/null
        ;;
    priv)
        echo "=== Privilege Escalation ==="
        ausearch -k priv-escalation -k perm-change -k owner-change -k sudo-config -ts recent 2>/dev/null
        ;;
    network)
        echo "=== Network Changes ==="
        ausearch -k network-config -k firewall-config -k firewall-tools -ts recent 2>/dev/null
        ;;
    tamper)
        echo "=== Log Tampering ==="
        ausearch -k audit-log-tamper -k audit-config-tamper -k log-tamper -k syslog-config -ts recent 2>/dev/null
        ;;
    tools)
        echo "=== Suspicious Tools ==="
        ausearch -k recon-tools -k exfil-tools -k compile-tools -k remote-access -ts recent 2>/dev/null
        ;;
    exec)
        _since="${2:-recent}"
        echo "=== Command Execution (since $_since) ==="
        aureport -x --summary -ts "$_since" 2>/dev/null || \
            ausearch -k exec-cmd -k exec-root -ts "$_since" 2>/dev/null | tail -n 500
        ;;
    kernel)
        echo "=== Kernel Modules ==="
        ausearch -k kernel-module -k kexec -k modprobe-config -ts recent 2>/dev/null
        ;;
    software)
        echo "=== Software Installation (apk) ==="
        ausearch -k software-install -ts recent 2>/dev/null
        ;;
    denied)
        echo "=== Access Denied ==="
        ausearch -k access-denied -ts recent 2>/dev/null
        ;;
    logins)
        echo "=== Current ===" && who 2>/dev/null
        echo "" && echo "=== Recent ===" && { last 2>/dev/null | head -n 20; }
        echo "" && echo "=== Failed ==="
        ausearch -m USER_LOGIN --success no -ts recent 2>/dev/null || \
            grep -hE 'Failed password|Invalid user|authentication failure|bad password' /var/log/auth.log /var/log/messages 2>/dev/null | tail -n 20
        ;;
    watch)
        tail -f /var/log/audit/audit.log
        ;;
    summary)
        aureport --summary 2>/dev/null
        echo "" && echo "=== Failed ===" && aureport --failed 2>/dev/null | tail -n 20
        echo "" && echo "=== Auth ===" && aureport --auth 2>/dev/null | tail -n 20
        ;;
    status)
        auditctl -s 2>/dev/null
        echo "" && echo "Rules: $(auditctl -l 2>/dev/null | wc -l)"
        echo "Log:   $(ls -lh /var/log/audit/audit.log 2>/dev/null | awk '{print $5}')"
        echo "Disk:  $(df -h /var/log | tail -n 1 | awk '{print $4 " free"}')"
        echo "auditd: $(rc-service auditd status 2>/dev/null | sed -n 's/.*status: *//p')"
        ;;
    *)
        cat << 'HELPEOF'
Usage: syshealth <command>

  auth      Authentication & credential events
  persist   Persistence changes (cron, OpenRC, local.d, profiles)
  priv      Privilege escalation (doas/sudo/su, chmod, chown)
  network   Network/firewall changes
  tamper    Log/audit tampering attempts
  tools     Suspicious tool execution (nmap, nc, wget...)
  exec      Commands run (execve: human users + root)
  kernel    Kernel module activity
  software  Package installation (apk)
  denied    Access denied events
  logins    Current / recent / failed logins
  watch     Live tail audit.log
  summary   aureport summary
  status    Audit system health

Quick reference:
  ausearch -k <key> -ts recent        Last 15 min by key
  ausearch -k <key> -ts today         Today by key
  ausearch -m USER_LOGIN --success no  Failed logins
  ausearch -c <command>                By command name
  ausearch -ui <uid>                   By user ID
HELPEOF
        ;;
esac
LOGWATCH_EOF

chmod +x /usr/sbin/syshealth
log_info "Monitoring helper installed: /usr/sbin/syshealth"

# ============================================================================
# STEP 8: Start / Restart services
# ============================================================================
log_section "Starting Services"

if [ "$SYSLOG_DAEMON" = "rsyslog" ]; then
    # rsyslog replaces BusyBox syslogd (both want /dev/log)
    _old_boot=0
    rc-update show boot 2>/dev/null | grep -qw syslog && _old_boot=1
    rc-service syslog stop >/dev/null 2>&1
    if svc_enable_start rsyslog boot && svc_started rsyslog; then
        rc-update del syslog boot >/dev/null 2>&1
        log_info "rsyslog started and replaces BusyBox syslogd at boot."
    else
        log_error "rsyslog failed to start - going back to BusyBox syslogd so logging keeps working."
        rc-update del rsyslog boot >/dev/null 2>&1
        [ "$_old_boot" -eq 1 ] && rc-update add syslog boot >/dev/null 2>&1
        rc-service syslog start >/dev/null 2>&1
    fi
elif [ "$SYSLOG_DAEMON" = "busybox" ] && [ -x /etc/init.d/syslog ]; then
    rc-service syslog restart >/dev/null 2>&1 && log_info "BusyBox syslogd restarted."
fi

# Start auditd, then load the rules from rules.d
if svc_enable_start auditd default; then
    log_info "auditd (re)started."
else
    log_warn "Could not start auditd. Try: rc-service auditd start ; tail /var/log/messages"
fi
if command -v augenrules >/dev/null 2>&1; then
    _err=$(augenrules --load 2>&1)
    if [ $? -eq 0 ]; then
        log_info "Audit rules loaded via augenrules."
    else
        log_warn "augenrules reported: $(echo "$_err" | tail -n 3)"
    fi
else
    auditctl -R "$RULES_FILE" >/dev/null 2>&1 && log_info "Audit rules loaded via auditctl -R."
fi

# ============================================================================
# STEP 9: Verify
# ============================================================================
log_section "Verification"

RULE_COUNT=$(auditctl -l 2>/dev/null | grep -vc '^No rules')
log_info "Active audit rules: $RULE_COUNT"

if [ "$RULE_COUNT" -lt 10 ]; then
    log_warn "Rule count seems low. Check for errors:"
    log_warn "  auditctl -s          # 'enabled 1' = kernel audit works"
    log_warn "  auditctl -l          # list loaded rules"
    log_warn "  augenrules --load    # shows rule errors"
    log_warn "  tail /var/log/messages"
fi

AUDIT_STATUS=$(auditctl -s 2>/dev/null | grep "enabled" || echo "unknown (kernel audit support missing?)")
log_info "Audit status: $AUDIT_STATUS"

# ============================================================================
# SUMMARY
# ============================================================================
log_section "Setup Complete"

cat << SUMMARY_EOF

  Key files:
    Audit rules:   $RULES_FILE
    Audit config:  /etc/audit/auditd.conf
    Audit log:     /var/log/audit/audit.log
    Syslog:        $( [ "$SYSLOG_DAEMON" = rsyslog ] && echo "/var/log/messages, /var/log/auth.log, /var/log/mail.log (rsyslog)" || echo "/var/log/messages (BusyBox syslogd)" )
    Backups:       $BACKUP_DIR

  Quick commands:
    syshealth logins     Who's logged in / failed logins
    syshealth tamper     Log tampering attempts
    syshealth persist    Persistence changes
    syshealth exec       Commands run
    syshealth tools      Suspicious tool execution
    syshealth watch      Live tail of audit log
    syshealth summary    aureport summary
    syshealth status     Audit health check

  Audit rule keys (ausearch -k <key>):
    audit-log-tamper  audit-config-tamper  audit-tools   log-tamper
    identity-modify   login-tracking       pam-config    ssh-config
    ssh-keys          sudo-config          priv-escalation
    perm-change       owner-change         process-inject
    cron-persist      init-persist         shell-persist motd-persist
    lib-hijack        kernel-module        kexec
    network-config    firewall-config      firewall-tools
    time-change       hostname-change      mount-ops
    recon-tools       exfil-tools          remote-access
    compile-tools     script-exec          container-tools
    software-install  exec-cmd             exec-root     32bit-api
    file-delete       access-denied        special-files

  To lock rules (prevents changes without reboot):
    Uncomment '-e 2' at the end of $RULES_FILE
    Then: augenrules --load  OR  rc-service auditd restart

SUMMARY_EOF

log_info "Done at $(date)"
