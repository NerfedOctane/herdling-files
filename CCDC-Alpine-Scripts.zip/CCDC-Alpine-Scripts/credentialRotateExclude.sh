#!/bin/sh
# credentialRotateExclude.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Rotates passwords and clears SSH authorized_keys for every user with a login
# shell on this system, except the users listed in an exclusion file.
#
# Usage: ./credentialRotateExclude.sh <exclude_list.txt>
#
#   exclude_list.txt - users to NOT touch, one per line
#
# Blank lines and lines starting with # are ignored, and Windows (CRLF) line
# endings are handled. root and blackteam_adm are always excluded, even if they
# are missing from the file. Only accounts whose shell ends in "sh" (ash, bash,
# sh, zsh, ...) are changed, so service accounts with nologin/false shells are
# left alone. The root password is changed separately at the end; you will be
# prompted for it.
#
# Alpine notes: uses BusyBox chpasswd/passwd. ssh-keygen comes from the
# openssh-keygen package. If /etc/shadow is immutable (CCDC-Harden-SSH.sh sets
# chattr +i), it is unlocked for the run and locked again at the end.

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

defaultExclude="blackteam_adm root"

if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root." >&2
    exit 1
fi

if [ $# -ne 1 ]; then
    echo "Usage: $0 <exclude_list.txt>" >&2
    exit 1
fi

excludeFile="$1"
if [ ! -f "$excludeFile" ] || [ ! -r "$excludeFile" ]; then
    echo "Cannot read file: $excludeFile" >&2
    exit 1
fi

# Print the usernames in a file, one per line, skipping blanks and comments
readUserFile() {
    while IFS= read -r line || [ -n "$line" ]; do
        # Usernames can't contain whitespace, so strip all of it (including CR from CRLF files)
        name=$(printf '%s' "$line" | tr -d '[:space:]')
        [ -z "$name" ] && continue
        case "$name" in \#*) continue ;; esac
        echo "$name"
    done < "$1"
}

# Excluded users as a space-padded list: " a b c "
excluded=" "
add_excluded() { case "$excluded" in *" $1 "*) ;; *) excluded="$excluded$1 " ;; esac; }
is_excluded()  { case "$excluded" in *" $1 "*) return 0 ;; esac; return 1; }

for u in $defaultExclude; do add_excluded "$u"; done
for u in $(readUserFile "$excludeFile"); do add_excluded "$u"; done

# Everyone with a login shell who isn't excluded
seen=" "
targets=""
while IFS=: read -r username _ _ _ _ _ shell; do
    [ -z "$username" ] && continue
    case "$seen" in *" $username "*) continue ;; esac
    seen="$seen$username "
    is_excluded "$username" && continue
    case "$shell" in *sh) ;; *) continue ;; esac
    targets="$targets $username"
done <<EOF
$(getent passwd)
EOF

hostname=$(hostname)

echo "Users that will NOT be touched ($(echo $excluded | wc -w)):"
for u in $excluded; do printf '    %s\n' "$u"; done | sort
echo
echo "Users that WILL be changed on $hostname ($(echo $targets | wc -w)):"
for u in $targets; do printf '    %s\n' "$u"; done
echo

if [ -z "$targets" ]; then
    echo "No users to change. Exiting..."
    exit 0
fi

# Unlock /etc/shadow if it is immutable; lock it again when the script ends
RELOCK=""
TMPD=$(mktemp -d)
cleanup() {
    stty echo 2>/dev/null
    for f in $RELOCK; do chattr +i "$f" 2>/dev/null && echo "Re-locked $f (chattr +i)"; done
    rm -rf "$TMPD"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
for f in /etc/shadow /etc/passwd; do
    if command -v lsattr >/dev/null 2>&1 && lsattr "$f" 2>/dev/null | awk '{print $1}' | grep -q i; then
        chattr -i "$f" && RELOCK="$RELOCK $f" && echo "Temporarily unlocked $f (was chattr +i)"
    fi
done

keyDir="/etc/ssh/shared_keys"
mkdir -p "$keyDir"
chmod 700 "$keyDir"

sshKey="$keyDir/shared_key"
if [ ! -f "$sshKey" ]; then
    if ! command -v ssh-keygen >/dev/null 2>&1; then
        echo "WARNING: ssh-keygen not found (apk add openssh-keygen); shared SSH key pair not generated."
    elif ssh-keygen -t rsa -b 4096 -f "$sshKey" -N '' -q; then
        echo "Shared SSH key pair generated."
    else
        echo "WARNING: Failed to generate shared SSH key pair."
    fi
else
    echo "Shared SSH key pair already exists."
fi

# read_secret: read a line from the terminal without echoing it
read_secret() {
    stty -echo 2>/dev/null
    IFS= read -r SECRET
    stty echo 2>/dev/null
    echo
}

echo "Enter the new passphrase for the users listed above (Ctrl+C to cancel):"
read_secret; sharedPassphrase=$SECRET
echo "Confirm the passphrase:"
read_secret; confirmPassphrase=$SECRET
SECRET=""

if [ -z "$sharedPassphrase" ]; then
    echo "Passphrase cannot be empty. Exiting..."
    exit 1
fi

if [ "$sharedPassphrase" != "$confirmPassphrase" ]; then
    echo "Passphrases do not match. Exiting..."
    exit 1
fi
unset confirmPassphrase

changed=0
failed=0

for username in $targets; do
    entry=$(getent passwd "$username")
    IFS=: read -r _ _ _ gid _ home _ <<EOF
$entry
EOF

    if printf '%s:%s\n' "$username" "$sharedPassphrase" | chpasswd; then
        echo "Password changed for $username"
    else
        echo "Failed to change password for $username"
        failed=$((failed + 1))
        continue
    fi
    changed=$((changed + 1))

    # Don't create .ssh in / or in a home directory that doesn't exist
    if [ -z "$home" ] || [ "$home" = "/" ] || [ ! -d "$home" ]; then
        echo "No usable home directory for $username, authorized_keys not touched"
        continue
    fi

    userSshDir="$home/.ssh"
    if [ -L "$userSshDir" ] || { [ -e "$userSshDir" ] && [ ! -d "$userSshDir" ]; }; then
        echo "WARNING: $userSshDir is a symlink or not a directory, authorized_keys not touched"
        continue
    fi

    mkdir -p "$userSshDir"
    chown "$username":"$gid" "$userSshDir"
    chmod 700 "$userSshDir"

    # Remove first, then create with noclobber, so a planted symlink can't
    # redirect the write to another file
    rm -f "$userSshDir/authorized_keys"
    if ( umask 077; set -C; : > "$userSshDir/authorized_keys" ); then
        chown "$username":"$gid" "$userSshDir/authorized_keys"
        chmod 600 "$userSshDir/authorized_keys"
        echo "Cleared authorized_keys for $username."
    else
        echo "WARNING: could not recreate $userSshDir/authorized_keys"
    fi
done

unset sharedPassphrase

echo
echo "Summary: $changed password(s) changed, $failed failed."

# Changing root user password
echo "Now changing the root password:"
passwd root

echo "Script completed."
