# CCDC scripts – Alpine Linux versions

These are Alpine-only copies of the team scripts. Keep using the originals on
Debian/Ubuntu and RHEL-family boxes. Each script checks for `/etc/alpine-release`
and refuses to run anywhere else (set `SKIP_ALPINE_CHECK=1` to override for testing).

## How to run them

Run everything as root (`su -` or `doas`). Alpine has no `sudo` by default.

```sh
sh ./CCDC-Backup-Final.sh          # works with BusyBox sh, nothing to install
sh ./CCDC-Harden-SSH.sh            # re-runs itself under bash (see below)
```

Always start them with `sh script.sh` (or `./script.sh`). All of them use a
`#!/bin/sh` first line, so they start on a bare Alpine box.

| Kind | Scripts | Needs |
|---|---|---|
| Plain sh (BusyBox ash) | `CCDC-Backup-Final.sh`, `CCDC-Restore-Final.sh`, `CCDC-Docker-Backup.sh`, `CCDC-Docker-Restore.sh`, `CCDC-Credential-Rotate.sh`, `credentialRotateExclude.sh`, `mass_user_delete.sh`, `mass_user_keep.sh`, `ftp_user_create_secure.sh`, `ftp_usergroup_add.sh`, `shadow_passwd_backup.sh`, `shadow_passwd_restore.sh`, `inventory.sh`, `logv14.sh` | Nothing. BusyBox only |
| bash | `CCDC-Harden-SSH.sh`, `CCDC-Harden-LDAP.sh`, `CCDC-Harden-Realmd.sh`, `harden-samba.2.sh`, `harden-mariadb.sh`, `mariadb-create-users.sh`, `mariadb-docker-harden.sh`, `vsftpd-harden-agnostic.sh`, `mail_harden-4.sh`, `mail_cve.sh`, `harden-web-traditional.sh`, `harden-web-docker.sh`, `CCDC-Docker-Harden.sh` | bash. If it's missing, the script runs `apk add bash` and re-launches itself. With no repo access it stops and tells you to install bash |
| Browser | `bulk_scorecheck_password_update.js` | Unchanged (Tampermonkey userscript, not OS-specific) |

Other packages are installed with `apk` only when no BusyBox tool can do the
job: `e2fsprogs-extra` for `chattr` (SSH lock step), `openssl` for a Dovecot
self-signed cert, and the service's own package when a script already installed
it before (audit, rsyslog, acct, fail2ban, samba, vsftpd, mariadb). If apk can't
reach a repo, the script warns and carries on.

## What changed everywhere

* **Packages:** `apt`/`dnf`/`yum` → `apk`.
* **Services:** `systemctl` → OpenRC (`rc-service NAME restart`, `rc-update add NAME default`,
  status parsed from `rc-service NAME status`). Alpine service names are used:
  `sshd`, `apache2`, `nginx`, `mariadb`, `samba`, `named`, `exim`, `nfs`, `slapd`, `auditd`, `docker`.
* **Users:** `useradd`/`usermod`/`groupadd` → BusyBox `adduser -D`, `addgroup USER GROUP`,
  `deluser --remove-home`. If the `shadow` package is installed, `userdel` is used.
* **GNU-only flags replaced:** `find -printf`, `cp --parents`, `chmod/chown --reference`,
  `sort -V`, `grep -P`, `grep --include`, `tar -P`/`--mode`, `ps aux`/`-C`/`-eo`, `date -Is`,
  `hostname -I`, `paste -sd`, `tac`, `\s` in sed/grep regexes (musl has no `\s`),
  one-line `sed 'a\ text'`. `ss` falls back to BusyBox `netstat`.
* **Logs:** no journald. Logs live in `/var/log/messages` (BusyBox syslogd), or in
  `/var/log/auth.log` and `/var/log/mail.log` once `logv14.sh` has installed rsyslog.
* **Paths:** Apache `/etc/apache2/httpd.conf` + `conf.d/`, web root `/var/www/localhost/htdocs`.
  Nginx `/etc/nginx/http.d/`, web root `/var/lib/nginx/html`. MariaDB `/etc/my.cnf.d/`.
  vsftpd `/etc/vsftpd/vsftpd.conf`. OpenLDAP `/etc/openldap`. Service settings in `/etc/conf.d/*`.

## Per-script notes

**CCDC-Harden-SSH.sh**
* Stock Alpine `openssh-server` has no PAM. The script detects this and leaves out `UsePAM yes`.
  A non-PAM sshd flags that line as unsupported, and the original treated that as fatal.
* `/etc/conf.d/sshd` replaces `/etc/default/ssh`. `SSHD_OPTS`, `SSHD_CONFIG`,
  `SSHD_CONFDIR` and `command*=` lines are commented out. A non-stock `SSHD_BINARY` is
  commented out too (`/usr/sbin/sshd` and `/usr/sbin/sshd.pam` are kept). Shell code
  in that file (it is sourced as root) is flagged.
* The systemd override checks became OpenRC checks. `apk audit` compares
  `/etc/init.d/sshd` and the ssh binaries with the package. Other init scripts,
  `local.d`, `inittab` and crontabs that start sshd are flagged.
* The admin check understands doas (`permit … :wheel`). If nobody can doas/sudo, it says so.
* `chattr` comes from `e2fsprogs-extra` and is installed if needed. `restore.sh` is now plain sh.

**CCDC-Backup-Final.sh / CCDC-Restore-Final.sh**
* Backups now also include OpenRC (`/etc/init.d`, `conf.d`, `runlevels`, `local.d`, `inittab`),
  cron (`/etc/crontabs`, `/etc/periodic`), doas, apk state (`/etc/apk`, installed list),
  `/etc/my.cnf*`, `/etc/snmp` and Alpine's iptables/nftables/awall files.
  Restore option **35** brings back OpenRC and cron.
* Most Alpine commands are symlinks to `/bin/busybox`. The binary backup stores each real
  file once, with its mode, plus a map of every symlink in the bin directories.
  Option 33 reports repointed or replaced symlinks and runs `apk audit`.
  Option 34 keeps setuid bits (the original's `chmod 755 /usr/bin/*` stripped them from
  `sudo`/`passwd`) and swaps files in by rename, since BusyBox itself is running.
* Fixed while porting: per-user shell configs were never restored (the file-name glob
  never matched), and "restore everything" copied tarballs and `ldap_*.conf` into `/etc`.

**shadow_passwd_backup.sh / restore.sh**
* Alpine servers have no icon theme, so the hiding spot moved. The copies are now
  gzip+base64 "public keys" in `/usr/share/apk/keys/`, a folder full of real
  `*.rsa.pub` files that apk never reads (it only trusts `/etc/apk/keys`):
  * `alpine-devel@lists.alpinelinux.org-5d43a1b1.rsa.pub` = shadow
  * `alpine-devel@lists.alpinelinux.org-5fd8b2e4.rsa.pub` = passwd
* The restore checks the decoded data before overwriting anything, and lifts `chattr +i` if
  the SSH script set it.

**mass_user_keep.sh / mass_user_delete.sh**
* Home directories are only removed when they're under `/home`. On Alpine, service accounts
  own their data directories as home (`mysql` → `/var/lib/mysql`, `nginx` → `/var/lib/nginx`),
  so the original rule would have wiped a database if `mysql` was missing from the keep list.
* The user you logged in as (`logname`) and `$DOAS_USER` are always kept, like `$SUDO_USER`.
* Stock Alpine system accounts are listed in the header to copy into your keep list.

**Credential rotation scripts**: BusyBox `chpasswd`. `/etc/shadow` is temporarily
unlocked if it's immutable, then re-locked.

**logv14.sh**
* Installs `audit`, `acct` and `rsyslog` with apk. rsyslog takes over from BusyBox syslogd
  (and rolls back if it won't start). Without rsyslog, BusyBox syslogd keeps 10×10 MB
  instead of its 200 KB default.
* Rules: systemd/apt/yum watches are replaced with OpenRC, `local.d`, `/etc/crontabs`,
  `/etc/periodic`, doas, `/etc/apk` and `/bin/bbsuid` (BusyBox's setuid su/passwd).
* `-p x` watches on BusyBox applets are commented out at install time (they can't tell
  applets apart). The execve rules still log every command.
* **Important:** without `pam_loginuid` (stock Alpine), the audit login UID is never set.
  The original `auid>=1000` rules would log nothing. They are switched to `uid>=1000`,
  and a new `exec-root` rule logs root's commands.
* Process accounting is re-enabled at boot through `/etc/local.d/acct.start`.

**vsftpd-harden-agnostic.sh**
* `seccomp_sandbox=NO`. The original set YES, and on Alpine that makes every listing fail
  with `500 OOPS: child died`.
* Warns about FTP users whose shell isn't in `/etc/shells` (non-PAM vsftpd refuses them).

**harden-mariadb.sh / mariadb-create-users.sh / mariadb-docker-harden.sh**
* Alpine layout and OpenRC. `-i` runs the first-start data-directory setup Alpine needs.
* Warns when Alpine's default `skip-networking` would block remote accounts or TCP scoring.
* Fixed: password generation exits silently (status 141) under `set -o pipefail` when
  `openssl` isn't installed, which is the default on Alpine.
* Docker version: `docker top -eo` (which runs the host's ps) is replaced with a `/proc` read
  inside the container.

**harden-web-traditional.sh**: modules are disabled by commenting out `LoadModule`, and
`mod_headers` is enabled. `httpd -t` / `nginx -t` run after the edits and roll back
automatically if they fail. Alpine's nginx `http.d/default.conf` (a 404 catch-all,
often holding the real site) is reported, never deleted.

**harden-web-docker.sh / CCDC-Docker-Harden.sh**
* Commands inside containers use `sh -c`, not `bash -c`. Alpine-based images have no bash,
  so before every step failed silently while printing OK.
* Handles the official `httpd` image layout (`/usr/local/apache2`) and nginx `http.d`.
* `daemon.json` is checked with `dockerd --validate` before a restart, and restored if docker
  won't start.
* **Behavior change, on purpose:** `userns-remap` is now a prompt that defaults to **No**.
  Remapping hides every existing container, image and volume, which would take scored
  containers offline. On Alpine there's a second risk: dockerd creates its `dockremap`
  user with `useradd` or Debian-style `adduser` flags that BusyBox doesn't accept, so the
  daemon can fail to start. If you say yes, the user and its `/etc/subuid`/`/etc/subgid`
  ranges are created first.
* The PID column for killing reverse shells is read from the `ps` header. The original's
  `$2` was the USER column in BusyBox containers.

**mail_harden-4.sh / mail_cve.sh**: apk/OpenRC; Exim is the single-file `/etc/exim/exim.conf`
(regexes rewritten for musl); Apache drop-in goes to `/etc/apache2/conf.d`; fail2ban
installed with apk (warns if mail logs are still in BusyBox's `/var/log/messages`);
pending updates come from `apk version -l '<'`; `--patch` runs `apk add -u`. Alpine
installs no changelog of backported fixes, so the CVE ladder plus apk updates decide.

**CCDC-Harden-LDAP.sh / CCDC-Harden-Realmd.sh**: these were already portable. They got the
bash bootstrap, OpenRC service checks, Alpine's lower-case `ldapi://%2f…` socket URL from
`/etc/conf.d/slapd`, and `ldap:ldap` recovery steps. realmd is uncommon on Alpine: without
it, the Realmd script audits hand-made joins (keytab permissions, `krb5.conf`, `sssd.conf`).

## What was and wasn't tested

* Every plain-sh script was syntax-checked with BusyBox 1.36.1's ash (the BusyBox shell
  Alpine uses) and dash. Every bash script passes `bash -n`, and its bootstrap was run
  from ash (including the install-bash path).
* Run end to end or with stubs: the passwd/shadow hide and restore round trip; both
  credential-rotation scripts; keep-list parsing and home-dir rules; the full backup; restore
  options 6, 33 and 34; the SSH `conf.d`/PAM/doas/netstat logic; mail tar/permission
  helpers and Exim edits; the version-compare replacement (identical to `sort -V` on all
  3,969 version pairs from the CVE ladder); in-container snippets for nginx, Apache and the
  reverse-shell kill.
* **Not tested on a real Alpine VM.** Do a dry run on a snapshot first, especially
  `CCDC-Harden-SSH.sh` (keep a second session open) and `logv14.sh` (check that
  `auditctl -s` shows `enabled 1`, meaning the kernel's audit support is on).
