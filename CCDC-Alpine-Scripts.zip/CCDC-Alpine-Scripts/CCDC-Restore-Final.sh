#!/bin/sh
# CCDC-Restore-Final.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Restores from the newest /root/Injects_* backup made by CCDC-Backup-Final.sh
# (or pass a backup directory as the first argument). Services are restarted
# with OpenRC (rc-service).

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
   echo "[!] Must run as root"
   exit 1
fi

BACKUP_DIR=${1:-$(ls -td /root/Injects_* /var/tmp/backups_* 2>/dev/null | head -n1)}

if [ -z "$BACKUP_DIR" ] || [ ! -d "$BACKUP_DIR" ]; then
    echo "[!] No backup found"
    exit 1
fi

ESC=$(printf '\033')
GRN="${ESC}[32m"; YEL="${ESC}[33m"; RED="${ESC}[31m"; GRY="${ESC}[90m"; RST="${ESC}[0m"

DISTRO_FAMILY=$(cat "$BACKUP_DIR/.distro_family" 2>/dev/null || echo alpine)

get_web_user() {
    if [ -f "$BACKUP_DIR/.web_user" ]; then
        cat "$BACKUP_DIR/.web_user"
        return
    fi
    for u in apache nginx lighttpd www-data; do
        id "$u" >/dev/null 2>&1 && { echo "$u"; return; }
    done
    echo "root"
}
WEB_USER=$(get_web_user)

untar() { [ -f "$1" ] && tar -xzf "$1" -C / 2>/dev/null; return 0; }

restart_svc() {
    for svc in "$@"; do
        if [ -x "/etc/init.d/$svc" ]; then
            rc-service "$svc" restart >/dev/null 2>&1
        fi
    done
}

check_status() {
    svc=$1
    [ -x "/etc/init.d/$svc" ] || return 0
    STATUS=$(rc-service "$svc" status 2>/dev/null | sed -n 's/.*status: *//p' | head -n1)
    case $STATUS in
        started)          printf '[%s ACTIVE %s] %s\n' "$GRN" "$RST" "$svc" ;;
        stopped|inactive) printf '[%s INACTIVE %s] %s\n' "$YEL" "$RST" "$svc" ;;
        crashed)          printf '[%s FAILED %s] %s\n' "$RED" "$RST" "$svc" ;;
        *)                printf '[%s UNKNOWN %s] %s\n' "$GRY" "$RST" "$svc" ;;
    esac
}

check_status_multi() {
    for svc in "$@"; do
        check_status "$svc"
    done
}

# PostgreSQL on Alpine may be /etc/init.d/postgresql or a versioned postgresqlNN
pg_services() {
    for f in /etc/init.d/postgresql*; do [ -x "$f" ] && basename "$f"; done
}

# with_unlocked FILE... -- COMMAND...: lift chattr +i for the command, then relock
unlock_files() {
    RELOCK=""
    for f in "$@"; do
        if command -v lsattr >/dev/null 2>&1 && lsattr "$f" 2>/dev/null | awk '{print $1}' | grep -q i; then
            chattr -i "$f" && RELOCK="$RELOCK $f"
        fi
    done
}
relock_files() { for f in $RELOCK; do chattr +i "$f"; done; RELOCK=""; }

restore_ssh() {
    unlock_files /etc/ssh/sshd_config
    for f in "$BACKUP_DIR/ssh/"*; do
        case "$(basename "$f")" in keys_*.tar.gz|conf.d_sshd) continue ;; esac
        cp -rp "$f" /etc/ssh/
    done
    [ -f "$BACKUP_DIR/ssh/conf.d_sshd" ] && cp -p "$BACKUP_DIR/ssh/conf.d_sshd" /etc/conf.d/sshd
    chmod 600 /etc/ssh/ssh_host_*_key 2>/dev/null
    chmod 644 /etc/ssh/sshd_config
    relock_files
}

restore_users() {
    unlock_files /etc/passwd /etc/shadow /etc/group
    cp "$BACKUP_DIR/system/passwd" /etc/passwd
    cp "$BACKUP_DIR/system/shadow" /etc/shadow
    cp "$BACKUP_DIR/system/group" /etc/group
    [ -f "$BACKUP_DIR/system/gshadow" ] && cp "$BACKUP_DIR/system/gshadow" /etc/gshadow
    chmod 644 /etc/passwd /etc/group
    chmod 640 /etc/shadow
    chown root:shadow /etc/shadow 2>/dev/null || chown root:root /etc/shadow
    relock_files
}

restore_auth_files() {
    untar "$BACKUP_DIR/auth/sssd_etc.tar.gz"
    untar "$BACKUP_DIR/auth/sssd_cache.tar.gz"
    [ -f "$BACKUP_DIR/auth/nsswitch.conf" ] && cp "$BACKUP_DIR/auth/nsswitch.conf" /etc/nsswitch.conf
    [ -f "$BACKUP_DIR/auth/krb5.conf" ] && cp "$BACKUP_DIR/auth/krb5.conf" /etc/krb5.conf
    untar "$BACKUP_DIR/auth/krb5_conf_d.tar.gz"
    [ -f "$BACKUP_DIR/auth/machine.keytab" ] && cp -p "$BACKUP_DIR/auth/machine.keytab" /etc/krb5.keytab
    if [ -f "$BACKUP_DIR/auth/ldap_openldap.conf" ]; then
        mkdir -p /etc/openldap && cp "$BACKUP_DIR/auth/ldap_openldap.conf" /etc/openldap/ldap.conf
    fi
    [ -f "$BACKUP_DIR/auth/smb.conf" ] && mkdir -p /etc/samba && cp "$BACKUP_DIR/auth/smb.conf" /etc/samba/smb.conf
    untar "$BACKUP_DIR/auth/realmd.tar.gz"
    untar "$BACKUP_DIR/auth/samba_secrets.tar.gz"
    chmod 600 /etc/sssd/sssd.conf /etc/krb5.keytab 2>/dev/null
}

restore_shell() {
    [ -f "$BACKUP_DIR/shell/etc_bash_bashrc" ] && cp "$BACKUP_DIR/shell/etc_bash_bashrc" /etc/bash/bashrc
    [ -f "$BACKUP_DIR/shell/bash.bashrc" ] && cp "$BACKUP_DIR/shell/bash.bashrc" /etc/bash.bashrc
    [ -f "$BACKUP_DIR/shell/bashrc" ] && cp "$BACKUP_DIR/shell/bashrc" /etc/bashrc
    [ -f "$BACKUP_DIR/shell/profile" ] && cp "$BACKUP_DIR/shell/profile" /etc/profile
    untar "$BACKUP_DIR/shell/profile_d.tar.gz"
    [ -f "$BACKUP_DIR/shell/root_bashrc" ] && cp "$BACKUP_DIR/shell/root_bashrc" /root/.bashrc
    [ -f "$BACKUP_DIR/shell/root_bash_profile" ] && cp "$BACKUP_DIR/shell/root_bash_profile" /root/.bash_profile
    [ -f "$BACKUP_DIR/shell/root_profile" ] && cp "$BACKUP_DIR/shell/root_profile" /root/.profile
    [ -f "$BACKUP_DIR/shell/root_ashrc" ] && cp "$BACKUP_DIR/shell/root_ashrc" /root/.ashrc
    # Per-user files are saved as <user>_.<file> (e.g. alice_.bashrc)
    for rc in "$BACKUP_DIR/shell/"*_.*; do
        [ -f "$rc" ] || continue
        filename=$(basename "$rc")
        user=${filename%%_.*}
        rctype=${filename#*_.}
        [ -d "/home/$user" ] && cp -p "$rc" "/home/$user/.$rctype" 2>/dev/null
    done
}

restore_sudo() {
    [ -f "$BACKUP_DIR/system/sudoers" ] && cp "$BACKUP_DIR/system/sudoers" /etc/sudoers && chmod 440 /etc/sudoers
    untar "$BACKUP_DIR/system/sudoers_d.tar.gz"
    [ -f "$BACKUP_DIR/system/doas.conf" ] && cp "$BACKUP_DIR/system/doas.conf" /etc/doas.conf && chmod 600 /etc/doas.conf
    untar "$BACKUP_DIR/system/doas_d.tar.gz"
}

restore_all_services() {
    for t in "$BACKUP_DIR/services/"*.tar.gz; do
        [ -f "$t" ] && tar -xzf "$t" -C / 2>/dev/null
    done
    restart_svc apache2 lighttpd nginx caddy
    restart_svc mariadb mysql $(pg_services)
    restart_svc postfix dovecot exim courier-imap
    restart_svc named unbound dnsmasq
    restart_svc samba vsftpd proftpd gitea snmpd nfs openvpn slapd redis haproxy squid fail2ban
    for f in /etc/init.d/php-fpm*; do [ -x "$f" ] && restart_svc "$(basename "$f")"; done
}

echo "=== CCDC RESTORE MENU (Alpine) ==="
echo "Backup: $BACKUP_DIR"
echo "Distro: $DISTRO_FAMILY"
echo ""
echo "AUTHENTICATION & ACCESS:"
echo "  1) SSH (sshd_config + host keys + /etc/conf.d/sshd)"
echo "  2) Auth (SSSD + Kerberos + LDAP client)"
echo "  3) Users (passwd/shadow/group)"
echo "  4) PAM (login policies, only if PAM was installed)"
echo "  5) Sudoers / doas"
echo "  6) Shell Configs (profile, ashrc, bashrc)"
echo ""
echo "NETWORK & SECURITY:"
echo "  7) Firewall (iptables/nftables/awall)"
echo "  8) Network configs (interfaces, resolv.conf, hosts, fstab)"
echo ""
echo "WEB SERVERS:"
echo "  9) Apache (apache2)"
echo "  10) Nginx"
echo "  11) Caddy"
echo ""
echo "DATABASES:"
echo "  12) MySQL/MariaDB"
echo "  13) PostgreSQL"
echo ""
echo "MAIL:"
echo "  14) Postfix"
echo "  15) Dovecot"
echo "  16) Exim"
echo "  17) Courier"
echo ""
echo "FILE/DOMAIN SERVICES:"
echo "  18) Samba"
echo "  19) FTP (vsftpd/proftpd)"
echo "  20) Gitea"
echo ""
echo "NETWORK SERVICES:"
echo "  21) BIND/Named (DNS)"
echo "  22) Unbound (DNS)"
echo "  23) dnsmasq (DNS)"
echo "  24) SNMP"
echo "  25) NFS"
echo "  26) OpenVPN"
echo ""
echo "WEB CONTENT:"
echo "  27) Full Web Root (/var/www, /var/lib/nginx/html, ...)"
echo "  28) WordPress"
echo ""
echo "PACKAGE MANAGER:"
echo "  29) APK (repositories, keys, world)"
echo ""
echo "NUCLEAR OPTIONS:"
echo "  30) All Auth (SSH + SSSD + Users + PAM + Shell)"
echo "  31) All Services"
echo "  32) EVERYTHING"
echo ""
echo "VERIFICATION & EMERGENCY:"
echo "  33) Verify Binaries (check for rootkits)"
echo "  34) Restore Binaries (LAST RESORT)"
echo ""
echo "ALPINE EXTRAS:"
echo "  35) OpenRC services, runlevels, local.d and cron"
echo ""
printf 'Select [1-35]: '
read -r choice

case $choice in
    1)
        echo "[*] Restoring SSH..."
        restore_ssh
        restart_svc sshd
        echo "✓ SSH restored"
        check_status sshd
        ;;
    2)
        echo "[*] Restoring authentication..."
        restore_auth_files
        restart_svc sssd
        echo "✓ Auth restored"
        check_status sssd
        command -v realm >/dev/null 2>&1 && realm list 2>/dev/null
        ;;
    3)
        echo "[*] Restoring users..."
        restore_users
        echo "✓ Users restored"
        ;;
    4)
        echo "[*] Restoring PAM..."
        if [ -f "$BACKUP_DIR/system/pam_configs.tar.gz" ]; then
            untar "$BACKUP_DIR/system/pam_configs.tar.gz"
            echo "✓ PAM restored"
        else
            echo "❌ No PAM configs in backup (PAM wasn't installed when it was taken)"
        fi
        ;;
    5)
        echo "[*] Restoring sudoers / doas..."
        restore_sudo
        echo "✓ Sudoers / doas restored"
        ;;
    6)
        echo "[*] Restoring shell configs..."
        restore_shell
        echo "✓ Shell configs restored"
        ;;
    7)
        echo "[*] Restoring firewall..."
        untar "$BACKUP_DIR/network/firewall_etc.tar.gz"
        [ -s "$BACKUP_DIR/network/iptables.rules" ] && command -v iptables-restore >/dev/null 2>&1 && iptables-restore < "$BACKUP_DIR/network/iptables.rules"
        [ -s "$BACKUP_DIR/network/ip6tables.rules" ] && command -v ip6tables-restore >/dev/null 2>&1 && ip6tables-restore < "$BACKUP_DIR/network/ip6tables.rules"
        [ -s "$BACKUP_DIR/network/nft.rules" ] && command -v nft >/dev/null 2>&1 && nft -f "$BACKUP_DIR/network/nft.rules"
        # Persist live iptables rules for the OpenRC iptables service
        if [ -x /etc/init.d/iptables ] && [ -s "$BACKUP_DIR/network/iptables.rules" ]; then
            rc-service iptables save >/dev/null 2>&1
        fi
        echo "✓ Firewall restored"
        command -v iptables >/dev/null 2>&1 && iptables -L -n 2>/dev/null | head -20
        ;;
    8)
        echo "[*] Restoring network configs..."
        cp "$BACKUP_DIR/system/resolv.conf" /etc/resolv.conf 2>/dev/null
        cp "$BACKUP_DIR/system/hosts" /etc/hosts 2>/dev/null
        cp "$BACKUP_DIR/system/hostname" /etc/hostname 2>/dev/null
        cp "$BACKUP_DIR/system/fstab" /etc/fstab 2>/dev/null
        [ -f "$BACKUP_DIR/network/interfaces" ] && mkdir -p /etc/network && cp "$BACKUP_DIR/network/interfaces" /etc/network/interfaces 2>/dev/null
        untar "$BACKUP_DIR/network/interfaces_d.tar.gz"
        untar "$BACKUP_DIR/network/network_hooks.tar.gz"
        untar "$BACKUP_DIR/network/NetworkManager.tar.gz"
        untar "$BACKUP_DIR/network/wpa_supplicant.tar.gz"
        echo "✓ Network configs restored (apply with: rc-service networking restart - this drops connections briefly)"
        ;;
    9)
        echo "[*] Restoring Apache..."
        untar "$BACKUP_DIR/services/apache_etc.tar.gz"
        untar "$BACKUP_DIR/services/apache2_etc.tar.gz"
        untar "$BACKUP_DIR/services/httpd_etc.tar.gz"
        restart_svc apache2
        echo "✓ Apache restored"
        check_status apache2
        ;;
    10)
        echo "[*] Restoring Nginx..."
        untar "$BACKUP_DIR/services/nginx_etc.tar.gz"
        restart_svc nginx
        echo "✓ Nginx restored"
        check_status nginx
        ;;
    11)
        echo "[*] Restoring Caddy..."
        untar "$BACKUP_DIR/services/caddy_etc.tar.gz"
        restart_svc caddy
        echo "✓ Caddy restored"
        check_status caddy
        ;;
    12)
        echo "[*] Restoring MySQL/MariaDB..."
        untar "$BACKUP_DIR/services/mysql_etc.tar.gz"
        untar "$BACKUP_DIR/services/mariadb_etc.tar.gz"
        restart_svc mariadb mysql
        echo "✓ MySQL/MariaDB restored"
        check_status_multi mariadb mysql
        ;;
    13)
        echo "[*] Restoring PostgreSQL..."
        untar "$BACKUP_DIR/services/postgresql_etc.tar.gz"
        restart_svc $(pg_services)
        echo "✓ PostgreSQL restored"
        check_status_multi $(pg_services)
        ;;
    14)
        echo "[*] Restoring Postfix..."
        untar "$BACKUP_DIR/services/postfix_etc.tar.gz"
        command -v newaliases >/dev/null 2>&1 && newaliases 2>/dev/null
        restart_svc postfix
        echo "✓ Postfix restored"
        check_status postfix
        ;;
    15)
        echo "[*] Restoring Dovecot..."
        untar "$BACKUP_DIR/services/dovecot_etc.tar.gz"
        restart_svc dovecot
        echo "✓ Dovecot restored"
        check_status dovecot
        ;;
    16)
        echo "[*] Restoring Exim..."
        untar "$BACKUP_DIR/services/exim_etc.tar.gz"
        untar "$BACKUP_DIR/services/exim4_etc.tar.gz"
        restart_svc exim
        echo "✓ Exim restored"
        check_status exim
        ;;
    17)
        echo "[*] Restoring Courier..."
        untar "$BACKUP_DIR/services/courier_etc.tar.gz"
        restart_svc courier courier-imap courier-pop
        echo "✓ Courier restored"
        check_status_multi courier courier-imap
        ;;
    18)
        echo "[*] Restoring Samba..."
        untar "$BACKUP_DIR/services/samba_etc.tar.gz"
        untar "$BACKUP_DIR/services/smb_etc.tar.gz"
        untar "$BACKUP_DIR/auth/samba_secrets.tar.gz"
        restart_svc samba
        echo "✓ Samba restored"
        check_status samba
        ;;
    19)
        echo "[*] Restoring FTP..."
        untar "$BACKUP_DIR/services/vsftpd_etc.tar.gz"
        untar "$BACKUP_DIR/services/proftpd_etc.tar.gz"
        restart_svc vsftpd proftpd
        echo "✓ FTP restored"
        check_status_multi vsftpd proftpd
        ;;
    20)
        echo "[*] Restoring Gitea..."
        untar "$BACKUP_DIR/services/gitea_etc.tar.gz"
        untar "$BACKUP_DIR/webapps/gitea_data.tar.gz"
        untar "$BACKUP_DIR/webapps/gitea_lib.tar.gz"
        id gitea >/dev/null 2>&1 && chown -R gitea:www-data /var/lib/gitea 2>/dev/null
        restart_svc gitea
        echo "✓ Gitea restored"
        check_status gitea
        ;;
    21)
        echo "[*] Restoring BIND..."
        untar "$BACKUP_DIR/services/bind_etc.tar.gz"
        untar "$BACKUP_DIR/services/bind9_etc.tar.gz"
        untar "$BACKUP_DIR/services/named_etc.tar.gz"
        restart_svc named
        echo "✓ BIND restored"
        check_status named
        ;;
    22)
        echo "[*] Restoring Unbound..."
        untar "$BACKUP_DIR/services/unbound_etc.tar.gz"
        restart_svc unbound
        echo "✓ Unbound restored"
        check_status unbound
        ;;
    23)
        echo "[*] Restoring dnsmasq..."
        untar "$BACKUP_DIR/services/dnsmasq_etc.tar.gz"
        restart_svc dnsmasq
        echo "✓ dnsmasq restored"
        check_status dnsmasq
        ;;
    24)
        echo "[*] Restoring SNMP..."
        untar "$BACKUP_DIR/services/snmpd_etc.tar.gz"
        restart_svc snmpd
        echo "✓ SNMP restored"
        check_status snmpd
        ;;
    25)
        echo "[*] Restoring NFS..."
        untar "$BACKUP_DIR/services/nfs_etc.tar.gz"
        untar "$BACKUP_DIR/services/nfs-server_etc.tar.gz"
        untar "$BACKUP_DIR/services/nfs-kernel-server_etc.tar.gz"
        restart_svc nfs
        command -v exportfs >/dev/null 2>&1 && exportfs -ra 2>/dev/null
        echo "✓ NFS restored"
        check_status nfs
        ;;
    26)
        echo "[*] Restoring OpenVPN..."
        untar "$BACKUP_DIR/services/openvpn_etc.tar.gz"
        restart_svc openvpn
        echo "✓ OpenVPN restored"
        check_status openvpn
        ;;
    27)
        echo "[*] Restoring full web root..."
        untar "$BACKUP_DIR/webroot/var_www.tar.gz"
        untar "$BACKUP_DIR/webroot/nginx_html.tar.gz"
        untar "$BACKUP_DIR/webroot/usr_share_nginx_html.tar.gz"
        untar "$BACKUP_DIR/webroot/webapps.tar.gz"
        untar "$BACKUP_DIR/webroot/srv_www.tar.gz"
        chown -R "$WEB_USER:$WEB_USER" /var/www 2>/dev/null
        restart_svc apache2 lighttpd nginx
        echo "✓ Web root restored (owner: $WEB_USER)"
        ;;
    28)
        echo "[*] Restoring WordPress..."
        WP_ROOT=$(cat "$BACKUP_DIR/webapps/wordpress_root.txt" 2>/dev/null)
        [ -n "$WP_ROOT" ] || WP_ROOT=$(find /var/www /var/lib/nginx/html /usr/share/nginx/html /usr/share/webapps /opt -name "wp-config.php" 2>/dev/null | head -n1 | xargs -r dirname)
        if [ -n "$WP_ROOT" ] && [ -f "$BACKUP_DIR/webapps/wp-config.php" ]; then
            mkdir -p "$WP_ROOT"
            cp "$BACKUP_DIR/webapps/wp-config.php" "$WP_ROOT/" 2>/dev/null
            untar "$BACKUP_DIR/webapps/wordpress_content.tar.gz"
            [ -f "$BACKUP_DIR/webapps/wordpress_htaccess" ] && cp "$BACKUP_DIR/webapps/wordpress_htaccess" "$WP_ROOT/.htaccess"
            chown -R "$WEB_USER:$WEB_USER" "$WP_ROOT" 2>/dev/null
            restart_svc apache2 lighttpd nginx
            for f in /etc/init.d/php-fpm*; do [ -x "$f" ] && restart_svc "$(basename "$f")"; done
            echo "✓ WordPress restored (owner: $WEB_USER)"
        else
            echo "❌ WordPress not found"
        fi
        ;;
    29)
        echo "[*] Restoring package manager..."
        untar "$BACKUP_DIR/packages/apk_etc.tar.gz"
        apk update 2>/dev/null | tail -n 2
        echo "✓ APK config restored. To reinstall packages that were removed since the backup:"
        echo "    apk add \$(cat $BACKUP_DIR/packages/world)"
        ;;
    30)
        echo "[*] RESTORING ALL AUTH..."
        restore_ssh
        restore_auth_files
        restore_users
        untar "$BACKUP_DIR/system/pam_configs.tar.gz"
        restore_sudo
        restore_shell
        restart_svc sshd sssd
        echo "✓ ALL AUTH RESTORED"
        check_status sshd
        check_status sssd
        ;;
    31)
        echo "[*] RESTORING ALL SERVICES..."
        restore_all_services
        echo "✓ ALL SERVICES RESTORED"
        echo ""
        for svc in apache2 lighttpd nginx caddy mariadb mysql $(pg_services) postfix dovecot exim named unbound dnsmasq samba vsftpd proftpd gitea snmpd nfs openvpn slapd; do
            check_status "$svc"
        done
        ;;
    32)
        echo "[*] NUCLEAR RESTORE - EVERYTHING..."
        restore_ssh
        restore_auth_files
        restore_users
        untar "$BACKUP_DIR/system/pam_configs.tar.gz"
        restore_sudo
        restore_shell
        for f in sysctl.conf fstab resolv.conf hosts hostname; do
            [ -f "$BACKUP_DIR/system/$f" ] && cp "$BACKUP_DIR/system/$f" "/etc/$f"
        done
        untar "$BACKUP_DIR/system/sysctl_d.tar.gz"
        untar "$BACKUP_DIR/webroot/var_www.tar.gz"
        untar "$BACKUP_DIR/webroot/nginx_html.tar.gz"
        untar "$BACKUP_DIR/webroot/usr_share_nginx_html.tar.gz"
        untar "$BACKUP_DIR/webroot/webapps.tar.gz"
        untar "$BACKUP_DIR/packages/apk_etc.tar.gz"
        untar "$BACKUP_DIR/network/firewall_etc.tar.gz"
        restore_all_services
        restart_svc sshd sssd
        for s in iptables ip6tables nftables; do [ -x "/etc/init.d/$s" ] && rc-service "$s" reload >/dev/null 2>&1; done
        echo "✓ FULL RESTORE COMPLETE"
        echo ""
        echo "=== SERVICE STATUS ==="
        for svc in sshd sssd apache2 lighttpd nginx caddy mariadb mysql $(pg_services) postfix dovecot exim named samba vsftpd gitea snmpd nfs openvpn slapd iptables nftables; do
            check_status "$svc"
        done
        ;;
    33)
        echo "[*] Verifying system binaries..."
        echo ""
        COMPROMISED=0
        MAN="$BACKUP_DIR/binaries/MANIFEST.txt"
        if [ -f "$MAN" ]; then
            while read -r stored mode uid gid real; do
                [ -n "$real" ] || continue
                if [ ! -e "$real" ]; then
                    printf '[%s MISSING %s] %s\n' "$RED" "$RST" "$real"; COMPROMISED=1; continue
                fi
                CURRENT_HASH=$(sha256sum "$real" 2>/dev/null | awk '{print $1}')
                BACKUP_HASH=$(awk -v f="$stored" '$2==f {print $1}' "$BACKUP_DIR/binaries/HASHES.txt")
                if [ "$CURRENT_HASH" = "$BACKUP_HASH" ]; then
                    printf '[%s OK %s] %s - matches backup\n' "$GRN" "$RST" "$real"
                else
                    printf '[%s COMPROMISED %s] %s - HASH MISMATCH\n' "$RED" "$RST" "$real"
                    echo "     Current:  $CURRENT_HASH"
                    echo "     Backup:   $BACKUP_HASH"
                    COMPROMISED=1
                fi
                cur_mode=$(stat -c %a "$real")
                [ "$cur_mode" != "$mode" ] && { printf '[%s CHANGED %s] %s mode %s (was %s)\n' "$YEL" "$RST" "$real" "$cur_mode" "$mode"; COMPROMISED=1; }
            done < "$MAN"
        fi
        # Symlinks in /bin /sbin /usr/bin /usr/sbin that now point somewhere else
        if [ -f "$BACKUP_DIR/binaries/ALL_SYMLINKS.txt" ]; then
            while read -r link target; do
                if [ -L "$link" ]; then
                    now=$(readlink "$link")
                    [ "$now" != "$target" ] && { printf '[%s REPOINTED %s] %s -> %s (was %s)\n' "$RED" "$RST" "$link" "$now" "$target"; COMPROMISED=1; }
                elif [ -e "$link" ]; then
                    printf '[%s REPLACED %s] %s is now a real file (was a symlink to %s)\n' "$RED" "$RST" "$link" "$target"; COMPROMISED=1
                fi
            done < "$BACKUP_DIR/binaries/ALL_SYMLINKS.txt"
        fi
        # Package database check: files changed since apk installed them
        echo ""
        echo "[*] apk audit of system binaries (U = modified, A = not from any package):"
        apk audit --system /bin /sbin /usr/bin /usr/sbin /lib /usr/lib/ssh 2>/dev/null | grep -E '^[UA] ' | head -n 40 | sed 's/^/    /'
        echo ""
        if [ $COMPROMISED -eq 1 ]; then
            printf '[%s WARNING %s] Compromised binaries detected!\n' "$YEL" "$RST"
            echo "Recommended action (reinstall from the repo):"
            echo "  apk fix --reinstall busybox busybox-suid apk-tools openssh openssh-server"
            command -v sudo >/dev/null 2>&1 && echo "  apk fix --reinstall sudo"
            command -v doas >/dev/null 2>&1 && echo "  apk fix --reinstall doas"
        else
            printf '[%s ALL CLEAR %s] No compromised binaries detected (compared to the backup)\n' "$GRN" "$RST"
        fi
        ;;
    34)
        echo "[!] WARNING: Only use if apk is completely broken!"
        echo ""
        printf 'Continue with binary restore? [y/N]: '
        read -r response
        case "$response" in
            [Yy])
                echo "[*] Restoring binaries..."
                MAN="$BACKUP_DIR/binaries/MANIFEST.txt"
                while read -r stored mode uid gid real; do
                    [ -n "$real" ] && [ -f "$BACKUP_DIR/binaries/$stored" ] || continue
                    # Copy next to the target, then rename over it: writing straight
                    # into a running binary (BusyBox is running this script) fails.
                    cp "$BACKUP_DIR/binaries/$stored" "$real.ccdc-new" \
                        && chown "$uid:$gid" "$real.ccdc-new" \
                        && chmod "$mode" "$real.ccdc-new" \
                        && mv -f "$real.ccdc-new" "$real" \
                        && echo "  restored $real ($mode)"
                done < "$MAN"
                # Put the tracked command symlinks back the way they were
                if [ -f "$BACKUP_DIR/binaries/SYMLINKS.txt" ]; then
                    while read -r link target; do
                        [ "$(readlink "$link" 2>/dev/null)" = "$target" ] && continue
                        ln -sfn "$target" "$link" && echo "  relinked $link -> $target"
                    done < "$BACKUP_DIR/binaries/SYMLINKS.txt"
                fi
                echo "✓ Binaries restored"
                echo ""
                printf '[%s IMPORTANT %s] NOW REINSTALL WITH APK:\n' "$YEL" "$RST"
                echo "  apk fix --reinstall busybox busybox-suid apk-tools openssh openssh-server"
                ;;
            *) echo "Binary restore cancelled" ;;
        esac
        ;;
    35)
        echo "[*] Restoring OpenRC services, runlevels, local.d and cron..."
        echo "    (anything red team added to /etc/init.d, /etc/runlevels, /etc/local.d or"
        echo "     crontabs since the backup is NOT removed by this - compare with:"
        echo "     tar -tzf $BACKUP_DIR/init/openrc.tar.gz)"
        untar "$BACKUP_DIR/init/openrc.tar.gz"
        untar "$BACKUP_DIR/init/cron.tar.gz"
        restart_svc crond
        echo "✓ OpenRC and cron restored. Current runlevels:"
        rc-update show -v 2>/dev/null | grep -v '|[[:space:]]*$' | head -40
        ;;
    *)
        echo "[!] Invalid choice"
        exit 1
        ;;
esac

echo ""
