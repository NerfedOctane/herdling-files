#!/bin/sh
# --- Alpine guard (POSIX sh until the second "fi") -----------------------------
# This is the Alpine Linux version. It needs bash: if this was started with
# BusyBox sh (ash), bash is installed with apk when missing and the script
# re-runs itself under it.
if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi
if [ -z "${BASH_VERSION:-}" ]; then
    if ! command -v bash >/dev/null 2>&1; then
        echo "[*] bash is not installed; installing it with apk..." >&2
        apk add --no-cache bash >/dev/null 2>&1 || {
            echo "[!] Could not install bash (no repository access?). Install it first: apk add bash" >&2
            exit 1
        }
    fi
    exec bash "$0" "$@"
fi
# --------------------------------------------------------------------------------
# mariadb-docker-harden.sh - audit and harden a MariaDB server running in Docker
# (Alpine Linux host version: BusyBox-compatible host commands, OpenRC docker service).
#
# Default mode only reports. With --apply it backs everything up first, then
# makes the changes that can be done on the running container (accounts,
# server options, resource limits). Settings Docker can only change by
# recreating the container are printed as a hardened `docker run` command.
#
# Usage: sh ./mariadb-docker-harden.sh [-c container] [--apply] [options]   (as root)

set -uo pipefail

CONTAINER="mariadbTEST"
APPLY=0
MEMORY="1g"
PIDS_LIMIT="200"
BIND_IP=""            # host IP for 3306 in the recommended run command
MIN_VERSION="10.11"   # oldest LTS still maintained (10.6 reached EOL July 2026)
TARGET_IMAGE="mariadb:11.4"
BACKUP_DIR="./mariadb-backups"
CNF_NAME="zz-hardening.cnf"

usage() {
  cat <<EOF
Usage: $0 [options]
  -c, --container NAME   container to harden (default: $CONTAINER)
  -a, --apply            apply fixes (default: audit only, changes nothing)
      --memory SIZE      memory limit set by --apply (default: $MEMORY)
      --pids N           process limit set by --apply (default: $PIDS_LIMIT)
      --bind-ip IP       host IP to publish 3306 on in the recommended run command
  -h, --help
The MariaDB root password is read from \$MARIADB_ROOT_PW, or prompted for.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -c|--container) CONTAINER="$2"; shift 2 ;;
    -a|--apply)     APPLY=1; shift ;;
    --memory)       MEMORY="$2"; shift 2 ;;
    --pids)         PIDS_LIMIT="$2"; shift 2 ;;
    --bind-ip)      BIND_IP="$2"; shift 2 ;;
    -h|--help)      usage; exit 0 ;;
    *) echo "Unknown option: $1"; usage; exit 2 ;;
  esac
done

# ---------- output helpers ----------
if [[ -t 1 ]]; then R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[34m'; N=$'\e[0m'; else R=; G=; Y=; B=; N=; fi
PASS=0; WARN=0; FAIL=0; FIXED=0
pass()    { echo "${G}[PASS]${N}  $*"; PASS=$((PASS+1)); }
warn()    { echo "${Y}[WARN]${N}  $*"; WARN=$((WARN+1)); }
fail()    { echo "${R}[FAIL]${N}  $*"; FAIL=$((FAIL+1)); }
info()    { echo "${B}[INFO]${N}  $*"; }
fixed()   { echo "${G}[FIXED]${N} $*"; FIXED=$((FIXED+1)); }
section() { echo; echo "== $* =="; }
die()     { echo "${R}ERROR:${N} $*" >&2; exit 1; }
oneline() { tr '\n' ' ' <<<"$1"; }

# Fixes found during the audit; applied at the end with --apply.
FIX_SQL=()      # statements run as root
CNF=()          # lines for /etc/mysql/conf.d/zz-hardening.cnf
UPD=()          # arguments for `docker update`
NEED_FILES_DIR=0

# ---------- preflight ----------
command -v docker >/dev/null || die "docker not found"
docker info >/dev/null 2>&1 || die "cannot reach the Docker daemon (run as root; is it started? rc-service docker start)"
[[ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null)" == "true" ]] \
  || die "container '$CONTAINER' is not running (see: docker ps -a)"

in_ctr() { docker exec "$CONTAINER" sh -c "$1" 2>/dev/null; }
CLI=$(in_ctr 'command -v mariadb || command -v mysql')
DUMP=$(in_ctr 'command -v mariadb-dump || command -v mysqldump')
ADMIN=$(in_ctr 'command -v mariadb-admin || command -v mysqladmin')
MYSQL_UID=$(in_ctr 'id -u mysql'); MYSQL_UID=${MYSQL_UID:-999}
[[ -n "$CLI" ]] || die "no mariadb/mysql client found inside the container"

ROOT_PW="${MARIADB_ROOT_PW:-}"
if [[ -z "$ROOT_PW" ]]; then read -rsp "MariaDB root password: " ROOT_PW; echo; fi

# The password goes in through MYSQL_PWD so it never appears in `ps` output.
sql()    { docker exec -i -e MYSQL_PWD="$ROOT_PW" "$CONTAINER" "$CLI" -uroot -N -B -e "$1"; }
sqlvar() { sql "SELECT @@GLOBAL.$1" 2>/dev/null; }
sql "SELECT 1" >/dev/null 2>&1 || die "root login inside the container failed (wrong password?)"

# ver_ge A B: true if dotted version A >= B (BusyBox sort has no -V)
ver_ge() {
  local IFS=. i x y
  local -a a=($1) b=($2)
  for ((i = 0; i < 4; i++)); do
    x=${a[i]:-0}; y=${b[i]:-0}
    x=${x%%[!0-9]*}; y=${y%%[!0-9]*}
    x=$((10#${x:-0})); y=$((10#${y:-0}))
    ((x > y)) && return 0
    ((x < y)) && return 1
  done
  return 0
}
insp()   { docker inspect -f "$1" "$CONTAINER"; }

echo "MariaDB Docker hardening - container: $CONTAINER - mode: $([[ $APPLY == 1 ]] && echo APPLY || echo AUDIT)"

# ======================================================================
section "MariaDB version"
VERSION=$(sql "SELECT VERSION()")
VER_NUM=${VERSION%%-*}
info "Server version: $VERSION"
if ver_ge "$VER_NUM" "$MIN_VERSION"; then
  pass "Version $VER_NUM is $MIN_VERSION or newer"
  TARGET_IMAGE=$(insp '{{.Config.Image}}')
else
  fail "Version $VER_NUM is older than $MIN_VERSION and no longer gets security fixes; upgrade to $TARGET_IMAGE"
fi

# ======================================================================
section "Accounts"
ANON=$(sql "SELECT CONCAT(QUOTE(user),'@',QUOTE(host)) FROM mysql.user WHERE user=''")
if [[ -n "$ANON" ]]; then
  fail "Anonymous accounts exist: $(oneline "$ANON")"
  while read -r a; do FIX_SQL+=("DROP USER $a;"); done <<<"$ANON"
else
  pass "No anonymous accounts"
fi

REMOTE_ROOT=$(sql "SELECT CONCAT(QUOTE(user),'@',QUOTE(host)) FROM mysql.user
                   WHERE user='root' AND host NOT IN ('localhost','127.0.0.1','::1')")
LOCAL_ROOT=$(sql "SELECT COUNT(*) FROM mysql.user WHERE user='root' AND host='localhost'")
if [[ -n "$REMOTE_ROOT" ]]; then
  fail "root can log in over the network: $(oneline "$REMOTE_ROOT")"
  if [[ "$LOCAL_ROOT" -ge 1 ]]; then
    while read -r a; do FIX_SQL+=("DROP USER $a;"); done <<<"$REMOTE_ROOT"
  else
    warn "Not removing remote root: there is no root@localhost to fall back on"
  fi
else
  pass "root is limited to local connections"
fi

EMPTY=$(sql "SELECT CONCAT(QUOTE(user),'@',QUOTE(host)) FROM mysql.user
             WHERE user NOT IN ('','mariadb.sys') AND plugin IN ('','mysql_native_password')
               AND authentication_string='' AND Password=''")
if [[ -n "$EMPTY" ]]; then
  fail "Accounts with no password (set one with ALTER USER): $(oneline "$EMPTY")"
else
  pass "Every password-based account has a password"
fi

WILDCARD=$(sql "SELECT CONCAT(QUOTE(user),'@',QUOTE(host)) FROM mysql.user
                WHERE host='%' AND user NOT IN ('','root')")
if [[ -n "$WILDCARD" ]]; then
  warn "Accounts allowed from any host (narrow to an IP or subnet): $(oneline "$WILDCARD")"
else
  pass "No non-root accounts allowed from any host"
fi

BROAD=$(sql "SELECT CONCAT(QUOTE(user),'@',QUOTE(host)) FROM mysql.user
             WHERE user NOT IN ('root','mariadb.sys')
               AND (Super_priv='Y' OR File_priv='Y' OR Grant_priv='Y'
                    OR Shutdown_priv='Y' OR Process_priv='Y')")
if [[ -n "$BROAD" ]]; then
  warn "Non-root accounts with admin privileges (SUPER/FILE/GRANT/SHUTDOWN/PROCESS); grant on db.* instead of *.*: $(oneline "$BROAD")"
else
  pass "No non-root accounts with admin privileges"
fi

DUPS=$(sql "SELECT CONCAT(user,' (',GROUP_CONCAT(host SEPARATOR ', '),')') FROM mysql.user
            WHERE user NOT IN ('','root','healthcheck') GROUP BY user HAVING COUNT(*) > 1")
if [[ -n "$DUPS" ]]; then
  warn "Same user defined for several hosts; the most specific host wins, possibly with a different password: $(oneline "$DUPS")"
else
  pass "No duplicate user definitions"
fi

# Accounts that use host names stop working once skip_name_resolve is on.
NAMED_HOSTS=$(sql "SELECT CONCAT(QUOTE(user),'@',QUOTE(host)) FROM mysql.user
                   WHERE host <> 'localhost' AND host NOT REGEXP '^[0-9.%_/]+\$' AND host NOT LIKE '%:%'")

# ======================================================================
section "Databases"
if [[ -n "$(sql "SHOW DATABASES LIKE 'test'")" ]]; then
  fail "Sample 'test' database exists"
  FIX_SQL+=("DROP DATABASE test;")
else
  pass "No 'test' database"
fi
TEST_GRANTS=$(sql "SELECT COUNT(*) FROM mysql.db WHERE Db='test' OR Db=CONCAT('test',CHAR(92),'_%')")
if [[ "$TEST_GRANTS" -gt 0 ]]; then
  fail "Default grants on test/test_% databases let any user create them"
  FIX_SQL+=("DELETE FROM mysql.db WHERE Db='test' OR Db=CONCAT('test',CHAR(92),'_%');")
else
  pass "No default test-database grants"
fi

# ======================================================================
section "Server options"
if [[ "$(sqlvar local_infile)" == "0" ]]; then
  pass "local_infile is OFF"
else
  fail "local_infile is ON (LOAD DATA LOCAL can read files from client machines)"
  FIX_SQL+=("SET GLOBAL local_infile = 0;")
  CNF+=("local_infile = 0")
fi

if [[ "$(sqlvar skip_name_resolve)" == "1" ]]; then
  pass "skip_name_resolve is ON"
elif [[ -n "$NAMED_HOSTS" ]]; then
  warn "skip_name_resolve is OFF; not enabling it because these accounts use host names: $(oneline "$NAMED_HOSTS")"
else
  warn "skip_name_resolve is OFF (DNS lookups on every connection; host-name spoofing)"
  CNF+=("skip_name_resolve = 1")
fi

SFP=$(sqlvar secure_file_priv)
if [[ -z "$SFP" ]]; then
  fail "secure_file_priv is empty (FILE privilege can read/write anywhere mysqld can)"
  CNF+=("secure_file_priv = /var/lib/mysql-files")
  NEED_FILES_DIR=1
else
  pass "secure_file_priv is restricted ($SFP)"
fi

if [[ "$(sqlvar have_symlink)" == "YES" ]]; then
  warn "Symbolic links for tables are enabled"
  CNF+=("symbolic-links = 0")
else
  pass "Symbolic links are disabled"
fi

LW=$(sqlvar log_warnings)
if [[ -n "$LW" && "$LW" -lt 2 ]]; then
  warn "log_warnings is $LW; failed logins are not logged"
  CNF+=("log_warnings = 2")
else
  pass "log_warnings is ${LW:-n/a}"
fi

if [[ "$(sqlvar have_ssl)" == "YES" ]]; then
  pass "TLS is available"
  if [[ "$(sqlvar require_secure_transport)" != "1" ]]; then
    warn "require_secure_transport is OFF; clients may still connect unencrypted"
  fi
else
  warn "TLS is not enabled; traffic, including logins, is unencrypted (needs certificates, not automated)"
fi

PWCHECK=$(sql "SELECT COUNT(*) FROM information_schema.PLUGINS
               WHERE PLUGIN_NAME IN ('simple_password_check','cracklib_password_check')
                 AND PLUGIN_STATUS='ACTIVE'")
if [[ "$PWCHECK" -gt 0 ]]; then
  pass "A password-strength plugin is active"
else
  warn "No password-strength plugin; weak new passwords are accepted"
  FIX_SQL+=("INSTALL SONAME 'simple_password_check';")
fi

# ======================================================================
section "Container: $CONTAINER"
IMAGE=$(insp '{{.Config.Image}}')
if [[ "$IMAGE" != *:* || "${IMAGE##*:}" == "latest" ]]; then
  warn "Image '$IMAGE' is not pinned to a version"
else
  pass "Image is pinned: $IMAGE"
fi

[[ "$(insp '{{.HostConfig.Privileged}}')" == "true" ]] \
  && fail "Container runs with --privileged" || pass "Not privileged"

[[ "$(insp '{{.HostConfig.NetworkMode}}')" == "host" ]] \
  && fail "Container uses host networking" || pass "Not using host networking"

CAP_ADD=$(insp '{{range .HostConfig.CapAdd}}{{.}} {{end}}')
CAP_DROP=$(insp '{{range .HostConfig.CapDrop}}{{.}} {{end}}')
[[ -n "$CAP_ADD" ]] && warn "Extra capabilities added: $CAP_ADD"
[[ "$CAP_DROP" == *ALL* ]] && pass "All capabilities dropped" \
  || warn "Default Linux capabilities kept (use --cap-drop ALL; needs recreate)"

[[ "$(insp '{{range .HostConfig.SecurityOpt}}{{.}} {{end}}')" == *no-new-privileges* ]] \
  && pass "no-new-privileges is set" || warn "no-new-privileges is not set (needs recreate)"

[[ "$(insp '{{.HostConfig.ReadonlyRootfs}}')" == "true" ]] \
  && pass "Root filesystem is read-only" || warn "Root filesystem is writable (needs recreate)"

PROC_UID=$(in_ctr 'for p in /proc/[0-9]*; do
  c=$(cat "$p/comm" 2>/dev/null)
  case "$c" in mariadbd|mysqld) awk "/^Uid:/ {print \$2; exit}" "$p/status"; break ;; esac
done')
[[ -n "$PROC_UID" && "$PROC_UID" != "0" ]] \
  && pass "mysqld runs as non-root (uid $PROC_UID)" || fail "mysqld runs as root"

if [[ "$(insp '{{.HostConfig.Memory}}')" == "0" ]]; then
  warn "No memory limit"
  UPD+=(--memory "$MEMORY" --memory-swap "$MEMORY")
else
  pass "Memory limit set"
fi

if [[ "$(insp '{{.HostConfig.PidsLimit}}')" =~ ^[1-9][0-9]*$ ]]; then
  pass "Process (pids) limit set"
else
  warn "No process (pids) limit"
  UPD+=(--pids-limit "$PIDS_LIMIT")
fi

RESTART=$(insp '{{.HostConfig.RestartPolicy.Name}}')
if [[ -z "$RESTART" || "$RESTART" == "no" ]]; then
  warn "No restart policy"
  UPD+=(--restart unless-stopped)
else
  pass "Restart policy: $RESTART"
fi

PORTS=$(insp '{{range $p, $b := .HostConfig.PortBindings}}{{range $b}}{{.HostIp}}|{{.HostPort}} {{end}}{{end}}')
EXPOSED=""
for p in $PORTS; do
  ip=${p%%|*}
  [[ -z "$ip" || "$ip" == "0.0.0.0" || "$ip" == "::" ]] && EXPOSED+="${ip:-all}:${p##*|} "
done
if [[ -n "$EXPOSED" ]]; then
  warn "Port published on all interfaces, IPv4 and IPv6 ($EXPOSED); bind to one IP (needs recreate)"
else
  pass "Ports are bound to specific addresses"
fi

PW_ENV=$(insp '{{range .Config.Env}}{{println .}}{{end}}' \
  | grep -E '^(MARIADB|MYSQL)_[A-Z_]*PASSWORD=' | cut -d= -f1 | tr '\n' ' ')
if [[ -n "$PW_ENV" ]]; then
  fail "Passwords stored in environment variables, readable with docker inspect: $PW_ENV"
else
  pass "No passwords in environment variables"
fi

MOUNTS=$(insp '{{range .Mounts}}{{.Source}}:{{.Destination}} {{end}}')
[[ "$MOUNTS" == *docker.sock* ]] && fail "Docker socket is mounted into the container (host takeover)"
DATA_VOL=$(insp '{{range .Mounts}}{{if eq .Destination "/var/lib/mysql"}}{{if .Name}}{{.Name}}{{else}}{{.Source}}{{end}}{{end}}{{end}}')
if [[ -z "$DATA_VOL" ]]; then
  fail "No volume on /var/lib/mysql; data lives in the container layer"
  DATA_VOL="mariadb-data"
elif [[ "$DATA_VOL" =~ ^[0-9a-f]{64}$ ]]; then
  warn "Data is on an anonymous volume ($DATA_VOL); 'docker rm -v' would delete it"
else
  pass "Data is on volume/bind: $DATA_VOL"
fi

# ======================================================================
section "Docker host"
DOCKER_MEMBERS=$(getent group docker | cut -d: -f4)
[[ -n "$DOCKER_MEMBERS" ]] && warn "Users in the docker group are root-equivalent: $DOCKER_MEMBERS" \
  || pass "docker group is empty"

DAEMON_JSON=/etc/docker/daemon.json
declare -A DAEMON_WANT=(
  ["no-new-privileges: true"]='"no-new-privileges": *true'
  ["icc: false"]='"icc": *false'
  ["live-restore: true"]='"live-restore": *true'
  ["userns-remap"]='"userns-remap"'
)
for label in "${!DAEMON_WANT[@]}"; do
  if [[ -f "$DAEMON_JSON" ]] && grep -Eq "${DAEMON_WANT[$label]}" "$DAEMON_JSON"; then
    pass "daemon.json sets $label"
  else
    warn "daemon.json does not set $label"
  fi
done

if command -v iptables >/dev/null && iptables -S DOCKER-USER 2>/dev/null | grep -q 3306; then
  pass "DOCKER-USER chain has a rule for 3306"
else
  warn "No DOCKER-USER firewall rule for 3306; published ports bypass the host's INPUT rules (iptables/awall)"
fi

# ======================================================================
if (( APPLY )); then
  section "Applying fixes"

  mkdir -p "$BACKUP_DIR" && chmod 700 "$BACKUP_DIR"
  STAMP="$BACKUP_DIR/${CONTAINER}-$(date +%Y%m%d-%H%M%S)"
  docker inspect "$CONTAINER" > "$STAMP.inspect.json"
  docker exec -e MYSQL_PWD="$ROOT_PW" "$CONTAINER" "$DUMP" -uroot --all-databases \
      --single-transaction --routines --events --triggers > "$STAMP.sql" \
    || die "backup failed; nothing was changed"
  chmod 600 "$STAMP".*
  info "Backup written: $STAMP.sql (and .inspect.json)"

  for s in "${FIX_SQL[@]}"; do
    if sql "$s" 2>/dev/null; then fixed "$s"; else fail "Could not run: $s"; fi
  done
  (( ${#FIX_SQL[@]} )) && sql "FLUSH PRIVILEGES;"

  if (( ${#CNF[@]} )); then
    { echo "# Written by mariadb-docker-harden.sh on $(date '+%Y-%m-%dT%H:%M:%S%z')"
      echo "[mysqld]"
      printf '%s\n' "${CNF[@]}"; } > "./$CNF_NAME"
    chmod 644 "./$CNF_NAME"
    if (( NEED_FILES_DIR )); then
      docker exec "$CONTAINER" sh -c 'mkdir -p /var/lib/mysql-files && chown mysql:mysql /var/lib/mysql-files && chmod 750 /var/lib/mysql-files'
    fi
    docker cp "./$CNF_NAME" "$CONTAINER:/etc/mysql/conf.d/$CNF_NAME"
    docker exec "$CONTAINER" chmod 644 "/etc/mysql/conf.d/$CNF_NAME"
    info "Restarting $CONTAINER to load $CNF_NAME"
    docker restart "$CONTAINER" >/dev/null

    ready() {
      for _ in $(seq 1 30); do
        docker exec -e MYSQL_PWD="$ROOT_PW" "$CONTAINER" "$ADMIN" -uroot ping >/dev/null 2>&1 && return 0
        sleep 2
      done
      return 1
    }
    if ready; then
      fixed "Server options written to /etc/mysql/conf.d/$CNF_NAME: $(printf '%s; ' "${CNF[@]}")"
    else
      fail "MariaDB did not come back; rolling back $CNF_NAME"
      echo "# disabled by rollback" > "./$CNF_NAME.rollback"
      docker cp "./$CNF_NAME.rollback" "$CONTAINER:/etc/mysql/conf.d/$CNF_NAME"
      docker restart "$CONTAINER" >/dev/null
      ready || die "still not up; check: docker logs $CONTAINER"
      info "Rolled back; see docker logs $CONTAINER for the rejected option"
    fi
  fi

  if (( ${#UPD[@]} )); then
    if docker update "${UPD[@]}" "$CONTAINER" >/dev/null; then
      fixed "docker update ${UPD[*]}"
    else
      fail "docker update ${UPD[*]} failed"
    fi
  fi
fi

# ======================================================================
section "Recommended hardened container (needs recreate)"
BIND_IP=${BIND_IP:-$(ip -4 -o addr show scope global 2>/dev/null | awk '{sub(/\/.*/, "", $4); print $4; exit}')}
cat <<EOF
These settings cannot be changed on a running container. After checking the
backup, recreate it with:

  docker stop $CONTAINER && docker rename $CONTAINER ${CONTAINER}-old
  docker run -d --name $CONTAINER \\
    --user mysql \\
    --cap-drop ALL \\
    --security-opt no-new-privileges:true \\
    --read-only \\
    --tmpfs /tmp \\
    --tmpfs /run/mysqld:uid=$MYSQL_UID,gid=$MYSQL_UID,mode=0755 \\
    --tmpfs /var/lib/mysql-files:uid=$MYSQL_UID,gid=$MYSQL_UID,mode=0750 \\
    --memory $MEMORY --memory-swap $MEMORY --pids-limit $PIDS_LIMIT \\
    --restart unless-stopped \\
    -p ${BIND_IP:-127.0.0.1}:3306:3306 \\
    -v $DATA_VOL:/var/lib/mysql \\
    -v "\$PWD/$CNF_NAME":/etc/mysql/conf.d/$CNF_NAME:ro \\
    -e MARIADB_AUTO_UPGRADE=1 \\
    $TARGET_IMAGE

Notes:
  - No password variables: the data directory is already initialised, so the
    root password lives in the database. For a fresh setup use
    MARIADB_ROOT_PASSWORD_FILE with a file mounted read-only.
  - MARIADB_AUTO_UPGRADE upgrades the system tables when the image version
    changes. Test a big jump (e.g. 10.3 -> 11.4) on a copy first.
  - Once it works: docker rm ${CONTAINER}-old (without -v, to keep the data).
  - Restrict who can reach 3306, e.g.:
      iptables -I DOCKER-USER -p tcp --dport 3306 ! -s <client-subnet> -j DROP
EOF

# ======================================================================
section "Summary"
echo "${G}PASS: $PASS${N}  ${Y}WARN: $WARN${N}  ${R}FAIL: $FAIL${N}  ${G}FIXED: $FIXED${N}"
if (( ! APPLY )); then
  QUEUED=$(( ${#FIX_SQL[@]} + ${#CNF[@]} + (${#UPD[@]} > 0) ))
  echo "Audit only, nothing changed. $QUEUED item(s) can be fixed automatically with --apply."
fi
(( FAIL == 0 ))
