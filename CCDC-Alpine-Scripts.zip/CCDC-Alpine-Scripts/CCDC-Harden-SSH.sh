#!/bin/sh
# --- Alpine guard (POSIX sh until the second "fi") -----------------------------
# This is the Alpine Linux version. It needs bash: if this was started with
# BusyBox sh (ash), bash is installed with apk when missing and the script
# re-runs itself under it.
if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi
if [ -z "${BASH_VERSION:-}" ]; then
    if ! command -v bash >/dev/null 2>&1; then
        echo "[*] bash is not installed; installing it with apk..." >&2
        apk add --no-cache bash >/dev/null 2>&1 || {
            echo "[!] Could not install bash (no repository access?). Install it first: apk add bash" >&2
            exit 1
        }
    fi
    exec bash "$0" "$@"
fi
# --------------------------------------------------------------------------------
# CCDC-Harden-SSH.sh - Alpine Linux version (OpenRC, BusyBox, OpenSSH with or without PAM)

if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root. Try: doas sh $0  (or su -c 'sh $0')" >&2
  exit 1
fi

set -uo pipefail
shopt -s nullglob

ASSUME_YES=false
KEEP_SFTP=false
SET_IMMUTABLE=true

SCRIPT_NAME=harden-ssh.sh
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_ROOT=/root/ssh-hardening-backups
BUTTERFARM=/root/butterfarm

usage() {
  cat <<EOF
Usage: sh $SCRIPT_NAME [options]   (as root)

  -y, --yes              Don't ask for confirmation
      --keep-sftp        Keep the SFTP subsystem (scp from OpenSSH 9+ clients
                         needs it; 'scp -O' works without it)
      --no-immutable     Don't chattr +i sshd_config and /etc/shadow
                         (chattr comes from e2fsprogs-extra; it's installed
                         with apk if missing)
  -h, --help             Show this help
EOF
}

while (( $# )); do
  case $1 in
    -y|--yes)           ASSUME_YES=true ;;
    --keep-sftp)        KEEP_SFTP=true ;;
    --no-immutable)     SET_IMMUTABLE=false ;;
    -h|--help)          usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

BACKUP_DIR="" LOG="" WORK_DIR=""
DISTRO_FAMILY="" DISTRO_NAME="" SVC="" INIT="" STARTUP_FILE="" ADMIN_GROUPS=""
SSHD_BIN="" SSH_BIN="" SSH_VER=""
PORTS_BEFORE="" PORTS_AFTER="" CONFIG_TEST_OUTPUT=""
KEEP_LINES=() FINDINGS=() WARNINGS=() SERVICE_QUARANTINED=() ADMINS=()
SSHD_HAS_PAM=true

if [[ -t 1 ]]; then
  C_RED=$'\e[1;31m' C_GRN=$'\e[1;32m' C_YEL=$'\e[1;33m' C_BLU=$'\e[1;34m'
  C_MAG=$'\e[1;35m' C_BLD=$'\e[1m' C_RST=$'\e[0m'
else
  C_RED="" C_GRN="" C_YEL="" C_BLU="" C_MAG="" C_BLD="" C_RST=""
fi

_log() {
  local color=$1 tag=$2; shift 2
  printf '%s[%s]%s %s\n' "$color" "$tag" "$C_RST" "$*"
  if [[ -n $LOG ]]; then printf '[%s] %s\n' "$tag" "$*" >>"$LOG"; fi
}
info()    { _log "$C_BLU" "INFO" "$@"; }
ok()      { _log "$C_GRN" " OK " "$@"; }
warn()    { _log "$C_YEL" "WARN" "$@"; WARNINGS+=("$*"); }
finding() { _log "$C_MAG" "FLAG" "$@"; FINDINGS+=("$*"); }
die()     { _log "$C_RED" "FAIL" "$@"; exit 1; }

step() {
  printf '\n%s==> %s%s\n' "$C_BLD" "$*" "$C_RST"
  if [[ -n $LOG ]]; then printf '\n==> %s\n' "$*" >>"$LOG"; fi
}

show() {
  [[ -n ${1:-} ]] || return 0
  printf '%s\n' "$1" | sed 's/^/        /'
  if [[ -n $LOG ]]; then printf '%s\n' "$1" | sed 's/^/        /' >>"$LOG"; fi
}

ask() {
  local reply=""
  if [[ -t 0 ]]; then
    read -r -p "$1 [y/N] " reply
  elif { exec 3</dev/tty; } 2>/dev/null; then
    read -r -u 3 -p "$1 [y/N] " reply
    exec 3<&-
  else
    die "No terminal to confirm on. Re-run with --yes."
  fi
  [[ $reply =~ ^[Yy]([Ee][Ss])?$ ]]
}

have() { command -v "$1" >/dev/null 2>&1; }

# cp -a --parents SRC DESTROOT, done portably (BusyBox cp may lack --parents)
cp_parents() {
  local src=$1 root=${2%/} d
  d="$root$(dirname -- "$src")"
  mkdir -p -- "$d" && cp -a -- "$src" "$d/"
}

# Print stdin lines joined by $1 on one line (instead of paste, which BusyBox may lack)
join_lines() { awk -v s="$1" 'NR > 1 { printf "%s", s } { printf "%s", $0 } END { if (NR) print "" }'; }

# Print stdin in reverse line order (instead of tac)
reverse_lines() { awk '{ a[NR] = $0 } END { for (i = NR; i > 0; i--) print a[i] }'; }

# chattr ships in e2fsprogs-extra on Alpine; install it only when we need it
ensure_chattr() {
  have chattr && return 0
  info "chattr not found; installing e2fsprogs-extra with apk"
  apk add --no-cache e2fsprogs-extra >/dev/null 2>&1
  have chattr
}

svc_state() { rc-service "$1" status 2>/dev/null | sed -n 's/.*status: *//p' | head -n1; }

unlock() {
  have chattr || return 0
  local p
  for p in "$@"; do
    if [[ -d $p && ! -L $p ]]; then chattr -R -ia "$p" 2>/dev/null
    elif [[ -e $p && ! -L $p ]]; then chattr -ia "$p" 2>/dev/null
    fi
  done
  return 0
}

relabel() {
  have restorecon || return 0
  restorecon -F "$@" 2>/dev/null
  return 0
}

backup() {
  local p=$1
  grep -qxE "[RN] $(printf '%s' "$p" | sed 's/[]\/$*.^[]/\\&/g')" "$BACKUP_DIR/manifest" 2>/dev/null && return 0
  if [[ -e $p || -L $p ]]; then
    if cp_parents "$p" "$BACKUP_DIR/files" 2>/dev/null; then
      echo "R $p" >>"$BACKUP_DIR/manifest"
    else
      warn "Could not back up $p"
      return 1
    fi
  else
    echo "N $p" >>"$BACKUP_DIR/manifest"
  fi
}

quarantine() {
  local p=$1
  [[ -e $p || -L $p ]] || return 1
  unlock "$p"
  if ! cp_parents "$p" "$BACKUP_DIR/quarantine" 2>/dev/null; then
    warn "Could not copy $p to quarantine, leaving it in place"
    return 1
  fi
  rm -rf -- "$p" || { warn "Could not remove $p"; return 1; }
}

install_file() {
  local src=$1 dest=$2 mode=$3
  unlock "$dest"
  backup "$dest" || return 1
  [[ -L $dest ]] && rm -f -- "$dest"
  cp -- "$src" "$dest" || return 1
  chown root:root "$dest"
  chmod "$mode" "$dest"
  relabel "$dest"
}

restore_manifest() {
  local kind path
  while read -r kind path; do
    [[ -n ${path:-} ]] || continue
    unlock "$path"
    rm -rf -- "$path"
    [[ $kind == R ]] && cp -a -- "$BACKUP_DIR/files$path" "$path"
  done < <(reverse_lines < "$BACKUP_DIR/manifest")
  : >"$BACKUP_DIR/manifest"
  relabel -R /etc/ssh
}

osr() { sed -n "s/^$1=//p" /etc/os-release 2>/dev/null | tr -d '"' | head -n1; }

detect_platform() {
  DISTRO_FAMILY=alpine
  DISTRO_NAME=$(osr PRETTY_NAME)
  [[ -n $DISTRO_NAME ]] || DISTRO_NAME="Alpine Linux $(cat /etc/alpine-release 2>/dev/null)"
  SVC=sshd STARTUP_FILE=/etc/conf.d/sshd ADMIN_GROUPS="wheel sudo admin"
  INIT=openrc

  # The OpenRC script runs ${SSHD_BINARY:-/usr/sbin/sshd}; the PAM build
  # (openssh-server-pam) may be selected that way. Only trust stock paths.
  local b=""
  [[ -f $STARTUP_FILE ]] && b=$(sed -n 's/^[[:space:]]*SSHD_BINARY=["'"'"']\{0,1\}\([^"'"'"' ]*\).*/\1/p' "$STARTUP_FILE" | tail -n1)
  case $b in
    /usr/sbin/sshd|/usr/sbin/sshd.pam) [[ -x $b ]] && SSHD_BIN=$b ;;
  esac
  [[ -z $SSHD_BIN && -x /usr/sbin/sshd ]] && SSHD_BIN=/usr/sbin/sshd
  [[ -z $SSHD_BIN ]] && SSHD_BIN=$(command -v sshd 2>/dev/null || true)
  [[ -n $SSHD_BIN ]] || die "sshd isn't installed. Install it first: apk add openssh-server && rc-update add sshd default"
  [[ -x /etc/init.d/$SVC ]] || warn "/etc/init.d/$SVC is missing (apk add openssh-server-openrc, or apk fix openssh-server)"
  SSH_BIN=$(command -v ssh 2>/dev/null || echo /usr/bin/ssh)
  SSH_VER=$("$SSH_BIN" -V 2>&1 | grep -oE 'OpenSSH_[0-9]+\.[0-9]+' | head -n1)
  [[ -z $SSH_VER ]] && SSH_VER=$("$SSHD_BIN" -V 2>&1 | grep -oE 'OpenSSH_[0-9]+\.[0-9]+' | head -n1)
  SSH_VER=${SSH_VER#OpenSSH_}

  info "Distro:  $DISTRO_NAME ($DISTRO_FAMILY)"
  info "OpenSSH: ${SSH_VER:-unknown}, binary $SSHD_BIN, service '$SVC' ($INIT)"
}

# Alpine ships sshd without PAM by default (openssh-server) and with it
# (openssh-server-pam). A non-PAM sshd reports "Unsupported option UsePAM".
detect_sshd_pam() {
  local t="$WORK_DIR/pamtest" out lib f
  printf 'UsePAM yes\n' >"$t"
  out=$("$SSHD_BIN" -t -f "$t" 2>&1)
  rm -f -- "$t"
  if [[ ${out,,} == *"unsupported option"*usepam* || ${out,,} == *"bad configuration option"*usepam* ]]; then
    SSHD_HAS_PAM=false
  else
    SSHD_HAS_PAM=true
    # Double-check by linkage (sshd or, on OpenSSH 9.8+, sshd-session)
    lib=""
    for f in "$SSHD_BIN" /usr/lib/ssh/sshd-session /usr/lib/ssh/sshd-session.pam /usr/libexec/sshd-session; do
      [[ -x $f ]] && lib+=$(ldd "$f" 2>/dev/null)
    done
    [[ -n $lib && $lib != *libpam* ]] && SSHD_HAS_PAM=false
  fi
  if $SSHD_HAS_PAM; then
    info "This sshd is built with PAM (UsePAM yes will be set)"
  else
    info "This sshd has no PAM support (stock Alpine openssh-server); passwords are checked against /etc/shadow directly"
  fi
}

ssh_version_at_least() {
  local maj=${SSH_VER%%.*} min=${SSH_VER#*.}
  [[ $maj =~ ^[0-9]+$ && $min =~ ^[0-9]+$ ]] || return 1
  (( maj > $1 || (maj == $1 && min >= $2) ))
}

check_access() {
  step "Pre-flight: making sure you won't be locked out"
  local uid_min=1000 v user uid shell hash groups g sudo_out is_admin others=() doas_ids=""
  if have doas; then
    doas_ids=$(grep -hE '^[[:space:]]*permit' /etc/doas.conf /etc/doas.d/*.conf 2>/dev/null | awk '{
      inb = 0
      for (i = 2; i <= NF; i++) {
        t = $i
        if (t == "{") { inb = 1; continue }
        if (inb) { if (t == "}") inb = 0; continue }
        if (t ~ /^(nopass|nolog|persist|keepenv|setenv)$/) continue
        print t; break
      } }')
  fi
  if [[ -r /etc/login.defs ]]; then
    v=$(awk '$1=="UID_MIN"{print $2}' /etc/login.defs)
    [[ $v =~ ^[0-9]+$ ]] && uid_min=$v
  fi

  while IFS=: read -r user _ uid _ _ _ shell; do
    [[ $uid =~ ^[0-9]+$ ]] || continue
    (( uid >= uid_min && uid < 65534 )) || continue
    case $shell in */nologin|*/false|*/sync|"") continue ;; esac
    hash=$(awk -F: -v u="$user" '$1==u{print $2; exit}' /etc/shadow 2>/dev/null)
    [[ -n $hash && ${hash:0:1} != '!' && ${hash:0:1} != '*' ]] || continue

    is_admin=false
    if have sudo; then
      if have timeout; then sudo_out=$(timeout 5 sudo -n -l -U "$user" 2>/dev/null)
      else sudo_out=$(sudo -n -l -U "$user" 2>/dev/null); fi
      [[ $sudo_out == *"may run the following"* ]] && is_admin=true
    fi
    groups=" $(id -nG "$user" 2>/dev/null) "
    # doas (Alpine's usual sudo replacement): "permit [opts] user|:group ..."
    if have doas; then
      for g in $doas_ids; do
        if [[ $g == :* ]]; then [[ $groups == *" ${g#:} "* ]] && is_admin=true
        else [[ $g == "$user" ]] && is_admin=true; fi
      done
    fi
    if $is_admin; then ADMINS+=("$user"); else others+=("$user"); fi
  done < <(getent passwd)

  if (( ${#ADMINS[@]} )); then
    ok "Accounts that can still SSH in and get root via doas/sudo: ${ADMINS[*]}"
  elif (( ${#others[@]} )); then
    warn "No doas/sudo-capable account has a password. These can SSH in but need 'su' and the root password: ${others[*]}"
  else
    warn "No non-root account has a password and a login shell. Once root login is off, NOBODY can SSH in. Make one first (adduser -D NAME && addgroup NAME wheel && passwd NAME; for doas: apk add doas && echo 'permit persist :wheel' > /etc/doas.d/wheel.conf) unless you have console access."
  fi

  if [[ -n ${SSH_CONNECTION:-} && -z ${SUDO_USER:-} ]]; then
    warn "You're logged in directly as root over SSH. This session stays open, but new root SSH logins will be refused."
  fi
}

confirm_plan() {
  local lock_note=""
  $SET_IMMUTABLE || lock_note=" (skipped, --no-immutable)"
  step "Plan"
  cat <<EOF
  On this host this will:
    - turn off root SSH login and SSH key login (passwords only)
    - replace sshd_config, remove /etc/ssh/sshd_config.d, restart $SVC
    - replace /etc/ssh/ssh_config with the hardened client config
    - remove nullok from PAM (only if PAM is installed)
    - quarantine authorized_keys, ~/.ssh/rc, /etc/ssh/sshrc and nologin files
    - chattr +i sshd_config and /etc/shadow$lock_note
    - check /etc/conf.d/sshd and the OpenRC init script for overrides
    - save locked copies of sshd_config and ssh_config to $BUTTERFARM
  Everything it changes is backed up first, with a restore.sh to undo it.
EOF
  $ASSUME_YES && return 0
  ask "Continue?" || die "Aborted. Nothing was changed."
}

setup_backup() {
  step "Backup"
  BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"
  mkdir -p "$BACKUP_DIR"/files "$BACKUP_DIR"/quarantine "$BACKUP_DIR"/snapshot \
    || die "Can't create $BACKUP_DIR"
  WORK_DIR=$(mktemp -d /etc/ssh/.harden-ssh.XXXXXX) || die "Can't create a work dir in /etc/ssh"
  trap 'rm -rf -- "$WORK_DIR"' EXIT
  chmod 700 "$BACKUP_ROOT" "$BACKUP_DIR"
  : >"$BACKUP_DIR/manifest"
  LOG="$BACKUP_DIR/harden-ssh.log"

  local p
  for p in /etc/ssh /etc/pam.d "$STARTUP_FILE"; do
    [[ -e $p ]] && cp_parents "$p" "$BACKUP_DIR/snapshot" 2>/dev/null
  done
  write_restore_script
  ok "Backups, log and restore.sh: $BACKUP_DIR"
}

write_restore_script() {
  {
    echo '#!/bin/sh'
    echo "# Undo $SCRIPT_NAME run $TIMESTAMP (Alpine/OpenRC). Run as root: sh $BACKUP_DIR/restore.sh"
    echo "SSHD_BIN='$SSHD_BIN'"
    echo "SVC='$SVC'"
    cat <<'EOF'
set -u
[ "$(id -u)" -eq 0 ] || { echo "Run as root." >&2; exit 1; }
DIR=$(cd "$(dirname "$0")" && pwd)
command -v chattr >/dev/null && chattr -ia /etc/ssh/sshd_config /etc/shadow 2>/dev/null

awk '{ a[NR] = $0 } END { for (i = NR; i > 0; i--) print a[i] }' "$DIR/manifest" | while read -r kind path; do
  [ -n "${path:-}" ] || continue
  command -v chattr >/dev/null && chattr -R -ia "$path" 2>/dev/null
  rm -rf -- "$path"
  if [ "$kind" = R ]; then
    cp -a -- "$DIR/files$path" "$path" && echo "restored $path"
  else
    echo "removed  $path (it didn't exist before)"
  fi
done

if "$SSHD_BIN" -t; then
  rc-service "$SVC" restart && echo "sshd restarted on the original config."
else
  echo "sshd -t fails on the restored config. Fix it before restarting sshd." >&2
  exit 1
fi
EOF
  } >"$BACKUP_DIR/restore.sh"
  chmod 700 "$BACKUP_DIR/restore.sh"
}

config_test() {
  local kind=$1 f=$2 out
  if [[ $kind == server ]]; then
    "$SSHD_BIN" -t -f "$f" 2>&1
  elif ssh_version_at_least 6 8; then
    "$SSH_BIN" -F "$f" -G localhost 2>&1 >/dev/null
  else
    out=$("$SSH_BIN" -F "$f" -o BatchMode=yes -o ConnectTimeout=2 -p 1 127.0.0.1 true 2>&1 >/dev/null)
    printf '%s\n' "$out"
    [[ ! $out =~ line\ [0-9]+ ]]
  fi
}

make_compatible() {
  local kind=$1 f=$2 out rc n directive i
  local protected='^(permitrootlogin|passwordauthentication|permitemptypasswords|usepam|port|listenaddress)$'
  for (( i = 0; i < 15; i++ )); do
    out=$(config_test "$kind" "$f"); rc=$?

    n=$(grep -F -- "$f" <<<"$out" | grep -oE 'line [0-9]+' | head -n1 | grep -oE '[0-9]+')
    if [[ -z $n && $out == *"AuthorizedKeysCommand set without"* ]]; then
      n=$(grep -niE '^[[:space:]]*authorizedkeyscommand[[:space:]]' "$f" | head -n1 | cut -d: -f1)
    fi
    if [[ -z $n ]]; then
      CONFIG_TEST_OUTPUT=$out
      (( rc == 0 ))
      return
    fi

    directive=$(sed -n "${n}p" "$f" | awk '{print $1}')
    if [[ -z $directive || $directive == \#* || ${directive,,} =~ $protected ]]; then
      CONFIG_TEST_OUTPUT=$out
      return 1
    fi
    sed -i "${n}s/^/# not supported by this OpenSSH: /" "$f"
    warn "This OpenSSH doesn't support '$directive' in the $kind config; commented it out"
    if [[ ${directive,,} == disableforwarding ]]; then
      printf '%s\n' "" \
        "AllowTcpForwarding no" "AllowAgentForwarding no" "AllowStreamLocalForwarding no" \
        "X11Forwarding no" "GatewayPorts no" >>"$f"
    fi
  done
  CONFIG_TEST_OUTPUT=$out
  return 1
}

effective_ports() {
  "$SSHD_BIN" -T 2>/dev/null | awk '$1=="port"{print $2}' | sort -un | join_lines ,
}

audit_sshd_file() {
  local f=$1 hits
  hits=$(
    {
      grep -inE '^[[:space:]]*(match|forcecommand|authorizedkeyscommand|authorizedprincipals(file|command)|trustedusercakeys|permitemptypasswords[[:space:]]+yes|permitrootlogin[[:space:]]+yes|permituserenvironment[[:space:]]+yes|permittunnel[[:space:]]+(yes|point-to-point|ethernet)|gatewayports[[:space:]]+(yes|clientspecified)|hostbasedauthentication[[:space:]]+yes|ignorerhosts[[:space:]]+no|strictmodes[[:space:]]+no)([[:space:]]|$)' "$f"
      grep -inE '^[[:space:]]*include[[:space:]]' "$f" \
        | grep -viE 'include[[:space:]]+/etc/ssh/sshd_config\.d/\*\.conf[[:space:]]*$'
      grep -inE '^[[:space:]]*authorizedkeysfile[[:space:]]' "$f" \
        | grep -viE 'authorizedkeysfile([[:space:]]+(%h/)?\.ssh/authorized_keys2?)+[[:space:]]*$|authorizedkeysfile[[:space:]]+none[[:space:]]*$'
    } 2>/dev/null | grep -viE 'authorizedkeyscommand[[:space:]]+none[[:space:]]*$' | sort -t: -k1,1n -u
  )
  if [[ -n $hits ]]; then
    finding "$f had settings worth a look (none of them survive in the new config):"
    show "$hits"
  fi
}

fix_hostkeys() {
  local keys=(/etc/ssh/ssh_host_*_key) k perm owner group
  if (( ${#keys[@]} == 0 )); then
    finding "No SSH host keys found (sshd can't start without them); generating new ones"
    ssh-keygen -A >/dev/null 2>&1 || warn "ssh-keygen -A failed"
    relabel -R /etc/ssh
    keys=(/etc/ssh/ssh_host_*_key)
    (( ${#keys[@]} )) || { warn "Still no host keys; sshd won't start until you run: ssh-keygen -A"; return 0; }
  fi
  for k in "${keys[@]}"; do
    read -r perm owner group < <(stat -c '%a %U %G' "$k")
    if [[ $owner != root ]] || (( 8#$perm & 8#027 )) \
       || { (( 8#$perm & 8#040 )) && [[ $group != root && $group != ssh_keys ]]; }; then
      finding "Host key $k had loose permissions ($perm $owner:$group); set to 600 root:root"
      unlock "$k"
      chown root:root "$k"
      chmod 600 "$k"
    fi
    [[ -f $k.pub ]] && { chown root:root "$k.pub"; chmod 644 "$k.pub"; }
  done
  ok "Host keys checked (${#keys[@]} found)"
}

build_sshd_config() {
  local out=$1
  {
    if (( ${#KEEP_LINES[@]} )); then
      printf '%s\n' "${KEEP_LINES[@]}"
      echo
    fi
    cat <<'EOF'
PermitRootLogin no

PasswordAuthentication yes
AuthenticationMethods password
PubkeyAuthentication no
AuthorizedKeysFile none
AuthorizedKeysCommand none
GSSAPIAuthentication no
HostbasedAuthentication no
IgnoreRhosts yes
PermitEmptyPasswords no
EOF
    # UsePAM only exists in PAM builds (openssh-server-pam)
    if $SSHD_HAS_PAM; then echo "UsePAM yes"; fi
    cat <<'EOF'

MaxAuthTries 3
LoginGraceTime 30

DisableForwarding yes
PermitTunnel no
PermitUserEnvironment no
PermitUserRC no
EOF
    if $KEEP_SFTP; then
      echo
      echo "Subsystem sftp internal-sftp"
    fi
  } >"$out"
}

remove_dropins() {
  local d=/etc/ssh/sshd_config.d f name
  local stock='^(50-redhat|50-cloud-init|60-cloudimg-settings|40-redhat-crypto-policies)\.conf$'
  if [[ ! -e $d && ! -L $d ]]; then
    ok "No sshd_config.d drop-in directory"
    return 0
  fi
  for f in "$d"/* "$d"/.[!.]*; do
    name=${f##*/}
    if [[ $name =~ $stock ]]; then info "Drop-in $name is a distro default"
    else finding "Drop-in $f is not a distro default"; fi
    [[ -f $f ]] && audit_sshd_file "$f"
  done
  unlock "$d"
  backup "$d" || return 1
  if rm -rf -- "$d"; then
    ok "Removed $d (nothing includes it any more)"
  else
    warn "Could not remove $d. The new sshd_config doesn't include it, so it's ignored anyway."
  fi
}

sanitize_startup_options() {
  local f=$STARTUP_FILE hits n code bin
  if [[ ! -f $f ]]; then
    ok "No $f"
    return 0
  fi
  # Settings the OpenRC sshd script turns into sshd arguments: extra options
  # (-f/-p/-o), a different config file or directory, or a replacement command.
  hits=$(grep -nE '^[[:space:]]*(export[[:space:]]+)?(SSHD_OPTS|SSHD_CONFIG|SSHD_CONFDIR|OPTIONS|command|command_args|command_args_background|command_user|command_background)=' "$f" \
         | grep -vE "=[[:space:]]*(\"\"|'')?[[:space:]]*$")
  # SSHD_BINARY is fine when it names the stock binary or its PAM build
  bin=$(grep -nE '^[[:space:]]*(export[[:space:]]+)?SSHD_BINARY=' "$f" \
        | grep -vE "SSHD_BINARY=[\"']?/usr/sbin/sshd(\.pam)?[\"']?[[:space:]]*$" \
        | grep -vE "=[[:space:]]*(\"\"|'')?[[:space:]]*$")
  [[ -n $bin ]] && hits=$(printf '%s\n%s\n' "$hits" "$bin" | grep -v '^$' | sort -t: -k1,1n)

  # conf.d files are sourced as shell by openrc-run: code here runs as root at every start
  code=$(grep -nE '\(\)|`|\$\(|^[[:space:]]*(start_pre|start_post|stop_pre|stop_post|depend)[[:space:]]*\(|^[[:space:]]*[a-z_]+[[:space:]]+[^=]*$' "$f" \
         | grep -vE '^[0-9]+:[[:space:]]*(#|$)')
  if [[ -n $code ]]; then
    finding "$f contains shell code, not just settings (it is sourced as root whenever sshd starts):"
    show "$code"
    info "Not changed automatically; remove anything you didn't put there, then: rc-service sshd restart"
  fi

  if [[ -z $hits ]]; then
    ok "$f passes no extra options to sshd"
    return 0
  fi
  finding "$f changes how sshd starts (these override sshd_config):"
  show "$hits"
  unlock "$f"
  backup "$f" || return 1
  for n in $(cut -d: -f1 <<<"$hits"); do
    sed -i "${n}s/^/# disabled by $SCRIPT_NAME: /" "$f"
  done
  ok "Commented those lines out"
}

# OpenRC counterpart of the systemd unit/drop-in checks: is the init script
# still the packaged one, and does anything else start an sshd?
check_service_overrides() {
  local init=/etc/init.d/$SVC out pkg others f
  if [[ ! -f $init ]]; then
    finding "$init is missing; sshd can't be managed by OpenRC (apk fix openssh-server-openrc)"
    return 0
  fi
  if have apk; then
    out=$(apk audit --system /etc/init.d 2>/dev/null | awk -v f="etc/init.d/$SVC" '$2 == f || $2 == "/" f')
    if [[ -n $out ]]; then
      finding "$init differs from the copy apk installed ($out); it may start a different sshd or config:"
      show "$(grep -nE '^[[:space:]]*(command|command_args|command_args_background|command_user|pidfile|SSHD_[A-Z_]*)=|start_pre|start_post' "$init")"
      pkg=$(apk info -W "$init" 2>/dev/null | awk '{print $NF}' | sed -E 's/-[0-9][^-]*-r[0-9]+$//')
      info "Put the packaged script back with: apk fix ${pkg:-openssh-server}"
    else
      ok "$init matches the apk package"
    fi
  fi

  # Other things that can start an extra sshd: init scripts, local.d, inittab, cron
  others=$(
    for f in /etc/init.d/* /etc/local.d/*.start /etc/inittab /etc/crontabs/* /etc/periodic/*/*; do
      [[ -f $f && $f != "$init" ]] || continue
      grep -qE '(/|[[:space:]]|^)sshd([[:space:]"'"'"';]|$)' "$f" 2>/dev/null \
        && grep -nE '(/|[[:space:]]|^)sshd([[:space:]"'"'"';]|$)' "$f" | grep -vE '^[0-9]+:[[:space:]]*#' | grep -vE '(need|use|after|before|want)[[:space:]]' | sed "s|^|$f:|"
    done)
  if [[ -n $others ]]; then
    finding "Other boot/cron entries mention sshd (a second, hidden sshd?):"
    show "$others"
  fi

  if [[ $(rc-update show default 2>/dev/null) != *" $SVC "* ]]; then
    : # handled in restart_sshd
  fi
  ok "Checked OpenRC overrides for $SVC"
}

service_status() {
  rc-service "$SVC" status 2>&1 | tail -n 5
  grep -h 'sshd' /var/log/messages /var/log/auth.log 2>/dev/null | tail -n 10
}

proc_args() { { tr '\0' ' ' <"/proc/$1/cmdline"; } 2>/dev/null; }

sshd_listeners() {
  local pid args
  for pid in $(pgrep -x sshd 2>/dev/null); do
    args=$(proc_args "$pid")
    [[ -n $args ]] || continue
    if [[ $args == *"[listener]"* || $args != "sshd: "* ]]; then echo "$pid"; fi
  done
}

svc_ctl() {
  rc-service "$SVC" "$1" >/dev/null 2>&1 || "/etc/init.d/$SVC" "$1" >/dev/null 2>&1
}

restart_sshd() {
  local old pid args new=""
  if ! rc-update show default 2>/dev/null | grep -qE "^[[:space:]]*$SVC[[:space:]]"; then
    finding "$SVC wasn't in the default runlevel (wouldn't start at boot); added it"
    rc-update add "$SVC" default >/dev/null 2>&1
  fi

  old=" $(sshd_listeners | join_lines ' ') "
  # A crashed service can't be stopped normally; zap resets OpenRC's state
  svc_ctl stop || { [[ $(svc_state "$SVC") == crashed ]] && rc-service "$SVC" zap >/dev/null 2>&1; }
  sleep 1
  for pid in $(sshd_listeners); do
    [[ $old == *" $pid "* ]] || continue
    args=$(proc_args "$pid")
    [[ -n $args ]] || continue
    finding "sshd PID $pid wasn't controlled by the $SVC service; killed it ($args)"
    kill "$pid" 2>/dev/null
    sleep 1
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
  done

  svc_ctl start || return 1
  sleep 1
  [[ $(svc_state "$SVC") == started ]] || return 1
  for pid in $(sshd_listeners); do
    [[ $old == *" $pid "* ]] || new=$pid
  done
  [[ -n $new ]]
}

rollback_sshd() {
  warn "Rolling back the sshd changes"
  restore_manifest
  local p
  for p in ${SERVICE_QUARANTINED[@]+"${SERVICE_QUARANTINED[@]}"}; do
    cp -a -- "$BACKUP_DIR/quarantine$p" "$p"
  done
  if "$SSHD_BIN" -t >/dev/null 2>&1 && restart_sshd; then
    ok "sshd is running on the original config again"
  else
    warn "sshd still isn't healthy after rollback. Check: $SSHD_BIN -t"
  fi
}

verify_effective() {
  local eff line key want got bad=0
  eff=$("$SSHD_BIN" -T 2>/dev/null) || { warn "sshd -T failed; couldn't double-check the live settings"; return; }
  info "Live settings according to sshd -T:"
  local want_lines=("permitrootlogin no" "passwordauthentication yes" "authenticationmethods password"
              "pubkeyauthentication no" "authorizedkeysfile none" "authorizedkeyscommand none"
              "gssapiauthentication no" "hostbasedauthentication no" "ignorerhosts yes"
              "permitemptypasswords no" "maxauthtries 3" "logingracetime 30"
              "disableforwarding yes" "permittunnel no" "permituserenvironment no" "permituserrc no")
  $SSHD_HAS_PAM && want_lines+=("usepam yes")
  for line in "${want_lines[@]}"; do
    key=${line%% *} want=${line#* }
    got=$(awk -v k="$key" '$1==k { $1=""; sub(/^ +/, ""); print; exit }' <<<"$eff")
    if [[ -z $got ]]; then
      show "$(printf '%-24s %s' "$key" "(not reported by this OpenSSH)")"
    elif [[ ${got,,} == "$want" ]]; then
      show "$(printf '%-24s %s' "$key" "$got")"
    else
      show "$(printf '%-24s %s   <-- expected %s' "$key" "$got" "$want")"
      bad=1
    fi
  done
  if (( bad )); then
    warn "Some live settings don't match the hardened config; something is overriding it"
  else
    ok "Live settings match the hardened config"
  fi
}

harden_sshd() {
  step "Inbound SSH: /etc/ssh/sshd_config"
  local cfg=/etc/ssh/sshd_config work="$WORK_DIR/sshd_config" line out

  # Privilege-separation directory sshd needs on Alpine
  [[ -d /var/empty ]] || { mkdir -p /var/empty; chmod 755 /var/empty; }
  PORTS_BEFORE=$(effective_ports)
  check_running_sshd "as found"

  if [[ -L $cfg ]]; then finding "$cfg was a symlink to $(readlink -f "$cfg"); it will be a real file again"; fi
  if [[ -f $cfg ]]; then audit_sshd_file "$cfg"; else finding "$cfg was missing"; fi

  KEEP_LINES=()
  if [[ -f $cfg ]]; then
    while IFS= read -r line; do KEEP_LINES+=("$line"); done < <(
      awk 'tolower($1)=="match"{exit} tolower($1)~/^(port|listenaddress|addressfamily)$/{print $1, $2}' "$cfg")
    (( ${#KEEP_LINES[@]} )) && info "Keeping from the old config: ${KEEP_LINES[*]}"
  fi

  fix_hostkeys
  detect_sshd_pam

  build_sshd_config "$work"
  if ! make_compatible server "$work"; then
    warn "The hardened config fails 'sshd -t':"
    show "$CONFIG_TEST_OUTPUT"
    die "sshd config was not changed."
  fi
  ok "New config passes sshd -t"

  remove_dropins
  install_file "$work" "$cfg" 600 || { rollback_sshd; die "Couldn't write $cfg; rolled back."; }
  ok "Wrote hardened $cfg"

  sanitize_startup_options
  check_service_overrides

  if ! out=$("$SSHD_BIN" -t 2>&1); then
    warn "sshd -t fails on the final config:"
    show "$out"
    rollback_sshd
    die "Rolled back. sshd was not restarted with the new config."
  fi
  show "$out"
  ok "sshd -t passed on the live config"

  if restart_sshd; then
    ok "$SVC restarted and running"
  else
    warn "$SVC didn't come back up with the new config:"
    show "$(service_status)"
    rollback_sshd
    die "Rolled back to the original sshd config."
  fi

  PORTS_AFTER=$(effective_ports)
  if [[ -n $PORTS_BEFORE && $PORTS_BEFORE != "$PORTS_AFTER" ]]; then
    warn "sshd port changed from $PORTS_BEFORE to $PORTS_AFTER (the old port came from a drop-in or startup option). Check the firewall and scoring."
  fi
  verify_effective
}

build_ssh_config() {
  local out=$1
  {
    cat <<'EOF'
Host *
    StrictHostKeyChecking ask
    UserKnownHostsFile ~/.ssh/known_hosts
    HashKnownHosts yes
    ForwardAgent no
    ForwardX11 no
    ForwardX11Trusted no
    ClearAllForwardings yes
    Tunnel no
    PermitLocalCommand no
    ProxyCommand none
    ProxyJump none
    ControlMaster no
    ControlPath none
    GSSAPIAuthentication no
    HostbasedAuthentication no
EOF
  } >"$out"
}

harden_ssh_client() {
  step "Outbound SSH: /etc/ssh/ssh_config"
  local work="$WORK_DIR/ssh_config"
  build_ssh_config "$work"
  if ! make_compatible client "$work"; then
    warn "The hardened ssh_config doesn't parse on this OpenSSH; left the old one in place:"
    show "$CONFIG_TEST_OUTPUT"
    return 0
  fi
  if install_file "$work" /etc/ssh/ssh_config 644; then
    ok "Wrote hardened /etc/ssh/ssh_config (/etc/ssh/ssh_config.d is no longer read)"
  else
    warn "Couldn't write /etc/ssh/ssh_config"
  fi
}

NULLOK_RE='^[^#]*[[:space:]]nullok'

strip_nullok() {
  local f
  f=$(readlink -f "$1")
  unlock "$f"
  backup "$f" || return 1
  sed -i -E 's/[[:space:]]nullok(_secure)?([[:space:]]|$)/\2/' "$f"
  relabel "$f"
  ! grep -qE "$NULLOK_RE" "$f"
}

fix_nullok() {
  step "PAM: removing nullok"
  local f left
  if [[ ! -d /etc/pam.d ]]; then
    ok "PAM isn't installed (stock Alpine); sshd checks /etc/shadow itself and PermitEmptyPasswords no refuses empty passwords"
    return 0
  fi
  $SSHD_HAS_PAM || info "sshd doesn't use PAM, but other PAM programs might; checking /etc/pam.d anyway"

  # Alpine's linux-pam puts the shared rules in base-auth; check every file
  while IFS= read -r f; do
    [[ -n $f ]] || continue
    [[ ${f##*/} == base-auth ]] || finding "nullok was in $f"
    if strip_nullok "$f"; then ok "Removed nullok from $f"; else warn "Couldn't remove nullok from $f"; fi
  done < <(grep -lE "$NULLOK_RE" /etc/pam.d/* 2>/dev/null)

  left=$(grep -nE "$NULLOK_RE" /etc/pam.d/* 2>/dev/null)
  if [[ -z $left ]]; then
    ok "No nullok left anywhere in /etc/pam.d"
  else
    warn "nullok is still present:"
    show "$left"
  fi
}

remove_persistence() {
  step "Removing SSH persistence and login blockers"
  local f home count found=false

  for f in /etc/nologin /run/nologin; do
    if [[ -e $f ]]; then
      quarantine "$f" && finding "Removed $f; it blocks every non-root login"
      found=true
    fi
  done

  if [[ -e /etc/ssh/sshrc ]]; then
    finding "/etc/ssh/sshrc runs for every SSH login (first lines below); quarantined"
    show "$(head -n 20 /etc/ssh/sshrc)"
    quarantine /etc/ssh/sshrc
    found=true
  fi

  while IFS= read -r home; do
    [[ -n $home && -d $home/.ssh ]] || continue
    for f in "$home/.ssh/authorized_keys" "$home/.ssh/authorized_keys2"; do
      [[ -e $f || -L $f ]] || continue
      count=$(grep -cvE '^[[:space:]]*(#|$)' "$f" 2>/dev/null)
      quarantine "$f" && finding "Quarantined $f (${count:-0} key(s)); key login is off anyway"
      found=true
    done
    f="$home/.ssh/rc"
    if [[ -e $f ]]; then
      finding "$f runs whenever that user logs in (first lines below); quarantined"
      show "$(head -n 20 "$f")"
      quarantine "$f"
      found=true
    fi
    if [[ -e $home/.ssh/environment ]]; then
      finding "$home/.ssh/environment exists (ignored now that PermitUserEnvironment is no)"
    fi
    if [[ -e $home/.ssh/config ]]; then
      info "$home/.ssh/config overrides the system ssh_config for that user; worth a look"
    fi
  done < <({ getent passwd | cut -d: -f6; echo /root; } | sort -u)

  $found || ok "No authorized_keys, rc scripts or nologin files found"
}

audit_packages() {
  local out
  have apk || return 0
  # apk audit compares files with the checksums apk recorded at install time:
  # U = changed, A = not from any package
  out=$(apk audit --system /usr/sbin /usr/bin /usr/lib/ssh /usr/libexec /etc/init.d 2>/dev/null \
        | grep -E '^[UAX] ' | grep -iE 'ssh')
  if [[ -n $out ]]; then
    finding "OpenSSH files differ from what apk installed (U = modified, A = not from any package; possible trojaned binary):"
    show "$out"
    info "Reinstall them from the repo with: apk fix --reinstall openssh openssh-server openssh-client-default openssh-keygen"
  else
    ok "sshd/ssh binaries and the init script match the installed packages (apk audit)"
  fi
}

check_running_sshd() {
  local when=${1:-now} pid args k keys bad listeners=()
  local crypto='^(ciphers|macs|kexalgorithms|gssapikexalgorithms|gssapikeyexchange|hostkeyalgorithms|pubkeyacceptedkeytypes|pubkeyacceptedalgorithms|casignaturealgorithms|hostbasedacceptedkeytypes|hostbasedacceptedalgorithms|requiredrsasize)$'
  for pid in $(sshd_listeners); do
    listeners+=("$pid")
    args=$(proc_args "$pid")
    bad=()
    [[ " $args " =~ [[:space:]]-f[[:space:]/] ]] && bad+=("-f (another config file)")
    [[ " $args " =~ [[:space:]]-p[[:space:]]?[0-9] ]] && bad+=("-p (extra port)")
    keys=$(grep -oE '(^|[[:space:]])-o[[:space:]]?[A-Za-z]+' <<<"$args" | sed -E 's/.*-o[[:space:]]?//')
    for k in $keys; do [[ ${k,,} =~ $crypto ]] || bad+=("-o $k"); done
    if (( ${#bad[@]} )); then
      finding "sshd PID $pid ($when) runs with ${bad[*]}: $args"
    fi
  done
  if (( ${#listeners[@]} > 1 )); then
    finding "${#listeners[@]} sshd listeners running ($when), PIDs ${listeners[*]}; there should be one"
  elif (( ${#listeners[@]} == 1 )); then
    ok "One sshd listener running (PID ${listeners[0]})"
  elif [[ $when == "as found" ]]; then
    info "No sshd listener was running when the script started (stopped, or waiting on ssh.socket)"
  else
    warn "No sshd listener is running"
  fi
}

audit_listeners() {
  local lines port extra=()
  if have ss; then
    lines=$(ss -tlnp 2>/dev/null | grep -E '"sshd')
  else
    # BusyBox netstat: proto recv send local foreign state PID/name
    lines=$(netstat -tlnp 2>/dev/null | awk '/LISTEN/ && /[0-9]+\/sshd/ {print $1, $2, $3, $4, $7}')
  fi
  if [[ -z $lines ]]; then
    warn "No listening socket owned by sshd found"
    return 0
  fi
  info "sshd is listening on:"
  show "$(awk '{print $4}' <<<"$lines" | sort -u)"
  for port in $(awk '{n=split($4,a,":"); print a[n]}' <<<"$lines" | sort -un); do
    [[ ",$PORTS_AFTER," == *",$port,"* ]] || extra+=("$port")
  done
  if (( ${#extra[@]} )); then
    finding "sshd is listening on port(s) not in sshd_config: ${extra[*]} (rogue sshd or socket override?)"
  fi
}

audit_accounts() {
  local uid0 empty
  uid0=$(awk -F: '$3==0 && $1!="root"{print $1}' /etc/passwd | join_lines ' ')
  if [[ -n $uid0 ]]; then
    finding "Accounts with UID 0 besides root: $uid0 (root-equivalent; PermitRootLogin no blocks them over SSH too)"
  fi
  empty=$(awk -F: '$2==""{print $1}' /etc/shadow 2>/dev/null | join_lines ' ')
  if [[ -n $empty ]]; then
    finding "Accounts with an EMPTY password: $empty. Without nullok they can't log in, but set a password or lock them (passwd -l NAME)"
  else
    ok "No accounts with empty passwords"
  fi
}

show_sessions() {
  local who_out conns
  who_out=$(who 2>/dev/null)
  if have ss; then
    conns=$(ss -tnp state established 2>/dev/null | grep -E '"sshd' | awk '{print $4}' \
            | sed -E 's/:[0-9]+$//' | sort | uniq -c | sort -rn)
  else
    conns=$(netstat -tnp 2>/dev/null | awk '$6 == "ESTABLISHED" && /[0-9]+\/sshd/ {print $5}' \
            | sed -E 's/:[0-9]+$//' | sort | uniq -c | sort -rn)
  fi
  info "Logged in right now (who):"
  show "${who_out:-(nobody)}"
  info "Open SSH connections by source address:"
  show "${conns:-(none)}"
  info "Anything you don't recognize may be red team. Kick a session: find its PID with 'ps -o pid,tty,user,args | grep pts/N', then kill -9 PID"
}

audit_system() {
  step "Audit"
  audit_packages
  check_running_sshd
  audit_listeners
  audit_accounts
  show_sessions
}

save_butterfarm() {
  step "Saving copies of the SSH configs to $BUTTERFARM"
  local f dest
  if [[ -L $BUTTERFARM || ( -e $BUTTERFARM && ! -d $BUTTERFARM ) ]]; then
    finding "$BUTTERFARM was a symlink or a file, not a directory; replaced it"
    unlock "$BUTTERFARM"
    rm -f -- "$BUTTERFARM"
  fi
  mkdir -p "$BUTTERFARM" || { warn "Can't create $BUTTERFARM"; return 0; }
  unlock "$BUTTERFARM"
  chown root:root "$BUTTERFARM"
  chmod 700 "$BUTTERFARM"
  for f in /etc/ssh/sshd_config /etc/ssh/ssh_config; do
    dest="$BUTTERFARM/${f##*/}"
    if [[ ! -f $f ]]; then
      warn "$f doesn't exist; nothing to save"
      continue
    fi
    unlock "$dest"
    [[ -L $dest ]] && rm -f -- "$dest"
    if ! cp -- "$f" "$dest"; then
      warn "Couldn't copy $f to $dest"
      continue
    fi
    chown root:root "$dest"
    chmod 600 "$dest"
    if { $SET_IMMUTABLE && ensure_chattr || have chattr; } && chattr +i "$dest" 2>/dev/null; then
      ok "Saved $f to $dest (root:root 600, chattr +i)"
    else
      warn "Saved $f to $dest, but chattr +i failed (filesystem may not support it)"
    fi
  done
}

lock_files() {
  step "Locking files (chattr +i)"
  if ! $SET_IMMUTABLE; then
    info "Skipped (--no-immutable)"
    return 0
  fi
  ensure_chattr || { warn "chattr isn't available (apk add e2fsprogs-extra)"; return 0; }
  local f
  for f in /etc/ssh/sshd_config /etc/shadow; do
    if chattr +i "$f" 2>/dev/null; then ok "chattr +i $f"
    else warn "chattr +i $f failed (filesystem may not support it)"; fi
  done
}

summary() {
  step "Summary"
  local i login_as="a doas/sudo user"
  (( ${#ADMINS[@]} )) && login_as=${ADMINS[*]}

  if (( ${#FINDINGS[@]} )); then
    printf '%s%d thing(s) found that may be red team activity:%s\n' "$C_MAG" "${#FINDINGS[@]}" "$C_RST"
    for i in "${FINDINGS[@]}"; do printf '  - %s\n' "${i%:}"; done
  else
    ok "Nothing suspicious found"
  fi
  if (( ${#WARNINGS[@]} )); then
    printf '\n%s%d warning(s):%s\n' "$C_YEL" "${#WARNINGS[@]}" "$C_RST"
    for i in "${WARNINGS[@]}"; do printf '  - %s\n' "${i%:}"; done
  fi

  cat <<EOF

${C_BLD}Remember${C_RST}
  - Root can't SSH in any more. Log in as $login_as and use doas/sudo/su.
  - SSH keys are off; it's passwords only. Make sure scored users have strong ones.
EOF
  if $SET_IMMUTABLE; then
    cat <<EOF
  - /etc/shadow is immutable, so passwd/chpasswd/adduser will fail until you unlock it:
        chattr -i /etc/shadow ; passwd USER ; chattr +i /etc/shadow
  - sshd_config is immutable too. To edit it:
        chattr -i /etc/ssh/sshd_config ; (edit) ; sshd -t ; chattr +i /etc/ssh/sshd_config
EOF
  fi
  $KEEP_SFTP || echo "  - SFTP is off, so scp from OpenSSH 9+ clients fails. Use 'scp -O', or re-run with --keep-sftp."
  cat <<EOF
  - Hardened config copies:   $BUTTERFARM (immutable; chattr -i before replacing them)
  - Undo the config changes:  sh $BACKUP_DIR/restore.sh
  - Quarantined files:        $BACKUP_DIR/quarantine
  - Full log:                 $LOG
EOF
}

main() {
  detect_platform
  check_access
  confirm_plan
  setup_backup
  harden_sshd
  harden_ssh_client
  fix_nullok
  remove_persistence
  save_butterfarm
  audit_system
  lock_files
  summary
}

main
