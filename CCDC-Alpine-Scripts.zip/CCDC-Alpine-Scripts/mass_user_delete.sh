#!/bin/sh
# mass_user_delete.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Deletes every user listed in a file (one per line) and their home directory.
# Uses userdel if the 'shadow' package is installed, otherwise BusyBox deluser.
#
# Usage: ./mass_user_delete.sh <userlist.txt>

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

set -eu

error() { echo "[ERROR] $*" >&2; exit 1; }

# ---------------------------
# Pre-flight checks
# ---------------------------
if [ -z "${1:-}" ]; then
    echo "Usage: $0 <userlist.txt>"
    echo "  userlist.txt - list of users to mass delete"
    exit 1
fi

[ "$(id -u)" -eq 0 ] || error "This script must be run as root (use su or doas)."

USERLIST_INPUT="$1"
[ -f "$USERLIST_INPUT" ] || error "Userlist file not found: $USERLIST_INPUT"

# /etc/passwd and /etc/shadow may be immutable (CCDC-Harden-SSH.sh does that)
if command -v lsattr >/dev/null 2>&1 && lsattr /etc/shadow 2>/dev/null | awk '{print $1}' | grep -q i; then
    error "/etc/shadow is immutable. Unlock it first: chattr -i /etc/shadow (and chattr +i it again afterwards)"
fi

# delete_user NAME: remove the account and its home directory
delete_user() {
    if command -v userdel >/dev/null 2>&1; then
        userdel -r "$1"
    else
        deluser --remove-home "$1"
    fi
}

while IFS= read -r user || [ -n "$user" ]; do
    user=$(printf '%s' "$user" | tr -d ' \t\r')
    # Skip empty lines and comments
    [ -z "$user" ] && continue
    case "$user" in \#*) continue ;; esac

    if ! id "$user" >/dev/null 2>&1; then
        echo "  WARNING: '$user' does not exist, skipped."
        continue
    fi
    if [ "$user" = root ]; then
        echo "  WARNING: refusing to delete root."
        continue
    fi
    if delete_user "$user"; then
        echo "  Deleted user: $user"
    else
        echo "  FAILED to delete: $user" >&2
    fi
done < "$USERLIST_INPUT"
