#!/bin/sh
# CCDC-Docker-Backup.sh - Alpine Linux host version (POSIX sh / BusyBox ash, no bash needed)
#
# Backs up service configs, web content, auth files and database dumps from
# every running container into /root/Docker_Service_Backup_<host>_<time>.
# Restore with CCDC-Docker-Restore.sh. Works with any container distro
# (including BusyBox/Alpine-based images that have no bash or ps aux).

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
   echo "[!] This script must be run as root (su or doas)"
   exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
    echo "[!] Docker is not installed or not in PATH (apk add docker)"
    exit 1
fi

ESC=$(printf '\033')
GRN="${ESC}[32m"; YEL="${ESC}[33m"; RST="${ESC}[0m"

HOSTNAME=$(hostname || echo "unknown_host")
TIMESTAMP=$(date +%Y%m%d_%H%M)
BACKUP_ROOT="/root/Docker_Service_Backup_${HOSTNAME}_${TIMESTAMP}"

mkdir -p -m 700 "$BACKUP_ROOT"
echo "--- Starting Docker Service Backup for $HOSTNAME ---"

TARGETS="dovecot postfix exim exim4 nginx apache apache2 httpd mysql mysqld mariadb postgresql postgres bind bind9 named vsftpd proftpd samba smbd nmbd snmpd nfs openvpn telnetd caddy gitea courier unbound dnsmasq sshd php-fpm redis memcached mongod elasticsearch rabbitmq haproxy traefik envoy squid tomcat jenkins grafana prometheus influxd mosquitto lighttpd"

get_conf_dirs() {
    case "$1" in
        nginx)         echo "/etc/nginx /usr/local/nginx/conf /etc/letsencrypt" ;;
        apache|apache2) echo "/etc/apache2 /etc/httpd /usr/local/apache2/conf" ;;
        httpd)         echo "/etc/httpd /etc/apache2 /usr/local/apache2/conf" ;;
        mysql)         echo "/etc/mysql /etc/my.cnf.d /var/lib/mysql/*.cnf" ;;
        mysqld|mariadb) echo "/etc/mysql /etc/my.cnf.d" ;;
        postgresql)    echo "/etc/postgresql /var/lib/postgresql/data" ;;
        postgres)      echo "/etc/postgresql /var/lib/postgresql/data /var/lib/pgsql/data" ;;
        dovecot)       echo "/etc/dovecot" ;;
        postfix)       echo "/etc/postfix" ;;
        exim)          echo "/etc/exim /etc/exim4" ;;
        exim4)         echo "/etc/exim4" ;;
        bind)          echo "/etc/bind /etc/named /var/named" ;;
        bind9)         echo "/etc/bind /var/cache/bind" ;;
        named)         echo "/etc/named /var/named" ;;
        vsftpd)        echo "/etc/vsftpd /etc/vsftpd.conf" ;;
        proftpd)       echo "/etc/proftpd" ;;
        samba|smbd)    echo "/etc/samba" ;;
        snmpd)         echo "/etc/snmp" ;;
        openvpn)       echo "/etc/openvpn" ;;
        caddy)         echo "/etc/caddy /config/caddy" ;;
        gitea)         echo "/etc/gitea /data/gitea" ;;
        courier)       echo "/etc/courier" ;;
        unbound)       echo "/etc/unbound" ;;
        dnsmasq)       echo "/etc/dnsmasq.conf /etc/dnsmasq.d" ;;
        sshd)          echo "/etc/ssh" ;;
        php-fpm)       echo "/etc/php /usr/local/etc/php" ;;
        redis)         echo "/etc/redis /usr/local/etc/redis" ;;
        memcached)     echo "/etc/memcached.conf" ;;
        mongod)        echo "/etc/mongod.conf /etc/mongodb.conf" ;;
        elasticsearch) echo "/etc/elasticsearch /usr/share/elasticsearch/config" ;;
        rabbitmq)      echo "/etc/rabbitmq" ;;
        haproxy)       echo "/etc/haproxy /usr/local/etc/haproxy" ;;
        traefik)       echo "/etc/traefik" ;;
        envoy)         echo "/etc/envoy" ;;
        squid)         echo "/etc/squid" ;;
        tomcat)        echo "/etc/tomcat /opt/tomcat/conf /usr/local/tomcat/conf" ;;
        jenkins)       echo "/var/jenkins_home /etc/jenkins" ;;
        grafana)       echo "/etc/grafana" ;;
        prometheus)    echo "/etc/prometheus" ;;
        influxd)       echo "/etc/influxdb" ;;
        mosquitto)     echo "/etc/mosquitto /mosquitto/config" ;;
        lighttpd)      echo "/etc/lighttpd" ;;
    esac
}

get_conf_files() {
    case "$1" in
        nginx)      echo "/etc/nginx/nginx.conf /etc/nginx/conf.d /etc/nginx/http.d /etc/nginx/sites-enabled /etc/nginx/sites-available" ;;
        mysql)      echo "/etc/my.cnf /etc/mysql/my.cnf" ;;
        mysqld)     echo "/etc/my.cnf" ;;
        mariadb)    echo "/etc/my.cnf /etc/mysql/my.cnf" ;;
        postgres)   echo "/var/lib/postgresql/data/pg_hba.conf /var/lib/postgresql/data/postgresql.conf /var/lib/pgsql/data/pg_hba.conf /var/lib/pgsql/data/postgresql.conf" ;;
        postgresql) echo "/var/lib/postgresql/data/pg_hba.conf /var/lib/postgresql/data/postgresql.conf" ;;
        redis)      echo "/etc/redis/redis.conf /usr/local/etc/redis/redis.conf /etc/redis.conf" ;;
        haproxy)    echo "/etc/haproxy/haproxy.cfg /usr/local/etc/haproxy/haproxy.cfg" ;;
        caddy)      echo "/etc/caddy/Caddyfile /config/Caddyfile" ;;
        squid)      echo "/etc/squid/squid.conf" ;;
        vsftpd)     echo "/etc/vsftpd.conf" ;;
        dnsmasq)    echo "/etc/dnsmasq.conf" ;;
        mongod)     echo "/etc/mongod.conf" ;;
        memcached)  echo "/etc/memcached.conf" ;;
    esac
}

WEB_DATA_PATHS="/var/www /usr/share/nginx/html /srv/www /var/www/html /usr/local/apache2/htdocs /opt/bitnami/nginx/html /var/lib/nginx/html /var/www/localhost/htdocs"

dexec() {
    cid="$1"
    shift
    docker exec "$cid" sh -c "$*" 2>/dev/null
}

safe_name() { echo "$1" | tr '/' '_' | sed 's/^_//'; }

# Process names inside the container. /proc works in every image, including
# minimal ones whose ps is BusyBox (no "ps aux") or missing entirely.
container_procs() {
    dexec "$1" 'for p in /proc/[0-9]*; do
        c=$(cat "$p/comm" 2>/dev/null); a=$(tr "\0" " " < "$p/cmdline" 2>/dev/null)
        [ -n "$c" ] && echo "$c $a"
    done'
}

detect_services_in_container() {
    cid="$1"
    found=""

    procs=$(container_procs "$cid")

    for svc in $TARGETS; do
        if echo "$procs" | grep -qiw -- "$svc"; then
            found="$found $svc"
        fi
    done

    extra=$(echo "$procs" | awk '{print $1}' | sed 's|.*/||' | sort -u)
    for proc in $extra; do
        proc_clean=$(echo "$proc" | tr -d '[:' | tr -d ']')
        [ -z "$proc_clean" ] && continue
        case "$proc_clean" in sh|ash|bash|sleep|cat|tr|tini|dumb-init|s6-*|supervisord|docker-entrypoi*) continue ;; esac
        MATCHED=0
        for svc in $TARGETS; do
            case "$proc_clean" in *"$svc"*) MATCHED=1; break ;; esac
        done
        for already in $found; do
            case "$proc_clean" in *"$already"*) MATCHED=1; break ;; esac
        done
        [ $MATCHED -eq 0 ] && found="$found $proc_clean"
    done

    echo $found
}

backup_service_from_container() {
    cid="$1"
    cname="$2"
    svc="$3"
    svc_dir="$BACKUP_ROOT/${cname}/services/${svc}"
    mkdir -p "$svc_dir"

    for cdir in $(get_conf_dirs "$svc"); do
        if dexec "$cid" "[ -d '$cdir' ] || [ -f '$cdir' ]"; then
            docker cp "$cid:$cdir" "$svc_dir/$(safe_name "$cdir")" 2>/dev/null
        fi
    done

    for cfile in $(get_conf_files "$svc"); do
        if dexec "$cid" "[ -f '$cfile' ]"; then
            docker cp "$cid:$cfile" "$svc_dir/$(safe_name "$cfile")" 2>/dev/null
        fi
    done

    etc_svc=$(dexec "$cid" "ls -d /etc/${svc}* 2>/dev/null")
    for epath in $etc_svc; do
        docker cp "$cid:$epath" "$svc_dir/$(safe_name "$epath")" 2>/dev/null
    done
}

backup_web_content_from_container() {
    cid="$1"
    cname="$2"
    web_dir="$BACKUP_ROOT/${cname}/webroot"
    mkdir -p "$web_dir"

    for wpath in $WEB_DATA_PATHS; do
        if dexec "$cid" "[ -d '$wpath' ]"; then
            docker cp "$cid:$wpath" "$web_dir/$(safe_name "$wpath")" 2>/dev/null
            echo "    ✓ $wpath"
        fi
    done
}

backup_system_from_container() {
    cid="$1"
    cname="$2"
    sys_dir="$BACKUP_ROOT/${cname}/system"
    mkdir -p "$sys_dir"

    for f in /etc/passwd /etc/shadow /etc/group /etc/gshadow /etc/resolv.conf /etc/hosts /etc/hostname; do
        if dexec "$cid" "[ -f '$f' ]"; then
            docker cp "$cid:$f" "$sys_dir/" 2>/dev/null
        fi
    done

    dexec "$cid" "cat /etc/os-release 2>/dev/null" > "$sys_dir/os-release.txt"
    dexec "$cid" "env" > "$sys_dir/environment.txt" 2>/dev/null
    dexec "$cid" "ps aux 2>/dev/null || ps -ef 2>/dev/null || ps 2>/dev/null" > "$sys_dir/processes.txt"
    dexec "$cid" "ss -plunt 2>/dev/null || netstat -plunt 2>/dev/null" > "$sys_dir/ports.txt"
    dexec "$cid" "cat /etc/crontab 2>/dev/null; ls /etc/cron.d/ 2>/dev/null; cat /etc/crontabs/* 2>/dev/null; for u in \$(cut -d: -f1 /etc/passwd 2>/dev/null); do crontab -l -u \$u 2>/dev/null; done" > "$sys_dir/crontabs.txt"
}

backup_auth_from_container() {
    cid="$1"
    cname="$2"
    auth_dir="$BACKUP_ROOT/${cname}/auth"
    mkdir -p "$auth_dir"

    for d in /etc/ssh /etc/pam.d /etc/ssl /etc/sssd /etc/krb5.conf; do
        if dexec "$cid" "[ -e '$d' ]"; then
            docker cp "$cid:$d" "$auth_dir/$(safe_name "$d")" 2>/dev/null
        fi
    done
}

backup_databases_from_container() {
    cid="$1"
    cname="$2"
    db_dir="$BACKUP_ROOT/${cname}/database_dumps"
    mkdir -p "$db_dir"

    if dexec "$cid" "command -v mysqldump || command -v mariadb-dump" >/dev/null 2>&1; then
        echo "    [*] Dumping MySQL/MariaDB..."
        DUMP='$(command -v mariadb-dump || command -v mysqldump)'
        dexec "$cid" "$DUMP --all-databases --single-transaction 2>/dev/null || $DUMP --all-databases 2>/dev/null" > "$db_dir/all_databases.sql" 2>/dev/null
        if [ ! -s "$db_dir/all_databases.sql" ]; then
            # Password via MYSQL_PWD so it never shows up in ps output
            dexec "$cid" "MYSQL_PWD=\${MYSQL_ROOT_PASSWORD:-\$MARIADB_ROOT_PASSWORD}; [ -n \"\$MYSQL_PWD\" ] && export MYSQL_PWD && $DUMP -uroot --all-databases --single-transaction" > "$db_dir/all_databases.sql" 2>/dev/null
        fi
        [ -s "$db_dir/all_databases.sql" ] && echo "    ✓ MySQL dump complete"
    fi

    if dexec "$cid" "command -v pg_dumpall" >/dev/null 2>&1; then
        echo "    [*] Dumping PostgreSQL..."
        dexec "$cid" "su - postgres -c 'pg_dumpall' 2>/dev/null || pg_dumpall -U \"\${POSTGRES_USER:-postgres}\" 2>/dev/null" > "$db_dir/pg_dumpall.sql" 2>/dev/null
        [ -s "$db_dir/pg_dumpall.sql" ] && echo "    ✓ PostgreSQL dump complete"
    fi

    if dexec "$cid" "command -v redis-cli" >/dev/null 2>&1; then
        echo "    [*] Dumping Redis..."
        dexec "$cid" "redis-cli BGSAVE 2>/dev/null && sleep 2 && cat /data/dump.rdb 2>/dev/null || cat /var/lib/redis/dump.rdb 2>/dev/null" > "$db_dir/redis_dump.rdb" 2>/dev/null
        [ -s "$db_dir/redis_dump.rdb" ] && echo "    ✓ Redis dump complete"
    fi

    if dexec "$cid" "command -v mongodump" >/dev/null 2>&1; then
        echo "    [*] Dumping MongoDB..."
        dexec "$cid" "mongodump --archive 2>/dev/null" > "$db_dir/mongo_dump.archive" 2>/dev/null
        [ -s "$db_dir/mongo_dump.archive" ] && echo "    ✓ MongoDB dump complete"
    fi
}

RUNNING_CONTAINERS=$(docker ps --format '{{.ID}} {{.Names}}' 2>/dev/null)
if [ -z "$RUNNING_CONTAINERS" ]; then
    echo "[!] No running containers found"
    exit 0
fi

echo "$RUNNING_CONTAINERS" | while IFS=' ' read -r cid cname; do
    printf '\n============================================\n'
    echo "[*] Container: $cname ($cid)"
    echo "============================================"

    CDIR="$BACKUP_ROOT/${cname}"
    mkdir -p "$CDIR"

    docker inspect "$cid" > "$CDIR/inspect.json" 2>/dev/null

    echo "  [*] Backing up system info..."
    backup_system_from_container "$cid" "$cname"

    echo "  [*] Backing up auth data..."
    backup_auth_from_container "$cid" "$cname"

    echo "  [*] Detecting services..."
    SERVICES_FOUND=$(detect_services_in_container "$cid")

    if [ -z "$SERVICES_FOUND" ]; then
        echo "    No known services detected via process list"
        IMG=$(docker inspect --format '{{.Config.Image}}' "$cid" 2>/dev/null)
        for svc in $TARGETS; do
            if echo "$IMG" | grep -qi -- "$svc"; then
                SERVICES_FOUND="$svc"
                echo "    Detected $svc from image name: $IMG"
                break
            fi
        done
    fi

    if [ -n "$SERVICES_FOUND" ]; then
        for svc in $SERVICES_FOUND; do
            echo "    [*] Backing up service: $svc"
            backup_service_from_container "$cid" "$cname" "$svc"
        done
    fi

    echo "  [*] Checking for web content..."
    backup_web_content_from_container "$cid" "$cname"

    echo "  [*] Checking for databases..."
    backup_databases_from_container "$cid" "$cname"

    echo "  ✓ Container $cname complete"
done

mkdir -p "$BACKUP_ROOT/_host_context"
docker ps -a --no-trunc > "$BACKUP_ROOT/_host_context/all_containers.txt" 2>/dev/null
docker images --no-trunc > "$BACKUP_ROOT/_host_context/all_images.txt" 2>/dev/null
docker network ls > "$BACKUP_ROOT/_host_context/all_networks.txt" 2>/dev/null
docker volume ls > "$BACKUP_ROOT/_host_context/all_volumes.txt" 2>/dev/null
cp -p /etc/docker/daemon.json "$BACKUP_ROOT/_host_context/" 2>/dev/null
cp -p /etc/conf.d/docker "$BACKUP_ROOT/_host_context/conf.d_docker" 2>/dev/null
find / -xdev \( -name 'docker-compose.yml' -o -name 'docker-compose.yaml' -o -name 'compose.yml' -o -name 'compose.yaml' \) \
    -not -path '/proc/*' -not -path "$BACKUP_ROOT/*" 2>/dev/null > "$BACKUP_ROOT/_host_context/compose_files.txt"
if [ -s "$BACKUP_ROOT/_host_context/compose_files.txt" ]; then
    # shellcheck disable=SC2046
    tar -czf "$BACKUP_ROOT/_host_context/compose_files.tar.gz" $(cat "$BACKUP_ROOT/_host_context/compose_files.txt") 2>/dev/null
fi

printf '\n--- VERIFICATION REPORT ---\n'
for cdir in "$BACKUP_ROOT"/*/; do
    cname=$(basename "$cdir")
    [ "$cname" = "_host_context" ] && continue
    svc_dir="$cdir/services"
    if [ -d "$svc_dir" ] && [ -n "$(ls -A "$svc_dir" 2>/dev/null)" ]; then
        svc_list=$(ls "$svc_dir" | tr '\n' ',' | sed 's/,$//')
        count=$(find "$svc_dir" -type f 2>/dev/null | wc -l)
        printf '[%s OK %s] %s → services: %s (%s files)\n' "$GRN" "$RST" "$cname" "$svc_list" "$count"
    else
        printf '[%s WARN %s] %s → no service configs found\n' "$YEL" "$RST" "$cname"
    fi
    if [ -d "$cdir/database_dumps" ] && [ -n "$(find "$cdir/database_dumps" -type f -size +0 2>/dev/null)" ]; then
        printf '[%s OK %s] %s → database dumps present\n' "$GRN" "$RST" "$cname"
    fi
    if [ -d "$cdir/webroot" ] && [ -n "$(ls -A "$cdir/webroot" 2>/dev/null)" ]; then
        printf '[%s OK %s] %s → web content backed up\n' "$GRN" "$RST" "$cname"
    fi
done

chmod -R 600 "$BACKUP_ROOT"
chmod 700 "$BACKUP_ROOT"
printf '\n--- Docker Service Backup Complete: %s ---\n' "$BACKUP_ROOT"
