#!/bin/sh
# shadow_passwd_restore.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Restores /etc/passwd and /etc/shadow from the decoy key files that
# shadow_passwd_backup.sh hid in /usr/share/apk/keys.

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

set -eu

error() { echo "[ERROR] $*" >&2; exit 1; }

# ---------------------------
# Pre-flight checks
# ---------------------------
[ "$(id -u)" -eq 0 ] || error "This script must be run as root (use su or doas)."

DIR="/usr/share/apk/keys"
SHADOW_FILE="$DIR/alpine-devel@lists.alpinelinux.org-5d43a1b1.rsa.pub"
PASSWD_FILE="$DIR/alpine-devel@lists.alpinelinux.org-5fd8b2e4.rsa.pub"

[ -s "$SHADOW_FILE" ] || error "Backup not found: $SHADOW_FILE"
[ -s "$PASSWD_FILE" ] || error "Backup not found: $PASSWD_FILE"

# Everything between the BEGIN/END lines, whitespace stripped, base64-decoded, gunzipped
extract() {
    sed -n '/^-----BEGIN PUBLIC KEY-----$/,/^-----END PUBLIC KEY-----$/{/-----/d;p;}' "$1" \
        | tr -d '[:space:]' | base64 -d | gunzip -c
}

# Decode to temp files first so a damaged backup can't leave /etc/shadow empty.
TMPD=$(mktemp -d)
trap 'rm -rf "$TMPD"' EXIT
extract "$PASSWD_FILE" > "$TMPD/passwd" || error "Could not decode $PASSWD_FILE"
extract "$SHADOW_FILE" > "$TMPD/shadow" || error "Could not decode $SHADOW_FILE"
grep -q '^root:' "$TMPD/passwd" || error "Decoded passwd has no root entry; not restoring"
grep -q '^root:' "$TMPD/shadow" || error "Decoded shadow has no root entry; not restoring"

# CCDC-Harden-SSH.sh makes /etc/shadow immutable; lift that while we write.
relock=""
for f in /etc/passwd /etc/shadow; do
    if command -v lsattr >/dev/null 2>&1 && lsattr "$f" 2>/dev/null | awk '{print $1}' | grep -q i; then
        chattr -i "$f" && relock="$relock $f"
    fi
done

cat "$TMPD/passwd" > /etc/passwd
cat "$TMPD/shadow" > /etc/shadow

# Restore sane default permissions (Alpine: shadow is root:shadow 0640)
chmod 644 /etc/passwd
chmod 640 /etc/shadow
chown root:root   /etc/passwd
chown root:shadow /etc/shadow 2>/dev/null || chown root:root /etc/shadow

for f in $relock; do chattr +i "$f"; done

echo "Restored /etc/passwd and /etc/shadow."
rm -- "$0"
