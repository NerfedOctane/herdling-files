#!/bin/sh
# --- Alpine guard (POSIX sh until the second "fi") -----------------------------
# This is the Alpine Linux version. It needs bash: if this was started with
# BusyBox sh (ash), bash is installed with apk when missing and the script
# re-runs itself under it.
if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi
if [ -z "${BASH_VERSION:-}" ]; then
    if ! command -v bash >/dev/null 2>&1; then
        echo "[*] bash is not installed; installing it with apk..." >&2
        apk add --no-cache bash >/dev/null 2>&1 || {
            echo "[!] Could not install bash (no repository access?). Install it first: apk add bash" >&2
            exit 1
        }
    fi
    exec bash "$0" "$@"
fi
# --------------------------------------------------------------------------------
# CCDC-Docker-Harden.sh - Alpine Linux host version (OpenRC docker service, BusyBox tools)

RESET='\033[0m'
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[!] This script requires root privileges${RESET}"
    exit 1
fi

if ! command -v docker &> /dev/null; then
    echo -e "${RED}[!] Docker is not installed (apk add docker)${RESET}"
    exit 1
fi

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/root/docker-backup-${TIMESTAMP}"
QUARANTINE_DIR="/root/docker-quarantine-${TIMESTAMP}"

echo -e "${CYAN}"
cat << "EOF"
╔═══════════════════════════════════════════════════════╗
║     Docker Hardening & Security Lockdown Tool         ║
║          CCDC Blue Team Defense Suite                 ║
║           🔒 Container Fortress Mode 🔒               ║
╚═══════════════════════════════════════════════════════╝
EOF
echo -e "${RESET}\n"

echo -e "${GREEN}[*] Starting hardening at: $(date)${RESET}\n"

mkdir -p "$BACKUP_DIR" "$QUARANTINE_DIR"

echo -e "${RED}╔═══════════════════════════════════════════════════════╗${RESET}"
echo -e "${RED}║           PHASE 1: THREAT IDENTIFICATION              ║${RESET}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${RESET}\n"

echo -e "${YELLOW}[1] Identifying Dangerous Containers${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

CONTAINERS=$(docker ps -q)
DANGEROUS_CONTAINERS=()

for container in $CONTAINERS; do
    CONTAINER_NAME=$(docker inspect --format='{{.Name}}' "$container" | tr -d '/')
    
    PRIVILEGED=$(docker inspect --format='{{.HostConfig.Privileged}}' "$container")
    
    DOCKER_SOCK=$(docker inspect --format='{{range .Mounts}}{{.Source}}{{"\n"}}{{end}}' "$container" | grep -E "docker\.sock")
    
    CAPS=$(docker inspect --format='{{.HostConfig.CapAdd}}' "$container")
    
    NETWORK=$(docker inspect --format='{{.HostConfig.NetworkMode}}' "$container")
    
    if [ "$PRIVILEGED" == "true" ] || [ -n "$DOCKER_SOCK" ] || [[ "$CAPS" == *"SYS_ADMIN"* ]] || [ "$NETWORK" == "host" ]; then
        echo -e "${RED}[!] DANGEROUS: $CONTAINER_NAME ($container)${RESET}"
        [ "$PRIVILEGED" == "true" ] && echo -e "  └─ Privileged mode enabled"
        [ -n "$DOCKER_SOCK" ] && echo -e "  └─ Docker socket mounted"
        [[ "$CAPS" == *"SYS_ADMIN"* ]] && echo -e "  └─ SYS_ADMIN capability"
        [ "$NETWORK" == "host" ] && echo -e "  └─ Host network mode"
        
        DANGEROUS_CONTAINERS+=("$container")
    fi
done

echo -e "\n${YELLOW}[2] Scanning for Reverse Shells${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

SHELL_CONTAINERS=()

for container in $CONTAINERS; do
    CONTAINER_NAME=$(docker inspect --format='{{.Name}}' "$container" | tr -d '/')
    
    SHELLS=$(docker exec "$container" sh -c 'ps aux 2>/dev/null || ps' 2>/dev/null | grep -iE "(nc.*-e|/dev/tcp|bash.*-i|sh.*-i|python.*socket|socat)" | grep -v grep)
    
    if [ -n "$SHELLS" ]; then
        echo -e "${RED}[!] REVERSE SHELL DETECTED: $CONTAINER_NAME${RESET}"
        echo "$SHELLS"
        SHELL_CONTAINERS+=("$container")
    fi
done

echo -e "\n${RED}╔═══════════════════════════════════════════════════════╗${RESET}"
echo -e "${RED}║              PHASE 2: CONTAINER REMEDIATION           ║${RESET}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${RESET}\n"

echo -e "${YELLOW}[3] Stopping Dangerous Containers${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for container in "${DANGEROUS_CONTAINERS[@]}"; do
    CONTAINER_NAME=$(docker inspect --format='{{.Name}}' "$container" | tr -d '/')
    
    echo -e "${BLUE}[i] Backing up container: $CONTAINER_NAME${RESET}"
    docker export "$container" > "$BACKUP_DIR/${CONTAINER_NAME}.tar" 2>/dev/null
    
    echo -e "${YELLOW}[!] Stopping: $CONTAINER_NAME${RESET}"
    docker stop "$container" > /dev/null 2>&1
    
    read -p "Remove container $CONTAINER_NAME permanently? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        docker rm "$container" > /dev/null 2>&1
        echo -e "${GREEN}[✓] Removed: $CONTAINER_NAME${RESET}"
    fi
done

echo -e "\n${YELLOW}[4] Killing Reverse Shell Processes${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for container in "${SHELL_CONTAINERS[@]}"; do
    CONTAINER_NAME=$(docker inspect --format='{{.Name}}' "$container" | tr -d '/')
    
    echo -e "${YELLOW}[!] Killing suspicious processes in: $CONTAINER_NAME${RESET}"
    
    docker exec "$container" sh -c 'pkill -9 nc' 2>/dev/null
    docker exec "$container" sh -c 'pkill -9 netcat' 2>/dev/null
    docker exec "$container" sh -c 'pkill -9 socat' 2>/dev/null
    
    # Find the PID column from the header: procps "ps aux" has it 2nd, BusyBox ps 1st
    docker exec -i "$container" sh 2>/dev/null <<'KILLEOF'
{ ps aux 2>/dev/null || ps; } | awk '
    NR == 1 { for (i = 1; i <= NF; i++) if ($i == "PID") c = i; next }
    /bash.*-i|sh.*-i/ && !/awk|grep/ { print $c }' | while read -r pid; do
    [ "$pid" = "$$" ] || kill -9 "$pid" 2>/dev/null
done
KILLEOF
    
    echo -e "${GREEN}[✓] Processes terminated${RESET}"
done

echo -e "\n${YELLOW}[5] Scanning for Malicious Images${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

DANGLING=$(docker images -f "dangling=true" -q)
if [ -n "$DANGLING" ]; then
    echo -e "${YELLOW}[!] Removing dangling images...${RESET}"
    docker rmi $DANGLING 2>/dev/null
    echo -e "${GREEN}[✓] Dangling images removed${RESET}"
fi

echo -e "${BLUE}[i] Images created in last 24 hours:${RESET}"
docker images --format "{{.Repository}}:{{.Tag}} - {{.CreatedAt}}" | grep "$(date +%Y-%m-%d)"

echo -e "\n${RED}╔═══════════════════════════════════════════════════════╗${RESET}"
echo -e "${RED}║           PHASE 3: DOCKER DAEMON HARDENING            ║${RESET}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${RESET}\n"

echo -e "${YELLOW}[6] Hardening Docker Daemon Configuration${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

mkdir -p /etc/docker
if [ -f /etc/docker/daemon.json ]; then
    cp /etc/docker/daemon.json "$BACKUP_DIR/daemon.json.bak"
fi

# userns-remap ("default") maps container root to an unprivileged range. Two
# Alpine-specific catches:
#  * dockerd creates its "dockremap" user with Debian-style adduser flags,
#    which BusyBox adduser rejects, so the daemon fails to start. The user and
#    its /etc/subuid + /etc/subgid ranges are created here first.
#  * Remapping gives Docker a separate data directory: every existing image,
#    container and volume is hidden until you turn it off again. That takes
#    scored containers offline, so it is opt-in.
USERNS_LINE=""
echo -e "${YELLOW}[?] Enable user-namespace remapping (userns-remap)?${RESET}"
echo "    Existing containers, images and volumes will NOT be visible afterwards"
echo "    (they stay on disk; remove userns-remap from daemon.json to get them back)."
REPLY=""
if [ -t 0 ]; then read -p "Enable userns-remap? (y/N): " -n 1 -r; echo; fi
if [[ $REPLY =~ ^[Yy]$ ]]; then
    getent group dockremap >/dev/null 2>&1 || addgroup -S dockremap
    id dockremap >/dev/null 2>&1 || adduser -S -D -H -G dockremap -s /sbin/nologin dockremap
    for f in /etc/subuid /etc/subgid; do
        touch "$f"
        grep -q '^dockremap:' "$f" || echo "dockremap:100000:65536" >> "$f"
    done
    USERNS_LINE='  "userns-remap": "default",'
    echo -e "${GREEN}[✓] dockremap user and subordinate ID ranges prepared${RESET}"
else
    echo -e "${BLUE}[i] Skipping userns-remap${RESET}"
fi

cat > /etc/docker/daemon.json << DOCKERCFG
{
  "icc": false,
${USERNS_LINE}
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "live-restore": true,
  "userland-proxy": false,
  "no-new-privileges": true
}
DOCKERCFG
# drop the blank line left when userns-remap is skipped
sed -i '/^$/d' /etc/docker/daemon.json

echo -e "${GREEN}[✓] Docker daemon config hardened${RESET}"

if dockerd --help 2>/dev/null | grep -q -- '--validate' && ! dockerd --validate --config-file /etc/docker/daemon.json >/dev/null 2>&1; then
    echo -e "${RED}[!] dockerd --validate rejected the new daemon.json - restoring the old one, NOT restarting${RESET}"
    if [ -f "$BACKUP_DIR/daemon.json.bak" ]; then cp "$BACKUP_DIR/daemon.json.bak" /etc/docker/daemon.json; else rm -f /etc/docker/daemon.json; fi
else
    echo -e "${BLUE}[i] Restarting Docker daemon...${RESET}"
    if rc-service docker restart >/dev/null 2>&1; then
        sleep 3
        echo -e "${GREEN}[✓] Docker daemon restarted${RESET}"
    else
        echo -e "${RED}[!] Docker failed to restart - restoring the previous daemon.json${RESET}"
        if [ -f "$BACKUP_DIR/daemon.json.bak" ]; then cp "$BACKUP_DIR/daemon.json.bak" /etc/docker/daemon.json; else rm -f /etc/docker/daemon.json; fi
        rc-service docker restart >/dev/null 2>&1 && echo -e "${YELLOW}[!] Docker is running on the previous config (see /var/log/docker.log)${RESET}"
    fi
fi

echo -e "\n${YELLOW}[7] Securing Docker Socket${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -S /var/run/docker.sock ]; then
    CURRENT_PERMS=$(stat -c "%a" /var/run/docker.sock)
    echo -e "${BLUE}[i] Current socket permissions: $CURRENT_PERMS${RESET}"
    
    chmod 660 /var/run/docker.sock
    chown root:docker /var/run/docker.sock
    echo -e "${GREEN}[✓] Socket permissions set to 660${RESET}"
fi

if netstat -an 2>/dev/null | grep -qE "(0\.0\.0\.0|:::|\*):2375[[:space:]]"; then
    echo -e "${RED}[!] WARNING: Docker API exposed on 2375${RESET}"
    echo -e "${YELLOW}[!] Disable by removing -H tcp://0.0.0.0:2375 from DOCKER_OPTS in /etc/conf.d/docker (or \"hosts\" in daemon.json)${RESET}"
fi
if grep -qsE '^[[:space:]]*DOCKER_OPTS=.*tcp://' /etc/conf.d/docker; then
    echo -e "${RED}[!] /etc/conf.d/docker makes dockerd listen on TCP:${RESET}"
    grep -E '^[[:space:]]*DOCKER_OPTS=' /etc/conf.d/docker
fi

echo -e "\n${YELLOW}[8] Restricting Docker Group Membership${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo -e "${BLUE}[i] Current docker group members:${RESET}"
getent group docker

echo -e "${YELLOW}[!] Remove unnecessary users from docker group:${RESET}"
echo "    delgroup [username] docker"

echo -e "\n${RED}╔═══════════════════════════════════════════════════════╗${RESET}"
echo -e "${RED}║              PHASE 4: NETWORK HARDENING               ║${RESET}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${RESET}\n"

echo -e "${YELLOW}[9] Auditing Docker Networks${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

docker network ls

HOST_CONTAINERS=$(docker ps --filter "network=host" --format "{{.Names}}")
if [ -n "$HOST_CONTAINERS" ]; then
    echo -e "${RED}[!] Containers on host network:${RESET}"
    echo "$HOST_CONTAINERS"
    echo -e "${YELLOW}[!] Consider moving to bridge network${RESET}"
fi

echo -e "\n${YELLOW}[10] Creating Isolated Network${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if ! docker network ls | grep -q "isolated"; then
    docker network create \
        --driver bridge \
        --subnet=172.20.0.0/16 \
        --opt "com.docker.network.bridge.name"="docker_isolated" \
        isolated
    echo -e "${GREEN}[✓] Created isolated network${RESET}"
fi

echo -e "\n${RED}╔═══════════════════════════════════════════════════════╗${RESET}"
echo -e "${RED}║           PHASE 5: PERSISTENCE REMOVAL                ║${RESET}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${RESET}\n"

echo -e "${YELLOW}[11] Checking Docker Compose Files${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

find / -path /proc -prune -o \( -name "docker-compose.yml" -o -name "docker-compose.yaml" -o -name "compose.yml" -o -name "compose.yaml" \) -print 2>/dev/null | while read -r compose_file; do
    echo -e "${BLUE}[i] Found: $compose_file${RESET}"
    
    cp "$compose_file" "$BACKUP_DIR/$(echo "$compose_file" | tr '/' '_').bak"
    
    if grep -qE "(privileged.*true|/var/run/docker.sock|cap_add.*SYS_ADMIN|network_mode.*host)" "$compose_file"; then
        echo -e "${RED}[!] Contains dangerous configurations${RESET}"
        grep -nE "(privileged|docker.sock|SYS_ADMIN|network_mode.*host)" "$compose_file"
        
        sed -i 's/privileged:.*/privileged: false/' "$compose_file"
        
        sed -i 's|^[[:space:]]*- /var/run/docker.sock|# REMOVED: - /var/run/docker.sock|' "$compose_file"
        
        echo -e "${GREEN}[✓] Sanitized compose file${RESET}"
    fi
done

echo -e "\n${YELLOW}[12] Removing Malicious OpenRC Services${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Init scripts (other than docker/containerd themselves) that run docker
for init in /etc/init.d/*; do
    SERVICE=$(basename "$init")
    case "$SERVICE" in docker|containerd|docker-*|functions.sh) continue ;; esac
    grep -qiE '(^|[^a-z])docker([^a-z-]|$)' "$init" 2>/dev/null || continue
    grep -qE '^[[:space:]]*(need|use|after|before)[[:space:]].*docker' "$init" && ! grep -qiE 'docker[[:space:]]+(run|exec|start)' "$init" && continue
    echo -e "${YELLOW}[!] Suspicious service: $SERVICE ($(rc-service "$SERVICE" status 2>/dev/null | sed -n 's/.*status: *//p'))${RESET}"
    grep -niE 'docker' "$init" | head -n 5 | sed 's/^/      /'
    read -p "Disable service $SERVICE? (y/N): " -n 1 -r </dev/tty
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rc-service "$SERVICE" stop
        for lvl in boot default sysinit; do rc-update del "$SERVICE" "$lvl" >/dev/null 2>&1; done
        echo -e "${GREEN}[✓] Disabled: $SERVICE${RESET}"
    fi
done
# Boot scripts and cron jobs that start containers
grep -lsiE 'docker[[:space:]]+(run|start|exec)' /etc/local.d/*.start /etc/crontabs/* /etc/periodic/*/* 2>/dev/null | while read -r f; do
    echo -e "${YELLOW}[!] $f starts containers - review it:${RESET}"
    grep -niE 'docker[[:space:]]+(run|start|exec)' "$f" | sed 's/^/      /'
done

echo -e "\n${RED}╔═══════════════════════════════════════════════════════╗${RESET}"
echo -e "${RED}║           PHASE 6: SECURITY MONITORING                ║${RESET}"
echo -e "${RED}╚═══════════════════════════════════════════════════════╝${RESET}\n"

echo -e "${YELLOW}[13] Enabling Docker Content Trust${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Alpine login shells read /etc/profile.d (there is no /etc/environment / pam_env)
echo "export DOCKER_CONTENT_TRUST=1" > /etc/profile.d/docker-content-trust.sh
chmod 644 /etc/profile.d/docker-content-trust.sh

echo -e "${GREEN}[✓] Docker Content Trust enabled${RESET}"
echo -e "${YELLOW}[!] Restart shell or run: export DOCKER_CONTENT_TRUST=1${RESET}"

echo -e "\n${YELLOW}[14] Setting Up Audit Logging${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if ! command -v auditctl &> /dev/null; then
    echo -e "${YELLOW}[!] Installing audit...${RESET}"
    apk add --no-cache audit audit-openrc >/dev/null 2>&1 || apk add --no-cache audit >/dev/null 2>&1
fi

mkdir -p /etc/audit/rules.d
cat > /etc/audit/rules.d/docker.rules << 'AUDITRULES'
-w /usr/bin/docker -p wa -k docker
-w /usr/bin/dockerd -p wa -k docker
-w /var/lib/docker -p wa -k docker
-w /etc/docker -p wa -k docker
-w /etc/init.d/docker -p wa -k docker
-w /etc/conf.d/docker -p wa -k docker
-w /etc/docker/daemon.json -p wa -k docker
-w /usr/bin/containerd -p wa -k docker
-w /usr/bin/runc -p wa -k docker
AUDITRULES

rc-update add auditd default >/dev/null 2>&1
rc-service auditd restart >/dev/null 2>&1
command -v augenrules >/dev/null 2>&1 && augenrules --load >/dev/null 2>&1
echo -e "${GREEN}[✓] Docker audit logging configured${RESET}"

echo -e "\n${YELLOW}[15] Creating Security Baseline${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cat > "$BACKUP_DIR/security-baseline.txt" << BASELINE
Docker Security Baseline - $(date)
═══════════════════════════════════════════

RUNNING CONTAINERS:
$(docker ps --format "{{.ID}} - {{.Names}} - {{.Image}}")

IMAGES:
$(docker images --format "{{.Repository}}:{{.Tag}} - {{.ID}}")

NETWORKS:
$(docker network ls)

VOLUMES:
$(docker volume ls)

DOCKER VERSION:
$(docker version --format '{{.Server.Version}}')

DAEMON CONFIG:
$(cat /etc/docker/daemon.json 2>/dev/null || echo "Default configuration")
BASELINE

echo -e "${GREEN}[✓] Baseline saved to: $BACKUP_DIR/security-baseline.txt${RESET}"

echo -e "\n${GREEN}╔═══════════════════════════════════════════════════════╗${RESET}"
echo -e "${GREEN}║              HARDENING COMPLETE                       ║${RESET}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${RESET}\n"

echo -e "${CYAN}[*] Summary:${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${BLUE}Backup Location:${RESET}     $BACKUP_DIR"
echo -e "${BLUE}Quarantine Location:${RESET} $QUARANTINE_DIR"
echo -e "${BLUE}Dangerous Containers:${RESET} ${#DANGEROUS_CONTAINERS[@]}"
echo -e "${BLUE}Shell Containers:${RESET}     ${#SHELL_CONTAINERS[@]}"

echo -e "\n${YELLOW}[!] ADDITIONAL MANUAL STEPS:${RESET}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "1. Review quarantined containers in: $BACKUP_DIR"
echo "2. Scan all images with 'docker scan <image>'"
echo "3. Restrict containers (--cap-drop ALL, --read-only, seccomp profiles)"
echo "4. Set up secrets management (HashiCorp Vault)"
echo "5. Enable user namespace remapping (if you skipped it: plan a window, it hides existing containers)"
echo "6. Configure resource limits (CPU/Memory)"
echo "7. Set up vulnerability scanning (Trivy/Clair)"
echo "8. Monitor Docker events: docker events &"
echo "9. Review audit logs: ausearch -k docker"
echo "10. Implement network policies and firewalls"

echo -e "\n${GREEN}[✓] Docker environment hardened!${RESET}"
echo -e "${CYAN}[*] Monitor containers: watch -n 2 'docker ps'${RESET}"
echo -e "${MAGENTA}[*] Stay vigilant. Red team never sleeps. 🔒${RESET}\n"