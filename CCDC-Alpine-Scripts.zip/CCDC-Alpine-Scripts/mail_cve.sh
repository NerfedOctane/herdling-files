#!/bin/sh
# --- Alpine guard (POSIX sh until the second "fi") -----------------------------
# This is the Alpine Linux version. It needs bash: if this was started with
# BusyBox sh (ash), bash is installed with apk when missing and the script
# re-runs itself under it.
if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi
if [ -z "${BASH_VERSION:-}" ]; then
    if ! command -v bash >/dev/null 2>&1; then
        echo "[*] bash is not installed; installing it with apk..." >&2
        apk add --no-cache bash >/dev/null 2>&1 || {
            echo "[!] Could not install bash (no repository access?). Install it first: apk add bash" >&2
            exit 1
        }
    fi
    exec bash "$0" "$@"
fi
# --------------------------------------------------------------------------------
# ==========================================================================================
# mail_cve.sh  -  CCDC mail box: find and close KNOWN CVEs (2006-2026) in Exim, Dovecot,
#                 Postfix and RainLoop/SnappyMail
# Category : Mail / Detection (default) + Mail / Hardening (--patch, --mitigate)
# Companion: mail_harden.sh fixes the default/misconfigured settings; run it FIRST.
#
# ALPINE LINUX VERSION. STEP 0 checks for Alpine. Packages come from apk, services
# are OpenRC. Alpine ships upstream versions (no distro changelog of backported CVE
# fixes is installed), so the version ladder plus "apk version" decide.
#
# Three layers, because no single one is enough:
#   1. VERSION GATE   installed version vs a built-in "fixed in" ladder (~150 CVEs). Tells you
#                     WHICH CVEs apply and how bad (Critical / CISA known-exploited = KEV).
#   2. PACKAGE MANAGER  "apk version -l '<'" lists newer builds in the repos (Alpine sometimes
#                     patches inside a release, -rN); --patch installs them (the real fix).
#   3. CONFIG MITIGATIONS  many CVEs need an optional feature (BDAT/CHUNKING, SPA/NTLM auth,
#                     PROXY protocol, ManageSieve, empty auth_username_chars...). Turning the
#                     feature off closes the CVE even before (or without) patching. --mitigate.
#   Plus an EXPLOIT-TRACE HUNT in the logs (Exim ${run{...}} payloads, Dovecot crashes).
#
# Modes:
#   (no mode)        READ-ONLY report: versions, CVEs that apply, pending updates, risky
#                    features, exploit traces, and a one-line verdict per service.
#   --patch          install vendor security updates for the mail packages, then re-check
#   --mitigate       apply the config mitigations (backed up, validated, auto-reverted)
#   --rollback [DIR] undo one --mitigate run (no DIR = list backups)
# Options:
#   --keep-sieve     don't close ManageSieve (port 4190) even if it is listening
#   --all            also list CVE groups the box is already past (full history)
# Usage   : sh ./mail_cve.sh | tee /root/cve-before.txt      (as root)
#           sh ./mail_cve.sh --patch --mitigate
# Safety  : nothing changes without --patch/--mitigate. Never touches BTA or seccdc* accounts.
#           --patch can restart services: check the scoreboard right after.
# ==========================================================================================
set -u
PATCH=0; MITIGATE=0; ROLLBACK=0; RB_DIR=""; KEEP_SIEVE=0; SHOW_ALL=0
while [[ $# -gt 0 ]]; do
  case $1 in
    --patch) PATCH=1 ;;
    --mitigate) MITIGATE=1 ;;
    --rollback) ROLLBACK=1; [[ ${2:-} == /* ]] && { RB_DIR=$2; shift; } ;;
    --keep-sieve) KEEP_SIEVE=1 ;;
    --all) SHOW_ALL=1 ;;
    -h|--help) awk 'NR>1 && /^#/{sub(/^# ?/,""); print; next} NR>1{exit}' "$0"; exit 0 ;;
    *) echo "Unknown option: $1 (try --help)"; exit 1 ;;
  esac; shift
done
R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[1m'; N=$'\e[0m'
bad(){ echo "${R}[!]${N} $*"; }
ok(){ echo "${G}[+]${N} $*"; }
warn(){ echo "${Y}[*]${N} $*"; }
hdr(){ echo; echo "${B}== $* ==${N}"; }
# svc ACTION SERVICE: OpenRC
svc(){ case $1 in enable) rc-update add "$2" default >/dev/null 2>&1 ;; *) rc-service "$2" "$1" >/dev/null 2>&1 ;; esac; }
# Archive / extract relative to / (BusyBox tar has no -P for absolute member names)
bk_tar(){ local out=$1 p rel=(); shift; for p in "$@"; do rel+=("${p#/}"); done; tar czf "$out" -C / "${rel[@]}"; }
bk_untar(){ local in=$1 p rel=(); shift; for p in "$@"; do rel+=("${p#/}"); done; tar xzf "$in" -C / "${rel[@]}"; }
# listening PORT: is something listening on this TCP port? (ss, or BusyBox netstat)
listening(){ { ss -tln 2>/dev/null || netstat -tln 2>/dev/null; } | grep -qE "[:.]$1[[:space:]]"; }

# ==========================================================================================
# STEP 0: DISTRO CHECK (identical to mail_harden.sh) - os-release is parsed, never sourced.
# ==========================================================================================
detect_distro(){
  DISTRO=unknown
  if [[ -f /etc/alpine-release || ${SKIP_ALPINE_CHECK:-0} == 1 ]]; then DISTRO=alpine; fi
  PKG=apk; EXIMSVC=exim; EXLOGDIR=/var/log/exim
  if [[ -f /var/log/mail.log ]]; then MAILLOG=/var/log/mail.log; else MAILLOG=/var/log/messages; fi
  P_DOVECOT="dovecot dovecot-pop3d dovecot-lmtpd dovecot-submissiond dovecot-pigeonhole-plugin"
  P_EXIM="exim"
}
detect_distro
[[ $DISTRO == unknown ]] && { echo "[!] Not Alpine Linux - use the original mail_cve.sh. Nothing was changed."; exit 1; }
echo "[*] Distro detected: $DISTRO $(cat /etc/alpine-release 2>/dev/null)  (pkg=$PKG, maillog=$MAILLOG)"
[[ $EUID -eq 0 ]] || { echo "Run as root (su or doas)"; exit 1; }

# ==========================================================================================
# THE LADDER  service | fixed-in (one per release branch, comma-separated) | severity | KEV | what | CVEs
# Built from mail_cves_reference.csv (CVE text "before X.Y") plus vendor advisories.
# Branch-aware: Dovecot 2.2.36.4 counts as fixed for CVE-2019-11500 even though it is below
# 2.3.7.2, because each release branch carries its own fix version.
# ==========================================================================================
LADDER=$(cat <<'EOF'
Exim|4.70|Critical|KEV|string_vformat heap overflow -> remote root|CVE-2010-4344
Exim|4.72|Medium|-|appendfile lets local users touch arbitrary files|CVE-2010-2023,CVE-2010-2024
Exim|4.73|High|KEV|exim user -> root via alternate config; unchecked setuid|CVE-2010-4345,CVE-2011-0017
Exim|4.76|High|-|DKIM format string / lookup -> RCE|CVE-2011-1407,CVE-2011-1764
Exim|4.81|Medium|-|DKIM DNS TXT heap overflow|CVE-2012-5671
Exim|4.83|Medium|-|double expansion local exec; DMARC From: RCE|CVE-2014-2972,CVE-2014-2957
Exim|4.86.2|High|-|perl_startup local root|CVE-2016-1531
Exim|4.87.1|Medium|-|DKIM private key disclosure|CVE-2016-9963
Exim|4.89.1|Medium|-|-p argument leak (Stack Clash helper)|CVE-2017-1000369
Exim|4.90|Critical|-|BDAT use-after-free RCE / DoS|CVE-2017-16943,CVE-2017-16944
Exim|4.90.1|Critical|KEV|base64d pre-auth RCE|CVE-2018-6789
Exim|4.92|Critical|KEV|Return of the WIZard: recipient address RCE as root|CVE-2019-10149,CVE-2020-28020
Exim|4.92.1|Critical|-|${sort} expansion RCE as root (some configs)|CVE-2019-13917
Exim|4.92.2|Critical|-|TLS SNI trailing backslash RCE as root|CVE-2019-15846
Exim|4.92.3|Critical|KEV|long EHLO heap overflow RCE|CVE-2019-16928
Exim|4.94|High|-|SPA/NTLM authentication bypass|CVE-2020-12783
Exim|4.94.2|Critical|-|21Nails: remote RCE + local root chain|CVE-2020-28007,CVE-2020-28008,CVE-2020-28009,CVE-2020-28010,CVE-2020-28011,CVE-2020-28012,CVE-2020-28013,CVE-2020-28014,CVE-2020-28015,CVE-2020-28016,CVE-2020-28017,CVE-2020-28018,CVE-2020-28019,CVE-2020-28021,CVE-2020-28022,CVE-2020-28023,CVE-2020-28024,CVE-2020-28025,CVE-2020-28026,CVE-2021-27216
Exim|4.95|Critical|-|host_name_lookup heap overflow; STARTTLS response injection|CVE-2022-37452,CVE-2021-38371
Exim|4.96|High|-|pam_converse invalid free|CVE-2022-37451
Exim|4.96.2|Critical|-|ZDI set: AUTH/NTLM/SPA pre-auth RCE, dnsdb leak|CVE-2023-42114,CVE-2023-42115,CVE-2023-42116,CVE-2023-42117,CVE-2023-42119
Exim|4.97|Critical|-|regex + DMARC use-after-free (conservative bound)|CVE-2022-3559,CVE-2022-3620
Exim|4.97.1|Medium|-|SMTP smuggling: spoofed senders|CVE-2023-51766
Exim|4.98|Medium|-|RFC 2231 filename misparse -> attachment filter bypass|CVE-2024-39929
Exim|4.98.1|Critical|-|SQLite hints + ETRN remote SQL injection|CVE-2025-26794
Exim|4.98.2|High|-|use-after-free local privilege escalation|CVE-2025-30232
Exim|4.99.1|Critical|-|rate-limit DB heap overflow (non-default ratelimit)|CVE-2025-67896
Exim|4.99.2|Critical|-|JSON lookup / SPA / UTF-8 / musl DNS memory bugs|CVE-2026-40684,CVE-2026-40685,CVE-2026-40686,CVE-2026-40687
Exim|4.99.3|Critical|-|GnuTLS BDAT use-after-free|CVE-2026-45185
Exim|4.99.4|Medium|-|PROXY short payload stack leak|CVE-2026-48840
Exim|4.99.5|High|-|.forward pipe force_command + queue-name traversal privesc|CVE-2026-66140,CVE-2026-66141
Exim|4.100.1|High|-|SMTP smuggling, PROXY protocol OOB/leak, GnuTLS UAF|CVE-2026-94054,CVE-2026-94055,CVE-2026-94056,CVE-2026-94057
Dovecot|2.0|High|-|any 1.x release: 15 CVEs (ACL bypass, sieve overflow, auth cache)|CVE-2006-5973,CVE-2007-2231,CVE-2007-4211,CVE-2007-6598,CVE-2008-1199,CVE-2008-1218,CVE-2008-4577,CVE-2008-4578,CVE-2008-4870,CVE-2008-4907,CVE-2008-5301,CVE-2009-2632,CVE-2009-3235,CVE-2009-3897,CVE-2010-0745
Dovecot|1.2.15,2.0.5|Medium|-|ACL inheritance / admin-right bypass; master DoS|CVE-2010-3304,CVE-2010-3706,CVE-2010-3707,CVE-2010-3779,CVE-2010-3780
Dovecot|1.2.17,2.0.13|Medium|-|header NUL DoS; script-login chroot/user bypass|CVE-2011-1929,CVE-2011-2166,CVE-2011-2167
Dovecot|2.0.16|Medium|-|proxy TLS hostname not verified|CVE-2011-4318
Dovecot|2.2.7|Medium|-|checkpassword setuid auth bypass|CVE-2013-6171
Dovecot|2.2.13|Medium|-|connection exhaustion DoS; APPEND loop|CVE-2014-3430,CVE-2013-2111
Dovecot|2.2.17|Medium|-|SSL handshake login crash|CVE-2015-3420
Dovecot|2.2.27|Medium|-|auth-policy crash|CVE-2016-8652
Dovecot|2.2.29|High|-|dict passdb username expansion DoS|CVE-2017-2669
Dovecot|2.2.34,2.3.1|High|-|SNI memory DoS; SASL abort leak; OOB read on delivery|CVE-2017-15130,CVE-2017-15132,CVE-2017-14461
Dovecot|2.2.36.1,2.3.4.1|Medium|-|client cert with empty username = login as anyone|CVE-2019-3814
Dovecot|2.2.36.3,2.3.5.1|High|-|indexer-worker overflow -> local root|CVE-2019-7524
Dovecot|2.3.6|High|-|auth JSON crash; submission-login crashes|CVE-2019-10691,CVE-2019-11494,CVE-2019-11499
Dovecot|2.2.36.4,2.3.7.2|Critical|-|NUL in quoted strings -> pre-auth heap corruption|CVE-2019-11500
Dovecot|2.3.9.3|High|-|push-notification / snippet / submission crashes|CVE-2019-19722,CVE-2020-7046,CVE-2020-7957
Dovecot|2.3.10.1|High|-|unauthenticated submission/lmtp crashes + UAF|CVE-2020-10957,CVE-2020-10958,CVE-2020-10967
Dovecot|2.3.11.3|High|-|RPA/NTLM auth crashes; MIME recursion DoS|CVE-2020-12100,CVE-2020-12673,CVE-2020-12674
Dovecot|2.3.13|Medium|-|IMAP IDLE unhibernate -> read other users' mail; MIME DoS|CVE-2020-24386,CVE-2020-25275
Dovecot|2.3.15|Medium|-|STARTTLS command injection; OAuth2 path traversal; sieve regex DoS|CVE-2021-33515,CVE-2021-29157,CVE-2020-28200
Dovecot|2.3.20|High|-|duplicate passdb entries -> privilege escalation|CVE-2022-30550
Dovecot|2.3.21.1|High|-|huge headers / address lists -> resource exhaustion|CVE-2024-23184,CVE-2024-23185
RainLoop|1.13.0|Medium|-|missing XSS protections (no CSP)|CVE-2019-13389
EOF
)
# CVEs in mail_cves_reference.csv with NO fixed version in their record: the package manager
# decides these; --mitigate closes the ones that hinge on a feature.
UNVERSIONED="Dovecot 2.4-era (2025-2026): CVE-2024-25584 CVE-2025-30189 CVE-2025-59028 CVE-2025-59031 CVE-2025-59032 CVE-2026-0394 CVE-2026-24031 CVE-2026-27851..27860 CVE-2026-33263 CVE-2026-33603..33607 CVE-2026-40013..40020 CVE-2026-40203..40205 CVE-2026-42006..42008 CVE-2026-42391..42395 CVE-2026-52681 CVE-2026-52687 CVE-2026-73208 CVE-2026-73209"

# ver_lt A B: true if dotted version A < B (BusyBox sort has no -V)
ver_lt(){
  local IFS=. i x y; local -a a=($1) b=($2)
  for ((i = 0; i < 6; i++)); do
    x=${a[i]:-0}; y=${b[i]:-0}; x=${x%%[!0-9]*}; y=${y%%[!0-9]*}
    x=$((10#${x:-0})); y=$((10#${y:-0}))
    ((x < y)) && return 0
    ((x > y)) && return 1
  done
  return 1
}
branch(){ cut -d. -f1-2 <<<"$1"; }
# is_vuln INSTALLED "fix1,fix2": the fix that counts is the lowest one on the installed branch or
# a newer branch; fixes for OLDER branches don't apply. Vulnerable if installed < that fix.
is_vuln(){ local iv=$1 f best="" b; b=$(branch "$1")
  for f in ${2//,/ }; do
    ver_lt "$(branch "$f")" "$b" && continue
    if [[ -z $best ]] || ver_lt "$f" "$best"; then best=$f; fi
  done
  [[ -n $best ]] && ver_lt "$iv" "$best"; }
declare -A NCVE NCRIT NKEV NBACK FIXED
# Debian/RHEL list backported CVEs in an installed changelog. Alpine installs none
# (its secfixes live in the APKBUILDs), so nothing counts as backported here.
load_changelog(){ FIXED[$1]=""; }
gate(){   # gate SERVICE VERSION
  local svc=$1 iv=$2 s fx sev kev what cves n=0 c=0 k=0 nb=0 tag cv open back
  [[ -z $iv ]] && { warn "$svc version unknown - the package-manager check decides"; return; }
  while IFS='|' read -r s fx sev kev what cves; do
    [[ $s == "$svc" ]] || continue
    if is_vuln "$iv" "$fx"; then
      open=(); back=0
      for cv in ${cves//,/ }; do [[ " ${FIXED[$svc]:-} " == *" $cv "* ]] && back=$((back+1)) || open+=("$cv"); done
      ((nb += back))
      if ((${#open[@]} == 0)); then ((SHOW_ALL)) && ok "$svc $iv < ${fx//,/ / } but all $back backported by the distro: $what"; continue; fi
      ((n += ${#open[@]})); [[ $sev == Critical ]] && ((c += ${#open[@]})); [[ $kev == KEV ]] && ((k += ${#open[@]}))
      tag=$sev; [[ $kev == KEV ]] && tag="$sev, EXPLOITED IN THE WILD"
      bad "$svc $iv < ${fx//,/ / } [$tag] $what: ${open[*]}$( ((back)) && echo "  (+$back backported)")"
    elif ((SHOW_ALL)); then ok "$svc $iv >= ${fx//,/ / }  $what"; fi
  done <<<"$LADDER"
  NCVE[$svc]=$n; NCRIT[$svc]=$c; NKEV[$svc]=$k; NBACK[$svc]=$nb
  ((nb)) && ok "$svc: $nb CVEs that the version number suggests are open were BACKPORTED by the distro (changelog)"
  ((n)) && bad "$svc: $n CVEs still open ($c critical, $k known-exploited)" \
        || ok "$svc $iv: no open CVEs in the ladder"
}
pending(){   # pending PKG... -> lines "pkg-oldver -> newver" for upgrades waiting in the repos
  apk version -l '<' "$@" 2>/dev/null | awk '$2 == "<" {print $1" -> "$3}'; }
installed_pkgs(){ local p; for p in "$@"; do apk info -e "$p" >/dev/null 2>&1 && echo "$p"; done; }
pkgver(){ local v
  v=$(apk list -I "$1" 2>/dev/null | awk 'NR==1{print $1}'); v=${v#"$1"-}
  [[ -n $v ]] || v=$(awk -v p="$1" '/^P:/{n=substr($0,3)} /^V:/{if(n==p){print substr($0,3); exit}}' /lib/apk/db/installed 2>/dev/null)
  printf '%s' "$v"; }

EXIM=$(command -v exim4 || command -v exim || true)
DOVEPKGS=(); EXIMPKGS=()
command -v dovecot >/dev/null && mapfile -t DOVEPKGS < <(installed_pkgs $P_DOVECOT)
[[ -n $EXIM ]] && mapfile -t EXIMPKGS < <(installed_pkgs $P_EXIM)
dc(){ doveconf -h "$1" 2>/dev/null; }

# dove_enforce DROPIN KEY... : after a restart, make sure each KEY really has the value our
# drop-in sets. A later-sorting conf.d file (zz-*.conf) or local.conf wins in Dovecot - a
# classic red-team trick to undo hardening - so any other file setting that key is commented
# out (originals are in the backup), then the config is re-validated and Dovecot restarted.
dove_enforce(){
  local drop=$1 k want f hit=0; shift; local LC_ALL=C
  for k in "$@"; do
    grep -q "^$k = " "$drop" || continue                  # only keys this drop-in sets
    want=$(sed -n "s/^$k = //p" "$drop" | tail -n1)
    [[ $(doveconf -h "$k" 2>/dev/null) == "$want" ]] && continue
    for f in /etc/dovecot/conf.d/*.conf /etc/dovecot/local.conf; do
      [[ -f $f && $f != *ccdc* ]] || continue               # never our own files
      # only files that load AFTER ours can override it: later in C sort order, or local.conf
      [[ $f == */local.conf ]] || [[ $(basename "$f") > $(basename "$drop") ]] || continue
      grep -qE "^[[:space:]]*${k}[[:space:]]*=" "$f" || continue
      sed -i -E "s/^([[:space:]]*)(${k}[[:space:]]*=)/\1#CCDC-overridden \2/" "$f"
      bad "$f was overriding '$k' (planted?) - neutralized it"; hit=1
    done
  done
  ((hit)) || return 0
  if doveconf -n >/dev/null 2>&1 && svc restart dovecot; then
    for k in "$@"; do grep -q "^$k = " "$drop" || continue; want=$(sed -n "s/^$k = //p" "$drop" | tail -n1)
      [[ $(doveconf -h "$k" 2>/dev/null) == "$want" ]] && ok "  $k = ${want:-(empty)} now effective" || bad "  $k still '$(doveconf -h "$k")' - check dovecot.conf includes by hand"; done
  else bad "Dovecot rejected the config after neutralizing - restore with the rollback command"; fi
}

# ---- rollback of a --mitigate run ---------------------------------------------------------
if ((ROLLBACK)); then
  if [[ -z $RB_DIR || ! -f $RB_DIR/etc.tgz ]]; then
    echo "Usage: $0 --rollback /root/ccdc-backups/<dir>"
    echo "Backups from BOTH scripts, newest first (mail-* = mail_harden.sh, cve-* = mail_cve.sh)."
    echo "Undo NEWEST FIRST, one at a time: each backup also contains every earlier run's changes."
    ls -td /root/ccdc-backups/*/ 2>/dev/null | while IFS= read -r d; do [[ -f $d/etc.tgz ]] && echo "  ${d%/}"; done; exit 1; fi
  for f in "$RB_DIR"/*perms.txt; do [[ -f $f ]] || continue
    while read -r m u g p; do [[ -e $p ]] && chown "$u:$g" "$p" && chmod "$m" "$p"; done < "$f"; done
  hdr "Rollback from $RB_DIR"
  sort -u "$RB_DIR/added-files.txt" 2>/dev/null | while IFS= read -r f; do [[ -n $f ]] && rm -f "$f" && echo "[-] removed $f"; done
  bk_untar "$RB_DIR/etc.tgz" && ok "configs restored"
  [[ -f /etc/exim4/update-exim4.conf.conf ]] && command -v update-exim4.conf >/dev/null && update-exim4.conf
  sort -u "$RB_DIR/services.txt" 2>/dev/null | while IFS= read -r s; do svc restart "$s" && ok "$s restarted" || bad "$s failed to restart"; done
  warn "package upgrades from --patch are not rolled back"; exit 0
fi

# ==========================================================================================
# STEP 1: (--patch) vendor security updates - the real fix for most CVEs
# ==========================================================================================
if ((PATCH)); then
  hdr "STEP 1  Installing vendor security updates"
  all=("${DOVEPKGS[@]}" "${EXIMPKGS[@]}"); command -v postconf >/dev/null && all+=(postfix)
  if ((${#all[@]})); then
    warn "packages: ${all[*]} (services may restart - watch the scoreboard)"
    timeout 300 apk update -q >/dev/null 2>&1 || warn "apk update failed (no repository access?) - using the cached index"
    # apk add -u upgrades only the named packages; config files you changed are kept (.apk-new)
    timeout 600 apk add -u "${all[@]}" 2>&1 | grep -E 'Upgrading|Installing|OK:|ERROR' | tail -n 6
    ok "update step finished - the report below re-checks versions"
  else warn "no mail packages found to patch"; fi
fi

# ==========================================================================================
# STEP 2: versions vs the ladder + what the package manager says is waiting
# ==========================================================================================
hdr "STEP 2  Versions vs known CVEs"
# Refresh the package index (quietly) so the "pending update" checks are current
timeout 60 apk update -q >/dev/null 2>&1 || warn "apk update failed (no repository access?) - pending-update checks use the cached index"
declare -A VERDICT
if command -v dovecot >/dev/null; then
  DV=$(dovecot --version 2>/dev/null | awk '{print $1}')
  echo "  Dovecot $DV   (package ${DOVEPKGS[0]:-?} $(pkgver "${DOVEPKGS[0]:-x}"))"
  load_changelog Dovecot "${DOVEPKGS[@]}"; gate Dovecot "$DV"
  PD=$( ((${#DOVEPKGS[@]})) && pending "${DOVEPKGS[@]}")
  [[ -n $PD ]] && { bad "Dovecot security update WAITING:"; sed 's/^/      /' <<<"$PD"; } || ok "Dovecot: no pending package update"
  [[ ${DV%%.*} -ge 2 && $(cut -d. -f2 <<<"$DV") -ge 4 ]] && warn "Dovecot 2.4: $UNVERSIONED - rely on updates + STEP 3"
  if [[ -n $PD ]]; then VERDICT[Dovecot]="UPDATE WAITING - run --patch"
  elif ((${NCVE[Dovecot]:-0})); then VERDICT[Dovecot]="${NCVE[Dovecot]} open CVEs, no update in the repo yet: apply STEP 3 mitigations, re-check for updates"
  else VERDICT[Dovecot]="OK"; fi
fi
if [[ -n $EXIM ]]; then
  EV=$("$EXIM" -bV 2>/dev/null | awk '/^Exim version/{print $3; exit}')
  echo "  Exim $EV   (package ${EXIMPKGS[0]:-?} $(pkgver "${EXIMPKGS[0]:-x}"))"
  load_changelog Exim "${EXIMPKGS[@]}"; gate Exim "$EV"
  PE=$( ((${#EXIMPKGS[@]})) && pending "${EXIMPKGS[@]}")
  [[ -n $PE ]] && { bad "Exim security update WAITING:"; sed 's/^/      /' <<<"$PE"; } || ok "Exim: no pending package update"
  if [[ -n $PE ]]; then VERDICT[Exim]="UPDATE WAITING - run --patch"
  elif ((${NCVE[Exim]:-0})); then VERDICT[Exim]="${NCVE[Exim]} open CVEs, no update in the repo yet: apply STEP 3 mitigations, re-check for updates"
  else VERDICT[Exim]="OK"; fi
fi
if command -v postconf >/dev/null; then
  echo "  Postfix $(postconf -h mail_version 2>/dev/null)  (no Postfix CVEs in the reference list - package manager only)"
  PP=$(pending postfix); [[ -n $PP ]] && { bad "Postfix update WAITING: $PP"; VERDICT[Postfix]="UPDATE WAITING"; } || { ok "Postfix: no pending update"; VERDICT[Postfix]="OK"; }
fi
mapfile -t WMS < <(find /var/www /srv /usr/share/nginx /usr/share/webapps /opt -maxdepth 9 -type d -path '*/_data_/_default_' 2>/dev/null)
for c in "${WMS[@]}"; do
  d=${c%/_data_/_default_}; w=$(dirname "$d"); v=$(head -c 20 "$d/VERSION" 2>/dev/null)
  if [[ -d $w/snappymail ]]; then ok "SnappyMail $v at $w - maintained fork; update it from snappymail.eu releases"; VERDICT[Webmail]="SnappyMail - keep current"
  else
    echo "  RainLoop ${v:-?} at $w"; gate RainLoop "${v:-0}"
    bad "RainLoop CVE-2022-29360 (stored XSS: one crafted email -> session takeover) has NO fix: the project is abandoned"
    warn "  fix = migrate to SnappyMail (drop-in fork) when you can re-test webmail; until then admin panel off (mail_harden.sh), and don't read untrusted mail as admin"
    VERDICT[Webmail]="RainLoop: 1 unfixable CVE - plan SnappyMail migration"
  fi
done

# ==========================================================================================
# STEP 3: risky optional features = CVE preconditions. Report, and fix with --mitigate.
# ==========================================================================================
hdr "STEP 3  CVE preconditions (features that make specific CVEs reachable)"
DFIX=(); EFIX=()   # what --mitigate would write
if command -v doveconf >/dev/null; then
  am=$(dc auth_mechanisms)
  if grep -qiwE 'rpa|ntlm|otp|skey|gssapi' <<<"$am"; then bad "Dovecot auth_mechanisms = $am  (RPA/NTLM/OTP parsers: CVE-2020-12673 CVE-2020-12674 CVE-2026-27855)"; DFIX+=("auth_mechanisms = plain login")
  else ok "Dovecot auth_mechanisms = $am (no RPA/NTLM/OTP)"; fi
  if doveconf auth_username_chars >/dev/null 2>&1 && [[ -z $(dc auth_username_chars) ]]; then
    bad "Dovecot auth_username_chars is EMPTY (SQL/LDAP injection + auth bypass: CVE-2026-24031 CVE-2026-27860)"
    DFIX+=("auth_username_chars = abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890.-_@")
  else ok "Dovecot auth_username_chars restricted"; fi
  if doveconf -n 2>/dev/null | grep -q 'managesieve-login' || listening 4190; then
    if listening 4190; then
      bad "ManageSieve listening on 4190 (pre-auth crashes/loops/OOB: CVE-2008-5301 CVE-2025-59032 CVE-2026-27858 CVE-2026-33605 CVE-2026-40013 CVE-2026-40019; sieve CPU: CVE-2026-40016)"
      ((KEEP_SIEVE)) && warn "  --keep-sieve: left open" || DFIX+=("service managesieve-login {\n  inet_listener sieve {\n    port = 0\n  }\n}")
    fi
  fi
  ltn=$(dc login_trusted_networks); [[ -n $ltn ]] && warn "Dovecot login_trusted_networks = $ltn - hosts here can inject forwarded fields (CVE-2026-42008 CVE-2026-42395); keep it to real proxies only"
  doveconf -n 2>/dev/null | grep -qE 'mail_plugins.*imap_(zlib|compress)' && warn "IMAP compression plugin enabled (memory/stack DoS, compression side channel: CVE-2026-52687 CVE-2026-73209 CVE-2026-40203)"
  doveconf -n 2>/dev/null | awk '/service doveadm/{f=1} f&&/port *= *[1-9]/{print; exit}' | grep -q . && warn "doveadm network listener configured (timing leak of its secret: CVE-2026-27856 CVE-2026-42393) - firewall it"
fi
if [[ -n $EXIM ]]; then
  ca=$("$EXIM" -bP chunking_advertise_hosts 2>/dev/null | sed 's/^[^=]*= *//')
  if [[ -n $ca ]]; then bad "Exim advertises CHUNKING/BDAT to '$ca' (BDAT RCE/UAF + smuggling: CVE-2017-16943 CVE-2017-16944 CVE-2026-45185 CVE-2023-51766 CVE-2026-94057)"; EFIX+=("chunking_advertise_hosts =")
  else ok "Exim CHUNKING/BDAT off"; fi
  "$EXIM" -bP authenticators 2>/dev/null | grep -qiE 'driver *= *spa' && bad "Exim SPA/NTLM authenticator configured (CVE-2020-12783 CVE-2023-42114/5/6 CVE-2026-40687) - remove that authenticator block" || ok "no SPA/NTLM authenticator"
  hp=$("$EXIM" -bP hosts_proxy 2>/dev/null | sed 's/^[^=]*= *//'); [[ -n $hp && $hp != *"not a known"* ]] && bad "Exim hosts_proxy = $hp (PROXY protocol leaks/OOB: CVE-2026-48840 CVE-2026-94054 CVE-2026-94056) - unset it unless a real proxy fronts Exim" || ok "PROXY protocol off"
  "$EXIM" -bP acl_smtp_etrn 2>/dev/null | grep -qE '= *[^ ]' && warn "Exim accepts ETRN (SQLite-hints SQL injection: CVE-2025-26794)"
  "$EXIM" -bP smtp_etrn_serialize 2>/dev/null | grep -q true && "$EXIM" -bV 2>/dev/null | grep -qi sqlite && warn "  ...and is built with SQLite hints"
  grep -rqsE 'ratelimit *= *[^/]*/[^/]*/per_(addr|cmd|conn|byte)' /etc/exim4 /etc/exim 2>/dev/null && warn "Exim ACLs use per_* ratelimit (rate-limit DB heap overflow: CVE-2025-67896)"
  grep -rqsE '^[[:space:]]*dmarc_' /etc/exim4 /etc/exim 2>/dev/null && warn "Exim DMARC enabled (CVE-2014-2957 CVE-2022-3620)"
fi
find /home /root -maxdepth 2 -name .forward 2>/dev/null | while IFS= read -r f; do grep -q '|' "$f" && bad ".forward with a pipe: $f  (CVE-2026-66141 privesc path; also red-team persistence)"; done

# ==========================================================================================
# STEP 4: exploit traces - has someone already tried these CVEs?
# ==========================================================================================
hdr "STEP 4  Exploit traces in the logs"
found=0
for f in "$EXLOGDIR"/mainlog "$EXLOGDIR"/rejectlog "$EXLOGDIR"/main.log "$EXLOGDIR"/reject.log; do
  [[ -f $f ]] || continue
  if grep -qE '\$\{run|\$\{readsocket|\$\{readfile|/bin/(ba)?sh|\\x2f' "$f"; then found=1
    bad "Exim expansion/command payloads in $f (CVE-2019-10149 style):"; grep -E '\$\{run|\$\{readsocket|\$\{readfile|/bin/(ba)?sh' "$f" | tail -n 3 | cut -c1-180 | sed 's/^/      /'; fi
  n=$(grep -cE 'SMTP protocol (synchronization )?error|too many (nonmail|syntax)|line too long' "$f"); ((n > 20)) && { found=1; warn "$n SMTP protocol errors in $f (fuzzing / overflow attempts?)"; }
done
for f in "$EXLOGDIR"/paniclog "$EXLOGDIR"/panic.log; do [[ -s $f ]] && { found=1; bad "Exim paniclog not empty: $f"; tail -n 3 "$f" | sed 's/^/      /'; }; done
for f in "$MAILLOG" /var/log/dovecot.log; do
  [[ -f $f ]] || continue
  n=$(grep -cE 'dovecot.*(Panic|Fatal|killed with signal|segfault)' "$f"); ((n)) && { found=1; bad "$n Dovecot crash lines in $f (DoS/exploit attempts?):"; grep -E 'dovecot.*(Panic|Fatal|killed with signal)' "$f" | tail -n 2 | cut -c1-180 | sed 's/^/      /'; }
done
dmesg 2>/dev/null | grep -E '(exim|dovecot|imap|pop3).*segfault' | tail -n 2 | sed "s/^/${R}[!]${N} kernel: /"
((found)) || ok "no exploit traces found"

# ==========================================================================================
# STEP 5: (--mitigate) apply the config mitigations - backed up, validated, auto-reverted
# ==========================================================================================
if ((MITIGATE)); then
  hdr "STEP 5  Applying CVE mitigations"
  TS=$(date +%Y%m%d-%H%M%S); BK=/root/ccdc-backups/cve-$TS
  mkdir -p "$BK"; chmod 700 /root/ccdc-backups "$BK"; : > "$BK/added-files.txt"; : > "$BK/services.txt"
  bp=(); for p in /etc/dovecot /etc/exim4 /etc/exim; do [[ -e $p ]] && bp+=("$p"); done
  bk_tar "$BK/etc.tgz" "${bp[@]}" 2>/dev/null; ok "backup -> $BK"
  if ((${#DFIX[@]})); then
    DROP=/etc/dovecot/conf.d/99-zz-ccdc-cve.conf   # loads after mail_harden.sh's drop-in
    echo "$DROP" >> "$BK/added-files.txt"; echo dovecot >> "$BK/services.txt"
    { echo "# CCDC CVE mitigations $TS - delete this file to undo"; printf '%b\n' "${DFIX[@]}"; } > "$DROP"; chmod 644 "$DROP"
    if doveconf -n >/dev/null 2>"$BK/doveconf.err" && svc restart dovecot; then ok "Dovecot: $(grep -cvE '^#|^ |^}' "$DROP") mitigation(s) applied ($DROP)"
      dove_enforce "$DROP" auth_mechanisms auth_username_chars
      if [[ ${DFIX[*]} == *managesieve* ]]; then sleep 1; listening 4190 && bad "4190 still listening" || ok "ManageSieve port 4190 closed"; fi
    else bad "Dovecot rejected the mitigations - reverted"; cat "$BK/doveconf.err"; rm -f "$DROP"; svc restart dovecot; fi
  else ok "Dovecot: nothing to mitigate"; fi
  if ((${#EFIX[@]})); then
    if [[ -f /etc/exim4/update-exim4.conf.conf ]] && command -v update-exim4.conf >/dev/null; then
      LM=/etc/exim4/exim4.conf.localmacros; [[ -e $LM ]] || echo "$LM" >> "$BK/added-files.txt"
      for l in "${EFIX[@]}"; do grep -qxF "$l" "$LM" 2>/dev/null || echo "$l" >> "$LM"; done
      echo "$EXIMSVC" >> "$BK/services.txt"
      if update-exim4.conf && "$EXIM" -bV >/dev/null 2>"$BK/exim.err" && svc restart "$EXIMSVC"; then ok "Exim: ${EFIX[*]} (in $LM)"
      else bad "Exim rejected the mitigations - restoring"; cat "$BK/exim.err"; bk_untar "$BK/etc.tgz" /etc/exim4; update-exim4.conf; svc restart "$EXIMSVC"; fi
    else
      CF=$("$EXIM" -bV 2>/dev/null | awk '/^Configuration file is/{print $NF; exit}')
      warn "Single-file Exim (Alpine): add these lines to the MAIN section of $CF (before the first 'begin'), then exim -bV && rc-service exim restart:"
      printf '      %s\n' "${EFIX[@]}"
    fi
  else ok "Exim: nothing to mitigate"; fi
  ok "undo: sh $0 --rollback $BK"
elif ((${#DFIX[@]} + ${#EFIX[@]})); then
  warn "$((${#DFIX[@]} + ${#EFIX[@]})) mitigation(s) available - apply with: sh $0 --mitigate"
fi

# ---- summary: one line per service, the thing to say out loud ----------------------------
hdr "Verdict"
for k in $(printf '%s\n' "${!VERDICT[@]}" | sort); do
  v=${VERDICT[$k]}; if [[ $v == OK* || $v == SnappyMail* ]]; then ok "$(printf '%-8s %s' "$k" "$v")"; else bad "$(printf '%-8s %s' "$k" "$v")"; fi
done
warn "re-run after every change; diff runs to spot tampering. Default-config hardening: ./mail_harden.sh"
