#!/bin/sh
# CCDC-Docker-Restore.sh - Alpine Linux host version (POSIX sh / BusyBox ash, no bash needed)
#
# Restores files saved by CCDC-Docker-Backup.sh into a running container.
# Usage: ./CCDC-Docker-Restore.sh [backup_dir]   (default: newest /root/Docker_Service_Backup_*)
#
# Alpine host notes: BusyBox tar has no --mode/--exclude, so files are staged
# in a temp folder, permission-normalized there, then streamed into the
# container with `docker cp -`.

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
   echo "[!] Must run as root"
   exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
    echo "[!] Docker is not installed or not in PATH"
    exit 1
fi

BACKUP_DIR=${1:-$(ls -td /root/Docker_Service_Backup_* 2>/dev/null | head -n1)}

if [ -z "$BACKUP_DIR" ] || [ ! -d "$BACKUP_DIR" ]; then
    echo "[!] No backup found"
    exit 1
fi

ESC=$(printf '\033')
GRN="${ESC}[32m"; RED="${ESC}[31m"; GRY="${ESC}[90m"; RST="${ESC}[0m"

TARGETS="dovecot postfix exim exim4 nginx apache apache2 httpd mysql mysqld mariadb postgresql postgres bind bind9 named vsftpd proftpd samba smbd nmbd snmpd nfs openvpn telnetd caddy gitea courier unbound dnsmasq sshd php-fpm redis memcached mongod elasticsearch rabbitmq haproxy traefik envoy squid tomcat jenkins grafana prometheus influxd mosquitto lighttpd"

KNOWN_PATHS="/etc/nginx /usr/local/nginx/conf /etc/letsencrypt /etc/nginx/nginx.conf /etc/nginx/conf.d /etc/nginx/http.d
    /etc/nginx/sites-enabled /etc/nginx/sites-available /etc/apache2 /etc/httpd /usr/local/apache2/conf
    /etc/mysql /etc/my.cnf.d /etc/my.cnf /etc/mysql/my.cnf /etc/postgresql
    /var/lib/postgresql/data/pg_hba.conf /var/lib/postgresql/data/postgresql.conf
    /var/lib/pgsql/data/pg_hba.conf /var/lib/pgsql/data/postgresql.conf
    /etc/dovecot /etc/postfix /etc/exim /etc/exim4 /etc/bind /etc/named /var/named /var/cache/bind
    /etc/vsftpd /etc/vsftpd.conf /etc/proftpd /etc/samba /etc/snmp /etc/openvpn
    /etc/caddy /config/caddy /etc/caddy/Caddyfile /config/Caddyfile /etc/gitea /data/gitea /etc/courier
    /etc/unbound /etc/dnsmasq.conf /etc/dnsmasq.d /etc/ssh /etc/php /usr/local/etc/php
    /etc/redis /usr/local/etc/redis /etc/redis/redis.conf /usr/local/etc/redis/redis.conf /etc/redis.conf
    /etc/memcached.conf /etc/mongod.conf /etc/mongodb.conf /etc/elasticsearch /usr/share/elasticsearch/config
    /etc/rabbitmq /etc/haproxy /usr/local/etc/haproxy /etc/haproxy/haproxy.cfg /usr/local/etc/haproxy/haproxy.cfg
    /etc/traefik /etc/envoy /etc/squid /etc/squid/squid.conf /etc/tomcat /opt/tomcat/conf /usr/local/tomcat/conf
    /var/jenkins_home /etc/jenkins /etc/grafana /etc/prometheus /etc/influxdb /etc/mosquitto /mosquitto/config
    /etc/lighttpd /var/www /usr/share/nginx/html /srv/www /var/www/html /usr/local/apache2/htdocs
    /opt/bitnami/nginx/html /var/lib/nginx/html /var/www/localhost/htdocs /etc/pam.d /etc/ssl /etc/sssd /etc/krb5.conf"

NAMES=""
for d in "$BACKUP_DIR"/*/; do
    [ -f "$d/inspect.json" ] && NAMES="$NAMES $(basename "$d")"
done
count=$(echo $NAMES | wc -w)

NAME=""
if [ "$count" -eq 0 ]; then
    echo "[!] No containers found in $BACKUP_DIR"
    exit 1
elif [ "$count" -eq 1 ]; then
    NAME=$(echo $NAMES)
else
    echo "Containers in backup:"
    i=1
    for n in $NAMES; do
        echo "  $i) $n"
        i=$((i + 1))
    done
    printf 'Select container [1-%s]: ' "$count"
    read -r n
    case "$n" in
        ''|*[!0-9]*) ;;
        *) [ "$n" -ge 1 ] && [ "$n" -le "$count" ] && NAME=$(echo $NAMES | tr ' ' '\n' | sed -n "${n}p") ;;
    esac
    if [ -z "$NAME" ]; then
        echo "[!] Invalid choice"
        exit 1
    fi
    echo ""
fi

is_running() {
    [ "$(docker inspect --type container --format '{{.State.Running}}' "$1" 2>/dev/null)" = "true" ]
}

TARGET=$NAME
if ! is_running "$TARGET"; then
    printf '%s is not running. Restore into which running container? ' "$NAME"
    read -r TARGET
    if ! is_running "$TARGET"; then
        echo "[!] $TARGET is not a running container"
        exit 1
    fi
fi

C="$BACKUP_DIR/$NAME"
N=0
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

to_path() {
    for p in $KNOWN_PATHS; do
        s=$(echo "$p" | tr '/' '_')
        if [ "${s#_}" = "$1" ]; then
            echo "$p"
            return
        fi
    done
    case $1 in
        etc_*) echo "/etc/${1#etc_}" ;;
    esac
}

# is_dup DIR NAME: docker cp of an existing directory nests a copy of it
# (backup of /etc/nginx contains nginx/), detect that duplicate level.
is_dup() {
    [ -d "$1/$2" ] || return 1
    ls -A "$1" | grep -vxF "$2" > "$WORK/a"
    ls -A "$1/$2" > "$WORK/b"
    cmp -s "$WORK/a" "$WORK/b"
}

put() {
    src=$1; dest=$2
    [ -e "$src" ] || [ -L "$src" ] || return 0
    if [ -L "$src" ]; then
        docker exec -u 0 "$TARGET" ln -sfn "$(readlink "$src")" "$dest" 2>/dev/null
    elif [ -d "$src" ]; then
        stage="$WORK/stage"
        rm -rf "$stage"; mkdir -p "$stage"
        cp -a "$src/." "$stage/"
        is_dup "$src" "${dest##*/}" && rm -rf "${stage:?}/${dest##*/}"
        # The backup is chmod 600; give files sane modes for anything new.
        # Files that already exist in the container get their old modes back below.
        chmod -R u+rwX,go+rX,go-w "$stage"
        meta=$(docker exec -u 0 "$TARGET" sh -c '[ -e "$1" ] && find "$1" -exec stat -c "%a %u %g %n" {} +' sh "$dest" 2>/dev/null)
        docker exec -u 0 "$TARGET" mkdir -p "$dest" 2>/dev/null
        tar -C "$stage" -cf - . | docker cp - "$TARGET:$dest" 2>/dev/null
        echo "$meta" | docker exec -u 0 -i "$TARGET" sh -c 'while read -r m u g p; do
            [ -e "$p" ] && chown -h "$u:$g" "$p" && { [ -L "$p" ] || chmod "$m" "$p"; }
        done' 2>/dev/null
        rm -rf "$stage"
    else
        docker exec -u 0 -i "$TARGET" sh -c 'mkdir -p "${1%/*}" 2>/dev/null; cat > "$1.new" || exit 1
            if [ -e "$1" ]; then chown "$(stat -c %u:%g "$1")" "$1.new"; chmod "$(stat -c %a "$1")" "$1.new"; fi 2>/dev/null
            mv -f "$1.new" "$1" 2>/dev/null || { cat "$1.new" > "$1"; rm -f "$1.new"; }' sh "$dest" < "$src"
    fi
    echo "  -> $dest"
    N=$((N + 1))
}

restore_svc() {
    for svc in "$@"; do
        for f in "$C/services/$svc"/*; do
            [ -e "$f" ] || [ -L "$f" ] || continue
            dest=$(to_path "$(basename "$f")")
            [ -n "$dest" ] && put "$f" "$dest"
        done
    done
}

restore_auth() {
    put "$C/auth/etc_ssh" /etc/ssh
    restore_svc sshd
    for f in passwd shadow group gshadow; do
        put "$C/system/$f" "/etc/$f"
    done
    put "$C/auth/etc_pam.d" /etc/pam.d
    put "$C/auth/etc_ssl" /etc/ssl
    put "$C/auth/etc_sssd" /etc/sssd
    put "$C/auth/etc_krb5.conf" /etc/krb5.conf
    docker exec -u 0 "$TARGET" sh -c 'chmod 600 /etc/ssh/ssh_host_*_key' 2>/dev/null
}

restore_webroot() {
    for f in "$C/webroot"/*; do
        [ -e "$f" ] || continue
        dest=$(to_path "$(basename "$f")")
        [ -n "$dest" ] && put "$f" "$dest"
    done
}

check_status() {
    sleep 2
    STATUS=$(docker inspect --type container --format '{{.State.Status}}' "$TARGET" 2>/dev/null)
    case $STATUS in
        running)     printf '[%s RUNNING %s] %s\n' "$GRN" "$RST" "$TARGET" ;;
        restarting)  printf '[%s RESTARTING %s] %s\n' "$RED" "$RST" "$TARGET" ;;
        exited|dead) printf '[%s STOPPED %s] %s\n' "$RED" "$RST" "$TARGET" ;;
        *)           printf '[%s UNKNOWN %s] %s\n' "$GRY" "$RST" "$TARGET" ;;
    esac
    [ "$STATUS" = "running" ] || docker logs --tail 10 "$TARGET" 2>&1
}

finish() {
    if [ "$N" -eq 0 ]; then
        echo "❌ $1 not found in backup"
        return
    fi
    if [ "${2:-}" = "norestart" ]; then
        echo "✓ $1 restored"
        return
    fi
    docker restart "$TARGET" >/dev/null 2>&1
    echo "✓ $1 restored"
    check_status
}

rcli() {
    docker exec "$TARGET" sh -c '[ -n "$REDIS_PASSWORD" ] && export REDISCLI_AUTH="$REDIS_PASSWORD"; exec redis-cli --raw "$@"' sh "$@" 2>/dev/null
}

# Byte offset of "REDIS0" in the first 512 bytes (the dump may start with
# redis-cli's "Background saving started" line). BusyBox grep has no -b.
redis_offset() {
    head -c 512 "$1" 2>/dev/null | od -A n -v -t x1 | tr -s ' \n' '\n\n' | grep -v '^$' \
        | awk '{b[NR]=$1} END {for (i = 1; i <= NR - 5; i++)
              if (b[i]=="52" && b[i+1]=="45" && b[i+2]=="44" && b[i+3]=="49" && b[i+4]=="53" && b[i+5]=="30") {print i - 1; exit}}'
}

echo "Backup: $BACKUP_DIR"
if [ "$TARGET" = "$NAME" ]; then
    echo "Container: $NAME"
else
    echo "Container: $NAME -> $TARGET"
fi
echo ""
echo "AUTHENTICATION & ACCESS:"
echo "  1) SSH (/etc/ssh)"
echo "  2) Users (passwd/shadow/group)"
echo "  3) PAM (/etc/pam.d)"
echo "  4) SSL certs + SSSD + Kerberos"
echo "  5) Telnet (telnetd)"
echo ""
echo "WEB SERVERS:"
echo "  6) Apache/httpd"
echo "  7) Nginx"
echo "  8) Caddy"
echo "  9) Lighttpd"
echo "  10) Tomcat"
echo "  11) PHP-FPM"
echo ""
echo "PROXIES:"
echo "  12) HAProxy"
echo "  13) Traefik"
echo "  14) Envoy"
echo "  15) Squid"
echo ""
echo "DATABASES (config):"
echo "  16) MySQL/MariaDB"
echo "  17) PostgreSQL"
echo "  18) Redis"
echo "  19) MongoDB"
echo "  20) Memcached"
echo "  21) Elasticsearch"
echo ""
echo "MAIL:"
echo "  22) Postfix"
echo "  23) Dovecot"
echo "  24) Exim"
echo "  25) Courier"
echo ""
echo "MESSAGING:"
echo "  26) RabbitMQ"
echo "  27) Mosquitto (MQTT)"
echo ""
echo "FILE/DEV SERVICES:"
echo "  28) Samba"
echo "  29) FTP (vsftpd/proftpd)"
echo "  30) Gitea"
echo "  31) Jenkins"
echo ""
echo "NETWORK SERVICES:"
echo "  32) BIND/Named (DNS)"
echo "  33) Unbound (DNS)"
echo "  34) dnsmasq (DNS)"
echo "  35) SNMP"
echo "  36) NFS"
echo "  37) OpenVPN"
echo ""
echo "MONITORING:"
echo "  38) Grafana"
echo "  39) Prometheus"
echo "  40) InfluxDB"
echo ""
echo "WEB CONTENT:"
echo "  41) Web root (/var/www, html dirs)"
echo ""
echo "DATABASE DATA (from dumps):"
echo "  42) MySQL/MariaDB data"
echo "  43) PostgreSQL data"
echo "  44) MongoDB data"
echo "  45) Redis data"
echo ""
echo "NUCLEAR OPTIONS:"
echo "  46) All Auth (SSH + Users + PAM + SSL)"
echo "  47) All Services"
echo "  48) EVERYTHING (no database data)"
echo ""
printf 'Select [1-48]: '
read -r choice

case $choice in
    1)  echo "[*] Restoring SSH..."
        put "$C/auth/etc_ssh" /etc/ssh
        restore_svc sshd
        docker exec -u 0 "$TARGET" sh -c 'chmod 600 /etc/ssh/ssh_host_*_key' 2>/dev/null
        finish "SSH" ;;
    2)  echo "[*] Restoring users..."
        for f in passwd shadow group gshadow; do
            put "$C/system/$f" "/etc/$f"
        done
        finish "Users" norestart ;;
    3)  echo "[*] Restoring PAM..."
        put "$C/auth/etc_pam.d" /etc/pam.d
        finish "PAM" norestart ;;
    4)  echo "[*] Restoring SSL/SSSD/Kerberos..."
        put "$C/auth/etc_ssl" /etc/ssl
        put "$C/auth/etc_sssd" /etc/sssd
        put "$C/auth/etc_krb5.conf" /etc/krb5.conf
        finish "SSL/SSSD/Kerberos" ;;
    5)  echo "[*] Restoring Telnet...";        restore_svc telnetd;              finish "Telnet" ;;
    6)  echo "[*] Restoring Apache...";        restore_svc apache apache2 httpd; finish "Apache" ;;
    7)  echo "[*] Restoring Nginx...";         restore_svc nginx;                finish "Nginx" ;;
    8)  echo "[*] Restoring Caddy...";         restore_svc caddy;                finish "Caddy" ;;
    9)  echo "[*] Restoring Lighttpd...";      restore_svc lighttpd;             finish "Lighttpd" ;;
    10) echo "[*] Restoring Tomcat...";        restore_svc tomcat;               finish "Tomcat" ;;
    11) echo "[*] Restoring PHP-FPM...";       restore_svc php-fpm;              finish "PHP-FPM" ;;
    12) echo "[*] Restoring HAProxy...";       restore_svc haproxy;              finish "HAProxy" ;;
    13) echo "[*] Restoring Traefik...";       restore_svc traefik;              finish "Traefik" ;;
    14) echo "[*] Restoring Envoy...";         restore_svc envoy;                finish "Envoy" ;;
    15) echo "[*] Restoring Squid...";         restore_svc squid;                finish "Squid" ;;
    16) echo "[*] Restoring MySQL/MariaDB config..."; restore_svc mysql mysqld mariadb; finish "MySQL/MariaDB config" ;;
    17) echo "[*] Restoring PostgreSQL config...";    restore_svc postgres postgresql;  finish "PostgreSQL config" ;;
    18) echo "[*] Restoring Redis config...";  restore_svc redis;                finish "Redis config" ;;
    19) echo "[*] Restoring MongoDB config..."; restore_svc mongod;              finish "MongoDB config" ;;
    20) echo "[*] Restoring Memcached...";     restore_svc memcached;            finish "Memcached" ;;
    21) echo "[*] Restoring Elasticsearch..."; restore_svc elasticsearch;        finish "Elasticsearch" ;;
    22) echo "[*] Restoring Postfix...";       restore_svc postfix;              finish "Postfix" ;;
    23) echo "[*] Restoring Dovecot...";       restore_svc dovecot;              finish "Dovecot" ;;
    24) echo "[*] Restoring Exim...";          restore_svc exim exim4;           finish "Exim" ;;
    25) echo "[*] Restoring Courier...";       restore_svc courier;              finish "Courier" ;;
    26) echo "[*] Restoring RabbitMQ...";      restore_svc rabbitmq;             finish "RabbitMQ" ;;
    27) echo "[*] Restoring Mosquitto...";     restore_svc mosquitto;            finish "Mosquitto" ;;
    28) echo "[*] Restoring Samba...";         restore_svc samba smbd nmbd;      finish "Samba" ;;
    29) echo "[*] Restoring FTP...";           restore_svc vsftpd proftpd;       finish "FTP" ;;
    30) echo "[*] Restoring Gitea...";         restore_svc gitea;                finish "Gitea" ;;
    31) echo "[*] Restoring Jenkins...";       restore_svc jenkins;              finish "Jenkins" ;;
    32) echo "[*] Restoring BIND...";          restore_svc bind bind9 named;     finish "BIND" ;;
    33) echo "[*] Restoring Unbound...";       restore_svc unbound;              finish "Unbound" ;;
    34) echo "[*] Restoring dnsmasq...";       restore_svc dnsmasq;              finish "dnsmasq" ;;
    35) echo "[*] Restoring SNMP...";          restore_svc snmpd;                finish "SNMP" ;;
    36) echo "[*] Restoring NFS...";           restore_svc nfs;                  finish "NFS" ;;
    37) echo "[*] Restoring OpenVPN...";       restore_svc openvpn;              finish "OpenVPN" ;;
    38) echo "[*] Restoring Grafana...";       restore_svc grafana;              finish "Grafana" ;;
    39) echo "[*] Restoring Prometheus...";    restore_svc prometheus;           finish "Prometheus" ;;
    40) echo "[*] Restoring InfluxDB...";      restore_svc influxd;              finish "InfluxDB" ;;
    41) echo "[*] Restoring web root...";      restore_webroot;                  finish "Web root" ;;
    42)
        f="$C/database_dumps/all_databases.sql"
        if [ ! -s "$f" ]; then
            echo "❌ No MySQL dump in backup"
            exit 1
        fi
        echo "[*] Restoring MySQL/MariaDB data..."
        { cat "$f"; echo "FLUSH PRIVILEGES;"; } | docker exec -i "$TARGET" sh -c '
            MYSQL_PWD=${MYSQL_ROOT_PASSWORD:-$MARIADB_ROOT_PASSWORD}; export MYSQL_PWD
            exec $(command -v mariadb || command -v mysql) -uroot' && echo "✓ MySQL/MariaDB data restored"
        ;;
    43)
        f="$C/database_dumps/pg_dumpall.sql"
        if [ ! -s "$f" ]; then
            echo "❌ No PostgreSQL dump in backup"
            exit 1
        fi
        echo "[!] Only use on an empty PostgreSQL server - the dump does not drop existing databases"
        printf 'Continue with PostgreSQL restore? [y/N]: '
        read -r response
        case "$response" in
            [Yy])
                echo "[*] Restoring PostgreSQL data..."
                docker exec -i "$TARGET" sh -c 'PGPASSWORD=$POSTGRES_PASSWORD exec psql -q -U "${POSTGRES_USER:-postgres}" -d postgres' < "$f" >/dev/null
                echo "✓ PostgreSQL data restored (a 'role already exists' error is normal)"
                ;;
            *) echo "PostgreSQL restore cancelled" ;;
        esac
        ;;
    44)
        f="$C/database_dumps/mongo_dump.archive"
        if [ ! -s "$f" ]; then
            echo "❌ No MongoDB dump in backup"
            exit 1
        fi
        echo "[*] Restoring MongoDB data..."
        docker exec -i "$TARGET" sh -c 'exec mongorestore --archive --drop ${MONGO_INITDB_ROOT_USERNAME:+--username "$MONGO_INITDB_ROOT_USERNAME" --password "$MONGO_INITDB_ROOT_PASSWORD" --authenticationDatabase admin}' < "$f" 2>&1 | tail -n 1
        echo "✓ MongoDB data restored"
        ;;
    45)
        f="$C/database_dumps/redis_dump.rdb"
        off=$(redis_offset "$f")
        dir=$(rcli CONFIG GET dir | sed -n 2p)
        file=$(rcli CONFIG GET dbfilename | sed -n 2p)
        if [ -z "$off" ] || [ -z "$dir" ] || [ -z "$file" ]; then
            echo "❌ No usable Redis dump in backup, or redis-cli not reachable"
            exit 1
        fi
        echo "[*] Restoring Redis data..."
        [ "$(rcli CONFIG GET appendonly | sed -n 2p)" = "yes" ] && echo "[!] appendonly is on - Redis will load its AOF instead of this dump"
        rcli CONFIG SET save "" >/dev/null
        tail -c +$((off + 1)) "$f" | docker exec -u 0 -i "$TARGET" sh -c 'cat > "$1"' sh "$dir/$file"
        docker restart "$TARGET" >/dev/null 2>&1
        echo "✓ Redis data restored (container restarted)"
        check_status
        ;;
    46)
        echo "[*] RESTORING ALL AUTH..."
        restore_auth
        finish "ALL AUTH"
        ;;
    47)
        echo "[*] RESTORING ALL SERVICES..."
        # shellcheck disable=SC2086
        restore_svc $TARGETS
        finish "ALL SERVICES"
        ;;
    48)
        echo "[*] NUCLEAR RESTORE - EVERYTHING..."
        restore_auth
        # shellcheck disable=SC2086
        restore_svc $TARGETS
        restore_webroot
        finish "EVERYTHING"
        ;;
    *)
        echo "[!] Invalid choice"
        exit 1
        ;;
esac

echo ""
