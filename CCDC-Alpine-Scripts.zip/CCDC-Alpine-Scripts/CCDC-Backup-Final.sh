#!/bin/sh
# CCDC-Backup-Final.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Backs up auth, SSH, network, service configs, OpenRC/cron, web content,
# apk state, critical binaries and a process/port baseline to
# /root/Injects_<host>_<time>. Restore with CCDC-Restore-Final.sh.

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
   echo "[!] This script must be run as root (su or doas)"
   exit 1
fi

ESC=$(printf '\033')
GRN="${ESC}[32m"; YEL="${ESC}[33m"; RED="${ESC}[31m"; RST="${ESC}[0m"

get_web_user() {
    for u in apache nginx lighttpd www-data; do
        id "$u" >/dev/null 2>&1 && { echo "$u"; return; }
    done
    echo "root"
}

find_bin() {
    for dir in /usr/bin /usr/sbin /bin /sbin; do
        if [ -e "$dir/$1" ]; then echo "$dir/$1"; return; fi
    done
}

# tgz OUT PATH... : archive only the paths that exist (BusyBox tar stops on missing ones)
tgz() {
    out=$1; shift
    list=""
    for p in "$@"; do [ -e "$p" ] && list="$list $p"; done
    [ -n "$list" ] || return 1
    # shellcheck disable=SC2086
    tar -czf "$out" $list 2>/dev/null
}

svc_status() { rc-service "$1" status 2>/dev/null | sed -n 's/.*status: *//p' | head -n1; }

DISTRO_FAMILY="alpine"
WEB_USER=$(get_web_user)
HOSTNAME=$(hostname || echo "unknown_host")
TIMESTAMP=$(date +%Y%m%d_%H%M)
BACKUP_ROOT="/root/Injects_${HOSTNAME}_${TIMESTAMP}"

mkdir -p -m 700 "$BACKUP_ROOT"
echo "--- Starting Aggressive Backup for $HOSTNAME ---"
echo "    Detected distro: Alpine $(cat /etc/alpine-release 2>/dev/null)"

echo "$DISTRO_FAMILY" > "$BACKUP_ROOT/.distro_family"
echo "$WEB_USER" > "$BACKUP_ROOT/.web_user"

mkdir -p "$BACKUP_ROOT/system"
for f in /etc/passwd /etc/shadow /etc/group /etc/gshadow /etc/sudoers /etc/doas.conf \
         /etc/sysctl.conf /etc/fstab /etc/resolv.conf /etc/hosts /etc/hostname \
         /etc/securetty /etc/shells /etc/login.defs /etc/nsswitch.conf; do
    [ -f "$f" ] && cp -p "$f" "$BACKUP_ROOT/system/" 2>/dev/null
done
tgz "$BACKUP_ROOT/system/pam_configs.tar.gz" /etc/pam.d
tgz "$BACKUP_ROOT/system/sudoers_d.tar.gz" /etc/sudoers.d
tgz "$BACKUP_ROOT/system/doas_d.tar.gz" /etc/doas.d
tgz "$BACKUP_ROOT/system/sysctl_d.tar.gz" /etc/sysctl.d

mkdir -p "$BACKUP_ROOT/shell"
echo "[*] Backing up shell configs..."
[ -f "/etc/bash/bashrc" ] && cp /etc/bash/bashrc "$BACKUP_ROOT/shell/etc_bash_bashrc"
[ -f "/etc/bash.bashrc" ] && cp /etc/bash.bashrc "$BACKUP_ROOT/shell/"
[ -f "/etc/bashrc" ] && cp /etc/bashrc "$BACKUP_ROOT/shell/"
[ -f "/etc/profile" ] && cp /etc/profile "$BACKUP_ROOT/shell/"
tgz "$BACKUP_ROOT/shell/profile_d.tar.gz" /etc/profile.d
[ -f "/root/.bashrc" ] && cp /root/.bashrc "$BACKUP_ROOT/shell/root_bashrc"
[ -f "/root/.bash_profile" ] && cp /root/.bash_profile "$BACKUP_ROOT/shell/root_bash_profile"
[ -f "/root/.profile" ] && cp /root/.profile "$BACKUP_ROOT/shell/root_profile"
[ -f "/root/.ashrc" ] && cp /root/.ashrc "$BACKUP_ROOT/shell/root_ashrc"
[ -f "/root/.bash_aliases" ] && cp /root/.bash_aliases "$BACKUP_ROOT/shell/root_bash_aliases"
find /home -maxdepth 2 -type f \( -name ".bashrc" -o -name ".bash_profile" -o -name ".profile" -o -name ".ashrc" \) 2>/dev/null | while read -r rc; do
    user=$(echo "$rc" | cut -d'/' -f3)
    filename=$(basename "$rc")
    cp "$rc" "$BACKUP_ROOT/shell/${user}_${filename}" 2>/dev/null
done
echo "  ✓ Shell configs backed up"

mkdir -p "$BACKUP_ROOT/auth"
echo "[*] Capturing SSSD, KRB5, LDAP client and NSS..."
tgz "$BACKUP_ROOT/auth/sssd_etc.tar.gz" /etc/sssd
tgz "$BACKUP_ROOT/auth/sssd_cache.tar.gz" /var/lib/sss
[ -f "/etc/nsswitch.conf" ] && cp /etc/nsswitch.conf "$BACKUP_ROOT/auth/"
[ -f "/etc/openldap/ldap.conf" ] && cp /etc/openldap/ldap.conf "$BACKUP_ROOT/auth/ldap_openldap.conf"
[ -f "/etc/samba/smb.conf" ] && cp /etc/samba/smb.conf "$BACKUP_ROOT/auth/"
tgz "$BACKUP_ROOT/auth/samba_secrets.tar.gz" /var/lib/samba/private
tgz "$BACKUP_ROOT/auth/realmd.tar.gz" /var/lib/realmd
[ -f "/etc/krb5.conf" ] && cp /etc/krb5.conf "$BACKUP_ROOT/auth/"
tgz "$BACKUP_ROOT/auth/krb5_conf_d.tar.gz" /etc/krb5.conf.d
[ -f "/etc/krb5.keytab" ] && cp -p /etc/krb5.keytab "$BACKUP_ROOT/auth/machine.keytab"

mkdir -p "$BACKUP_ROOT/ssh"
cp -rp /etc/ssh/* "$BACKUP_ROOT/ssh/" 2>/dev/null
[ -f /etc/conf.d/sshd ] && cp -p /etc/conf.d/sshd "$BACKUP_ROOT/ssh/conf.d_sshd"
find /home /root -name ".ssh" -type d 2>/dev/null | while read -r dir; do
    user_name=$(basename "$(dirname "$dir")")
    tar -czf "$BACKUP_ROOT/ssh/keys_${user_name}.tar.gz" "$dir" 2>/dev/null
done

mkdir -p "$BACKUP_ROOT/network"
command -v iptables-save >/dev/null 2>&1 && iptables-save > "$BACKUP_ROOT/network/iptables.rules" 2>/dev/null
command -v ip6tables-save >/dev/null 2>&1 && ip6tables-save > "$BACKUP_ROOT/network/ip6tables.rules" 2>/dev/null
command -v nft >/dev/null 2>&1 && nft list ruleset > "$BACKUP_ROOT/network/nft.rules" 2>/dev/null
# Rule files the OpenRC iptables/nftables services load at boot, and awall policies
tgz "$BACKUP_ROOT/network/firewall_etc.tar.gz" /etc/iptables /etc/nftables.nft /etc/nftables.d /etc/awall /etc/conf.d/iptables /etc/conf.d/ip6tables /etc/conf.d/nftables

echo "[*] Backing up network routes and interfaces..."
ip route show > "$BACKUP_ROOT/network/routes.txt" 2>/dev/null
ip addr show > "$BACKUP_ROOT/network/addresses.txt" 2>/dev/null
[ -f "/etc/network/interfaces" ] && cp /etc/network/interfaces "$BACKUP_ROOT/network/" 2>/dev/null
tgz "$BACKUP_ROOT/network/interfaces_d.tar.gz" /etc/network/interfaces.d
tgz "$BACKUP_ROOT/network/network_hooks.tar.gz" /etc/network/if-up.d /etc/network/if-down.d /etc/network/if-pre-up.d /etc/network/if-post-down.d
tgz "$BACKUP_ROOT/network/NetworkManager.tar.gz" /etc/NetworkManager
tgz "$BACKUP_ROOT/network/wpa_supplicant.tar.gz" /etc/wpa_supplicant
echo "  ✓ Network routes and interfaces backed up"

mkdir -p "$BACKUP_ROOT/init"
echo "[*] Backing up OpenRC services, runlevels and cron (common persistence spots)..."
tgz "$BACKUP_ROOT/init/openrc.tar.gz" /etc/init.d /etc/conf.d /etc/runlevels /etc/local.d /etc/inittab /etc/rc.conf
tgz "$BACKUP_ROOT/init/cron.tar.gz" /etc/crontabs /etc/periodic /var/spool/cron
rc-status -a > "$BACKUP_ROOT/init/rc-status.txt" 2>/dev/null
rc-update show -v > "$BACKUP_ROOT/init/rc-update.txt" 2>/dev/null
echo "  ✓ OpenRC and cron backed up"

mkdir -p "$BACKUP_ROOT/services"
TARGETS="dovecot postfix exim exim4 nginx apache apache2 httpd lighttpd mysql mariadb postgresql bind bind9 named vsftpd proftpd samba smb snmpd nfs-server nfs-kernel-server nfs openvpn telnetd caddy gitea courier unbound dnsmasq openldap slapd php redis haproxy squid fail2ban docker"

# Extra paths for services whose config doesn't live in /etc/<name>* on Alpine
extra_paths() {
    case "$1" in
        mysql|mariadb) echo "/etc/my.cnf /etc/my.cnf.d /etc/conf.d/mariadb" ;;
        postgresql)    ls -d /var/lib/postgresql/*/data/*.conf 2>/dev/null; echo "/etc/conf.d/postgresql" ;;
        snmpd)         echo "/etc/snmp" ;;
        nfs)           echo "/etc/exports /etc/exports.d /etc/conf.d/nfs" ;;
        slapd)         echo "/etc/openldap /etc/conf.d/slapd" ;;
        gitea)         echo "/etc/gitea /etc/conf.d/gitea" ;;
        named)         echo "/etc/bind /etc/conf.d/named" ;;
        samba)         echo "/etc/conf.d/samba" ;;
        vsftpd)        echo "/etc/vsftpd /etc/vsftpd.userlist /etc/conf.d/vsftpd" ;;
        nginx)         echo "/etc/conf.d/nginx" ;;
        apache2)       echo "/etc/conf.d/apache2" ;;
        docker)        echo "/etc/docker /etc/conf.d/docker" ;;
    esac
}

backup_service() {
    svc=$1
    # shellcheck disable=SC2086
    CONF_PATHS="$(ls -d /etc/${svc}* 2>/dev/null) $(extra_paths "$svc")"
    # shellcheck disable=SC2086
    tgz "$BACKUP_ROOT/services/${svc}_etc.tar.gz" $CONF_PATHS
}

echo "[*] Backing up standard services..."
for svc in $TARGETS; do
    backup_service "$svc"
done

printf '\n[*] Detecting services not in backup list...\n'
RUNNING_SERVICES=$(rc-status --servicelist 2>/dev/null | awk '/started/ {print $1}')
UNLISTED=""
SYSTEM_EXCLUDE="^(devfs|dmesg|mdev|hwdrivers|modules|modloop|sysctl|hostname|bootmisc|syslog|klogd|networking|urandom|seedrng|swap|localmount|fsck|root|mount-ro|killprocs|savecache|acpid|crond|chronyd|ntpd|udev|udev-trigger|udev-settle|udev-postmount|cgroups|loopback|sysfs|procfs|termencoding|keymaps|hwclock|swclock|firstboot|local|machine-id|osclock|staticroute|iptables|ip6tables|nftables|auditd|rsyslog|sshd|dbus|elogind|polkit|cloud-init|cloud-config|cloud-final|qemu-guest-agent|open-vm-tools|haveged|wpa_supplicant|agetty|getty|tinyssh).*$"

for running in $RUNNING_SERVICES; do
    echo "$running" | grep -Eq "$SYSTEM_EXCLUDE" && continue
    FOUND=0
    for target in $TARGETS; do
        case "$running" in *"$target"*) FOUND=1; break ;; esac
    done
    [ $FOUND -eq 0 ] && UNLISTED="$UNLISTED $running"
done

if [ -n "$UNLISTED" ]; then
    printf '\n[%s NOTICE %s] Found services not in backup list:\n' "$YEL" "$RST"
    for svc in $UNLISTED; do
        echo "  - $svc"
    done
    printf '\nBackup these services? [y/N]: '
    read -r response
    case "$response" in
        [Yy])
            for svc in $UNLISTED; do
                echo "[*] Backing up $svc..."
                # shellcheck disable=SC2086
                tgz "$BACKUP_ROOT/services/${svc}_etc.tar.gz" $(ls -d /etc/${svc}* 2>/dev/null) "/etc/init.d/$svc" "/etc/conf.d/$svc"
            done
            echo "✓ Additional services backed up"
            ;;
        *) echo "Skipping additional services" ;;
    esac
fi

mkdir -p "$BACKUP_ROOT/binaries"
echo "[*] Backing up critical binaries..."
# Most Alpine tools are symlinks to /bin/busybox, so the REAL file behind each
# name is saved once, together with its mode and the symlink layout.
CRITICAL_BIN_NAMES="busybox bbsuid apk sudo doas su sshd ssh login passwd useradd usermod adduser deluser ps netstat ss ls find grep sh ash bash"
: > "$BACKUP_ROOT/binaries/MANIFEST.txt"
: > "$BACKUP_ROOT/binaries/SYMLINKS.txt"
for name in $CRITICAL_BIN_NAMES; do
    bin_path=$(find_bin "$name")
    [ -n "$bin_path" ] || continue
    real=$(readlink -f "$bin_path")
    [ -f "$real" ] || continue
    [ -L "$bin_path" ] && echo "$bin_path $(readlink "$bin_path")" >> "$BACKUP_ROOT/binaries/SYMLINKS.txt"
    store="$BACKUP_ROOT/binaries/$(basename "$real")"
    if ! awk -v r="$real" '$NF==r {f=1} END {exit !f}' "$BACKUP_ROOT/binaries/MANIFEST.txt"; then
        cp -p "$real" "$store" 2>/dev/null && \
            echo "$(basename "$real") $(stat -c '%a %u %g' "$real") $real" >> "$BACKUP_ROOT/binaries/MANIFEST.txt"
    fi
done
# Every symlink in the system bin dirs: lets the restore check spot a repointed /bin/ls
for d in /bin /sbin /usr/bin /usr/sbin; do
    for l in "$d"/*; do [ -L "$l" ] && echo "$l $(readlink "$l")"; done
done > "$BACKUP_ROOT/binaries/ALL_SYMLINKS.txt" 2>/dev/null
(cd "$BACKUP_ROOT/binaries" && for f in *; do
    case "$f" in *.txt) continue ;; esac
    sha256sum "$f"
 done) > "$BACKUP_ROOT/binaries/HASHES.txt"

mkdir -p "$BACKUP_ROOT/webroot"
echo "[*] Backing up web content..."
[ -d "/var/www" ] && tar -czf "$BACKUP_ROOT/webroot/var_www.tar.gz" /var/www 2>/dev/null && echo "  ✓ /var/www backed up"
[ -d "/var/lib/nginx/html" ] && tar -czf "$BACKUP_ROOT/webroot/nginx_html.tar.gz" /var/lib/nginx/html 2>/dev/null && echo "  ✓ /var/lib/nginx/html backed up"
[ -d "/usr/share/nginx/html" ] && tar -czf "$BACKUP_ROOT/webroot/usr_share_nginx_html.tar.gz" /usr/share/nginx/html 2>/dev/null && echo "  ✓ /usr/share/nginx/html backed up"
[ -d "/usr/share/webapps" ] && tar -czf "$BACKUP_ROOT/webroot/webapps.tar.gz" /usr/share/webapps 2>/dev/null && echo "  ✓ /usr/share/webapps backed up"
[ -d "/srv/www" ] && tar -czf "$BACKUP_ROOT/webroot/srv_www.tar.gz" /srv/www 2>/dev/null && echo "  ✓ /srv/www backed up"

mkdir -p "$BACKUP_ROOT/webapps"
echo "[*] Detecting web applications..."

WP_ROOT=$(find /var/www /var/lib/nginx/html /usr/share/nginx/html /usr/share/webapps /opt -name "wp-config.php" 2>/dev/null | head -n1)
if [ -n "$WP_ROOT" ]; then
    WP_ROOT=$(dirname "$WP_ROOT")
    echo "  - WordPress detected ($WP_ROOT)"
    cp "$WP_ROOT/wp-config.php" "$BACKUP_ROOT/webapps/" 2>/dev/null
    tar -czf "$BACKUP_ROOT/webapps/wordpress_content.tar.gz" "$WP_ROOT/wp-content" 2>/dev/null
    [ -f "$WP_ROOT/.htaccess" ] && cp "$WP_ROOT/.htaccess" "$BACKUP_ROOT/webapps/wordpress_htaccess"
    echo "$WP_ROOT" > "$BACKUP_ROOT/webapps/wordpress_root.txt"
fi

if [ -x /etc/init.d/gitea ] || command -v gitea >/dev/null 2>&1; then
    echo "  - Gitea detected"
    GITEA_CONF=$(find /etc -name "app.ini" -path "*/gitea/*" 2>/dev/null | head -n1)
    [ -n "$GITEA_CONF" ] && cp "$GITEA_CONF" "$BACKUP_ROOT/webapps/gitea_app.ini" 2>/dev/null
    [ -d "/opt/gitea" ] && tar -czf "$BACKUP_ROOT/webapps/gitea_data.tar.gz" /opt/gitea 2>/dev/null
    [ -d "/var/lib/gitea" ] && tar -czf "$BACKUP_ROOT/webapps/gitea_lib.tar.gz" /var/lib/gitea 2>/dev/null
fi

RAINLOOP_ROOT=$(find /var/www /var/lib/nginx /usr/share/nginx /usr/share/webapps -type d \( -name "rainloop" -o -name "snappymail" \) 2>/dev/null | head -n1)
if [ -n "$RAINLOOP_ROOT" ]; then
    echo "  - Rainloop/SnappyMail detected"
    tar -czf "$BACKUP_ROOT/webapps/rainloop_data.tar.gz" "$RAINLOOP_ROOT/data" 2>/dev/null
fi

if [ -d "/var/www/jekyll" ] || [ -d "/srv/jekyll" ]; then
    echo "  - Jekyll detected"
    JEKYLL_ROOT=$(find /var/www /srv -type d \( -name "jekyll" -o -name "_site" \) 2>/dev/null | head -n1)
    [ -n "$JEKYLL_ROOT" ] && tar -czf "$BACKUP_ROOT/webapps/jekyll_site.tar.gz" "$JEKYLL_ROOT" 2>/dev/null
fi

if [ -x /etc/init.d/filestash ] || [ -d /etc/filestash ]; then
    echo "  - Filestash detected"
    [ -d "/etc/filestash" ] && tar -czf "$BACKUP_ROOT/webapps/filestash_config.tar.gz" /etc/filestash 2>/dev/null
fi

mkdir -p "$BACKUP_ROOT/packages"
echo "[*] Backing up package manager data..."
tgz "$BACKUP_ROOT/packages/apk_etc.tar.gz" /etc/apk
cp /etc/apk/world "$BACKUP_ROOT/packages/world" 2>/dev/null
cp /etc/apk/repositories "$BACKUP_ROOT/packages/repositories" 2>/dev/null
apk info -v 2>/dev/null | sort > "$BACKUP_ROOT/packages/apk_installed.txt"
echo "  ✓ Package manager backed up"

mkdir -p "$BACKUP_ROOT/baseline"
echo "[*] Recording Auth Status & Processes..."
if ps auxf >/dev/null 2>&1; then
    ps auxf > "$BACKUP_ROOT/baseline/processes.txt"
else
    ps -o pid,ppid,user,stat,time,args > "$BACKUP_ROOT/baseline/processes.txt" 2>/dev/null || ps > "$BACKUP_ROOT/baseline/processes.txt"
fi
if command -v ss >/dev/null 2>&1; then
    ss -plunt > "$BACKUP_ROOT/baseline/ports.txt" 2>/dev/null
else
    netstat -plunt > "$BACKUP_ROOT/baseline/ports.txt" 2>/dev/null
fi
command -v realm >/dev/null 2>&1 && realm list > "$BACKUP_ROOT/baseline/domain_status.txt" 2>/dev/null
command -v adcli >/dev/null 2>&1 && adcli info "$(hostname -d 2>/dev/null)" >> "$BACKUP_ROOT/baseline/domain_status.txt" 2>/dev/null

printf '\n--- VERIFICATION REPORT ---\n'
CHECK_LIST="ssh passwd shadow apk openrc"
[ -d /etc/sssd ] && CHECK_LIST="$CHECK_LIST sssd"
[ -f /etc/nsswitch.conf ] && CHECK_LIST="$CHECK_LIST nsswitch"
[ -f /etc/krb5.conf ] && CHECK_LIST="$CHECK_LIST krb5"
[ -d /etc/pam.d ] && CHECK_LIST="$CHECK_LIST pam"
for item in $CHECK_LIST; do
    if find "$BACKUP_ROOT" -name "*$item*" 2>/dev/null | grep -q "$item"; then
        printf '[%s OK %s] %s found.\n' "$GRN" "$RST" "$item"
    else
        printf '[%s MISSING %s] %s NOT FOUND.\n' "$RED" "$RST" "$item"
    fi
done

printf '\n--- SERVICE STATUS (OpenRC) ---\n'
for svc in $TARGETS $UNLISTED; do
    [ -x "/etc/init.d/$svc" ] || continue
    STATUS=$(svc_status "$svc")
    case $STATUS in
        started)          printf '[%s ACTIVE %s] %s\n' "$GRN" "$RST" "$svc" ;;
        stopped|inactive) printf '[%s INACTIVE %s] %s\n' "$YEL" "$RST" "$svc" ;;
        crashed)          printf '[%s FAILED %s] %s\n' "$RED" "$RST" "$svc" ;;
    esac
done

# Private to root (directories stay traversable; saved binaries keep their x bit)
chmod -R go-rwx "$BACKUP_ROOT"
chmod 700 "$BACKUP_ROOT"
printf '\n--- Backup Complete: %s ---\n' "$BACKUP_ROOT"
