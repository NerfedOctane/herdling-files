#!/bin/sh
# ftp_user_create_secure.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Creates local users from a list file and gives every new account the same
# pre-computed password hash. Uses BusyBox adduser/chpasswd (no shadow package needed).
#
# Usage: ./ftp_user_create_secure.sh <userlist.txt>
#set -x # THIS IS FOR DEBUG PURPOSES. LEAVE DISABLED

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

# REPLACE THIS HASH WITH THE ONE THEY PROVIDE. THIS IS JUST THE ONE FROM NOTION
# ($6$ = SHA-512 crypt, which musl/Alpine supports)
secure_hash='$6$iB45nMgzciz4NZ6A$hus0EIqQG7K/W3LmpC9qbhlB5B1q6KcXExvrAv1vfL3XbvLtU92ItaB0E3nmRh1HUYQxWydEUFkbgjSGqgpl0/'

if [ -z "${1:-}" ]; then
    echo "ERROR: No user list file provided."
    echo "Usage: $0 <userlist.txt>"
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: run as root (use su or doas)." >&2
    exit 1
fi

filepath=$(readlink -f "$1")
if [ ! -f "$filepath" ]; then
    echo "ERROR: user list not found: $1" >&2
    exit 1
fi

# Basic sanity check
if [ -z "$secure_hash" ]; then
    echo "secure_hash is empty. Set secure_hash to the precomputed encrypted hash." >&2
    exit 2
fi

if command -v lsattr >/dev/null 2>&1 && lsattr /etc/shadow 2>/dev/null | awk '{print $1}' | grep -q i; then
    echo "ERROR: /etc/shadow is immutable. Unlock it first: chattr -i /etc/shadow" >&2
    exit 1
fi

#this creates valid users from the provided userlist with the predefined hash. THE PASS IS TEMPORARY
#note: this creates users locally. A dedicated script for creating local users for scoring isn't necessary.
while IFS= read -r user || [ -n "$user" ]; do
    user=$(printf '%s' "$user" | tr -d ' \t\r')
    # Skip empty lines
    [ -z "$user" ] && continue

    # If user does NOT exist
    if ! id "$user" >/dev/null 2>&1; then
        # -D: no password prompt (account starts locked); a home dir is created by default
        if adduser -D "$user"; then
            echo "$user:$secure_hash" | chpasswd -e
            echo "  Created user: $user with predefined hash."
        else
            echo "  ERROR: could not create '$user'." >&2
        fi
    else
        echo "  WARNING: '$user' already exists."
    fi
done < "$filepath"

#UNUSED. If you need to do /etc/shadow surgery, just...uncomment all this
# make backup of /etc/shadow in case we break something
#echo "CREATING BACKUP OF /ETC/SHADOW"
#cp -p /etc/shadow /etc/shadow.bak
# this backup should preserve the permissions. No tomfoolery with the perms needed here.
#echo "DONE"
