#!/bin/sh
#
# mass_user_keep.sh - Alpine Linux version (POSIX sh / BusyBox ash, no bash needed)
#
# Takes a list of users to KEEP (include system users!) and deletes every
# other local account in /etc/passwd.
#
# Usage: ./mass_user_keep.sh [-n] [-y] [-k] <keeplist.txt>
#   -n  dry run: show what would be deleted, change nothing
#   -y  skip the confirmation prompt
#   -k  kill a user's processes before deleting them
#
# Keep-list format: one username per line. Blank lines and '#' comments are
# ignored, surrounding whitespace and Windows line endings are stripped.
#
# Stock Alpine system accounts you almost certainly want in the keep list:
#   root bin daemon adm lp sync shutdown halt mail news uucp operator man
#   postmaster cron ftp sshd at squid xfs games cyrus vpopmail ntp smmsp
#   guest nobody   (plus service accounts such as nginx apache mysql ldap
#   dovecot postfix named redis docker ... for whatever is installed)
#
# Safety nets (always on, regardless of the keep list):
#   - root, the user who invoked sudo/doas, and the user you logged in as are
#     never deleted
#   - a home directory is only removed if it is under /home and owned by the
#     user being deleted. On Alpine, service accounts own their data
#     directories as "home" (mysql -> /var/lib/mysql, nginx -> /var/lib/nginx),
#     so removing any other home could wipe a scored service's data.
#
# Uses userdel if the 'shadow' package is installed, otherwise BusyBox deluser.

if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi

set -u

error() { echo "[ERROR] $*" >&2; exit 1; }
info()  { echo "[*] $*"; }

usage() {
    echo "Usage: $0 [-n] [-y] [-k] <keeplist.txt>"
    echo "  keeplist.txt - list of users to KEEP; every other local user is deleted"
    echo "  -n  dry run    -y  no confirmation    -k  kill user processes first"
    exit 1
}

DRY_RUN=0
ASSUME_YES=0
KILL_PROCS=0
while getopts ":nyk" opt; do
    case "$opt" in
        n) DRY_RUN=1 ;;
        y) ASSUME_YES=1 ;;
        k) KILL_PROCS=1 ;;
        *) usage ;;
    esac
done
shift $((OPTIND - 1))

# ---------------------------
# Pre-flight checks
# ---------------------------
[ -z "${1:-}" ] && usage

if [ "$(id -u)" -ne 0 ] && [ "$DRY_RUN" -eq 0 ]; then
    error "This script must be run as root (use su or doas)."
fi

KEEPLIST_INPUT="$1"
[ -f "$KEEPLIST_INPUT" ] || error "Keep list file not found: $KEEPLIST_INPUT"

# ---------------------------
# Build keep set: a space-padded word list, " root bin daemon ... "
# ---------------------------
KEEP=" "
keep_add() { case "$KEEP" in *" $1 "*) ;; *) KEEP="$KEEP$1 " ;; esac; }
is_kept()  { case "$KEEP" in *" $1 "*) return 0 ;; esac; return 1; }

while IFS= read -r line || [ -n "$line" ]; do
    line=${line%%#*}                                  # strip comments
    line=$(printf '%s' "$line" | tr -d ' \t\r')       # strip whitespace and CR
    [ -z "$line" ] && continue
    keep_add "$line"
done < "$KEEPLIST_INPUT"

# Hard-coded safety: never delete root, whoever ran sudo/doas, or the login user
keep_add root
[ -n "${SUDO_USER:-}" ] && keep_add "$SUDO_USER"
[ -n "${DOAS_USER:-}" ] && keep_add "$DOAS_USER"
login_user=$(logname 2>/dev/null || true)
[ -n "$login_user" ] && keep_add "$login_user"

keep_count=$(echo $KEEP | wc -w)
[ "$keep_count" -le 2 ] && info "WARNING: keep list only contains root/invoking user - did you forget system users?"

# Warn about keep-list entries that don't exist (likely typos)
for u in $KEEP; do
    getent passwd "$u" >/dev/null 2>&1 || info "Note: '$u' is in keep list but does not exist on this system"
done

# ---------------------------
# Determine users to delete (local accounts only)
# ---------------------------
TO_DELETE=""
while IFS=: read -r user _ _ _ _ _ _; do
    [ -z "$user" ] && continue
    case "$user" in \#*) continue ;; esac
    is_kept "$user" && continue
    TO_DELETE="$TO_DELETE $user"
done < /etc/passwd

del_count=$(echo $TO_DELETE | wc -w)
if [ "$del_count" -eq 0 ]; then
    info "Nothing to delete - every local user is in the keep list."
    exit 0
fi

info "The following $del_count user(s) will be DELETED:"
for u in $TO_DELETE; do
    printf '    %-20s uid=%-6s home=%s\n' "$u" "$(id -u "$u" 2>/dev/null)" "$(getent passwd "$u" | cut -d: -f6)"
done

if [ "$DRY_RUN" -eq 1 ]; then
    info "Dry run - no changes made."
    exit 0
fi

if [ "$ASSUME_YES" -eq 0 ]; then
    printf 'Proceed? [y/N] '
    read -r ans
    case "$ans" in [Yy]) ;; *) info "Aborted."; exit 0 ;; esac
fi

if command -v lsattr >/dev/null 2>&1 && lsattr /etc/shadow 2>/dev/null | awk '{print $1}' | grep -q i; then
    error "/etc/shadow is immutable. Unlock it first: chattr -i /etc/shadow (and chattr +i it again afterwards)"
fi

# ---------------------------
# Helpers
# ---------------------------
# Only plain directories under /home may be removed along with the account.
home_removable() {
    p=$(readlink -f "$1" 2>/dev/null || echo "$1")
    case "$p" in
        /home/?*) return 0 ;;
    esac
    return 1
}

# Kill every process whose real UID is $1 (BusyBox pkill can't always match numeric UIDs)
kill_uid() {
    for d in /proc/[0-9]*; do
        pu=$(awk '/^Uid:/{print $2; exit}' "$d/status" 2>/dev/null)
        [ "$pu" = "$1" ] && kill -9 "${d#/proc/}" 2>/dev/null
    done
    return 0
}

# delete_user NAME REMOVE_HOME(0|1) FORCE(0|1)
delete_user() {
    if command -v userdel >/dev/null 2>&1; then
        if [ "$2" -eq 1 ] && [ "$3" -eq 1 ]; then userdel -r -f "$1"
        elif [ "$2" -eq 1 ]; then userdel -r "$1"
        elif [ "$3" -eq 1 ]; then userdel -f "$1"
        else userdel "$1"; fi
    else
        # BusyBox deluser doesn't check for running processes, so FORCE isn't needed
        if [ "$2" -eq 1 ]; then deluser --remove-home "$1"; else deluser "$1"; fi
    fi
}

# ---------------------------
# Delete
# ---------------------------
deleted=0; failed=0
for user in $TO_DELETE; do
    uid=$(id -u "$user" 2>/dev/null) || { info "Skipping $user (no longer exists)"; continue; }
    home=$(getent passwd "$user" | cut -d: -f6)

    # Does this UID belong to another account we're keeping? (e.g. a UID 0
    # backdoor shares root's UID). If so, killing its processes would kill
    # the kept user's processes too, and userdel needs -f because it sees the
    # kept user's processes.
    shared_uid=0
    [ "$uid" = 0 ] && shared_uid=1
    for k in $KEEP; do
        [ "$(id -u "$k" 2>/dev/null)" = "$uid" ] && { shared_uid=1; break; }
    done

    if [ "$KILL_PROCS" -eq 1 ]; then
        if [ "$shared_uid" -eq 1 ]; then
            info "Not killing processes for $user (UID $uid is shared with a kept account)"
        else
            kill_uid "$uid"
            sleep 1
        fi
    fi

    remove_home=0
    if [ -n "$home" ] && [ -d "$home" ] && home_removable "$home" \
       && [ "$(stat -c %u "$home" 2>/dev/null)" = "$uid" ]; then
        remove_home=1
    fi

    # A home owned by a shared UID (e.g. root) isn't really this user's
    [ "$shared_uid" -eq 1 ] && remove_home=0

    delete_user "$user" "$remove_home" "$shared_uid"
    rc=$?
    # userdel exit 12 = account removed but home dir/mail spool couldn't be removed
    if [ "$rc" -eq 0 ] || [ "$rc" -eq 12 ]; then
        if [ "$remove_home" -eq 1 ]; then
            info "Deleted $user (home $home removed)"
        else
            info "Deleted $user (home kept: ${home:-none})"
        fi
        deleted=$((deleted + 1))
    else
        echo "[!] Failed to delete $user (exit $rc)" >&2
        failed=$((failed + 1))
    fi
done

info "Done. Deleted: $deleted  Failed: $failed"
[ "$failed" -eq 0 ]
