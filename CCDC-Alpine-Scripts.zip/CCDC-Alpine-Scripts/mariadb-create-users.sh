#!/bin/sh
# --- Alpine guard (POSIX sh until the second "fi") -----------------------------
# This is the Alpine Linux version. It needs bash: if this was started with
# BusyBox sh (ash), bash is installed with apk when missing and the script
# re-runs itself under it.
if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi
if [ -z "${BASH_VERSION:-}" ]; then
    if ! command -v bash >/dev/null 2>&1; then
        echo "[*] bash is not installed; installing it with apk..." >&2
        apk add --no-cache bash >/dev/null 2>&1 || {
            echo "[!] Could not install bash (no repository access?). Install it first: apk add bash" >&2
            exit 1
        }
    fi
    exec bash "$0" "$@"
fi
# --------------------------------------------------------------------------------
#
# mariadb-create-users.sh - Alpine Linux version
# Create MariaDB users from a list file. Installs with apk and manages the
# OpenRC "mariadb" service when -i is given.
#
# List file format (one user per line, comma separated):
#   username,host,password,database,privileges
#
#   - host        defaults to localhost
#   - password    left empty -> a random one is generated
#   - database    left empty -> no GRANT is issued; "*" means all databases
#   - privileges  defaults to "ALL PRIVILEGES"; separate several with ';'
#                 (e.g. SELECT;INSERT;UPDATE)
#   - blank lines and lines starting with '#' are ignored
#
# Example:
#   alice,localhost,S3cret!,appdb,ALL PRIVILEGES
#   bob,%,,reports,SELECT
#   carol,10.0.0.%,,,
#
set -euo pipefail

SCRIPT_NAME=$(basename "$0")
LIST_FILE=""
INSTALL=0
DRY_RUN=0
UPDATE_EXISTING=0
DEFAULTS_FILE=""
CRED_FILE="./mariadb-credentials-$(date +%Y%m%d-%H%M%S).txt"
PASSWORD_LENGTH=20

usage() {
    cat <<EOF
Usage: $SCRIPT_NAME -f LIST_FILE [options]

Options:
  -f FILE   List of users to create (required)
  -i        Install and start MariaDB server if it is missing
  -u        Update password/grants for users that already exist
  -c FILE   MariaDB client defaults file with admin credentials
            (default: connect as root over the unix socket)
  -o FILE   Where to write generated passwords (default: $CRED_FILE)
  -n        Dry run: print the SQL (passwords masked) without running it
  -h        Show this help
EOF
}

log()  { printf '[INFO]  %s\n' "$*"; }
warn() { printf '[WARN]  %s\n' "$*" >&2; }
die()  { printf '[ERROR] %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- distro ---

detect_distro() {
    [[ -f /etc/alpine-release ]] || [[ ${SKIP_ALPINE_CHECK:-0} == 1 ]] || die "Not Alpine Linux."
    DISTRO_FAMILY="alpine"
    PKG_INSTALL="apk add mariadb mariadb-client mariadb-openrc"
    PKG_UPDATE=""
    log "Detected Alpine Linux $(cat /etc/alpine-release 2>/dev/null)"
}

find_client() {
    if command -v mariadb >/dev/null 2>&1; then
        CLIENT="mariadb"
    elif command -v mysql >/dev/null 2>&1; then
        CLIENT="mysql"
    else
        CLIENT=""
    fi
}

# start_mariadb: Alpine needs the data directory initialised once before the first start
start_mariadb() {
    if [[ ! -d /var/lib/mysql/mysql ]]; then
        log "Initialising the MariaDB data directory (first start)..."
        /etc/init.d/mariadb setup >/dev/null 2>&1 \
            || mariadb-install-db --user=mysql --datadir=/var/lib/mysql >/dev/null \
            || die "Could not initialise /var/lib/mysql"
    fi
    rc-update add mariadb default >/dev/null 2>&1
    rc-service mariadb start
}

install_mariadb() {
    [[ $EUID -eq 0 ]] || die "Installing packages requires root (use su or doas)."
    log "Installing MariaDB server..."
    $PKG_INSTALL || apk add mariadb mariadb-client || die "apk add mariadb failed"
    start_mariadb
    find_client
}

ensure_running() {
    if [[ -x /etc/init.d/mariadb ]] && ! rc-service mariadb status 2>/dev/null | grep -q 'status: started'; then
        if [[ $INSTALL -eq 1 ]]; then
            log "Starting mariadb service..."
            start_mariadb
        else
            warn "mariadb service does not appear to be running (use -i to start it)."
        fi
    fi
}

# Alpine's stock /etc/my.cnf.d/mariadb-server.cnf enables skip-networking:
# accounts for hosts other than localhost can't connect until it's removed.
check_networking() {
    local f
    f=$(grep -lsE '^[[:space:]]*skip[-_]networking([[:space:]]*=[[:space:]]*(1|on|true))?[[:space:]]*$' /etc/my.cnf /etc/my.cnf.d/*.cnf 2>/dev/null | head -n1)
    [[ -n $f ]] || return 0
    if grep -vE '^[[:space:]]*(#|$)' "$LIST_FILE" | awk -F, '{h=$2; gsub(/[[:space:]]/, "", h); if (h != "" && h != "localhost" && h != "127.0.0.1" && h != "::1") f=1} END{exit !f}'; then
        warn "skip-networking is set in $f: MariaDB only accepts local socket connections,"
        warn "so the remote-host accounts in $LIST_FILE can't log in. Comment it out and run: rc-service mariadb restart"
    fi
}

# ------------------------------------------------------------------- SQL ---

# Escape a value for use inside single-quoted SQL strings.
sql_escape() {
    local s=$1
    s=${s//\\/\\\\}
    s=${s//\'/\\\'}
    printf '%s' "$s"
}

# (openssl isn't installed by default on Alpine. Reading a bounded amount of
#  /dev/urandom, and "|| true", keep pipefail + set -e from aborting on SIGPIPE.)
gen_password() {
    if command -v openssl >/dev/null 2>&1; then
        { openssl rand -base64 48 | tr -dc 'A-Za-z0-9' | head -c "$PASSWORD_LENGTH"; } || true
    else
        { head -c 512 /dev/urandom | LC_ALL=C tr -dc 'A-Za-z0-9' | head -c "$PASSWORD_LENGTH"; } || true
    fi
}

run_sql() {
    if [[ $DRY_RUN -eq 1 ]]; then
        # Mask anything between IDENTIFIED BY '...'
        sed -E "s/(IDENTIFIED BY ')([^']|\\\\')*'/\1********'/g"
        return 0
    fi
    # SQL goes through stdin so passwords never appear in the process list.
    if [[ -n $DEFAULTS_FILE ]]; then
        "$CLIENT" --defaults-extra-file="$DEFAULTS_FILE" --batch "$@"
    else
        "$CLIENT" -u root --batch "$@"
    fi
}

user_exists() {
    [[ $DRY_RUN -eq 1 ]] && return 1
    local count
    count=$(printf "SELECT COUNT(*) FROM mysql.user WHERE User='%s' AND Host='%s';\n" \
                "$(sql_escape "$1")" "$(sql_escape "$2")" | run_sql --skip-column-names 2>/dev/null | tail -n1)
    [[ ${count:-0} -gt 0 ]]
}

# ------------------------------------------------------------ validation ---

valid_user()  { [[ $1 =~ ^[A-Za-z0-9_.-]{1,80}$ ]]; }
valid_host()  { [[ $1 =~ ^[A-Za-z0-9_.%:-]{1,255}$ ]]; }
valid_db()    { [[ $1 == "*" || $1 =~ ^[A-Za-z0-9_\$]{1,64}$ ]]; }
PRIVS_RE='^[A-Za-z ]+(;[A-Za-z ]+)*$'
valid_privs() { [[ $1 =~ $PRIVS_RE ]]; }

trim() { local s=$1; s=${s#"${s%%[![:space:]]*}"}; s=${s%"${s##*[![:space:]]}"}; printf '%s' "$s"; }

# ------------------------------------------------------------------ main ---

process_list() {
    local line_no=0 created=0 updated=0 skipped=0 failed=0
    local user host pass db privs generated sql target action

    if [[ $DRY_RUN -eq 0 ]]; then
        ( umask 077; : > "$CRED_FILE" )
    fi

    while IFS= read -r line || [[ -n $line ]]; do
        line_no=$((line_no + 1))
        line=$(trim "${line%$'\r'}")
        [[ -z $line || $line == \#* ]] && continue

        IFS=',' read -r user host pass db privs <<<"$line"
        user=$(trim "${user:-}")
        host=$(trim "${host:-}");   host=${host:-localhost}
        pass=$(trim "${pass:-}")
        db=$(trim "${db:-}")
        privs=$(trim "${privs:-}"); privs=${privs:-ALL PRIVILEGES}

        if ! valid_user "$user"; then warn "Line $line_no: invalid username '$user', skipped."; failed=$((failed+1)); continue; fi
        if ! valid_host "$host"; then warn "Line $line_no: invalid host '$host', skipped.";     failed=$((failed+1)); continue; fi
        if [[ -n $db ]] && ! valid_db "$db"; then warn "Line $line_no: invalid database '$db', skipped."; failed=$((failed+1)); continue; fi
        if ! valid_privs "$privs"; then warn "Line $line_no: invalid privileges '$privs', skipped."; failed=$((failed+1)); continue; fi

        generated=0
        if [[ -z $pass ]]; then
            pass=$(gen_password)
            generated=1
        fi

        target="'$(sql_escape "$user")'@'$(sql_escape "$host")'"

        if user_exists "$user" "$host"; then
            if [[ $UPDATE_EXISTING -eq 0 ]]; then
                log "User $user@$host already exists, skipped (use -u to update)."
                skipped=$((skipped+1))
                continue
            fi
            sql="ALTER USER $target IDENTIFIED BY '$(sql_escape "$pass")';"
            action="updated"
        else
            sql="CREATE USER $target IDENTIFIED BY '$(sql_escape "$pass")';"
            action="created"
        fi

        if [[ -n $db ]]; then
            local scope
            if [[ $db == "*" ]]; then scope="*.*"; else scope="\`$db\`.*"; fi
            sql+=$'\n'"GRANT ${privs//;/, } ON $scope TO $target;"
        fi

        if printf '%s\n' "$sql" | run_sql; then
            log "User $user@$host $action${db:+ (grants on $db)}."
            [[ $action == created ]] && created=$((created+1)) || updated=$((updated+1))
            if [[ $generated -eq 1 && $DRY_RUN -eq 0 ]]; then
                printf '%s@%s\t%s\n' "$user" "$host" "$pass" >> "$CRED_FILE"
            fi
        else
            warn "Failed to create/update $user@$host."
            failed=$((failed+1))
        fi
    done < "$LIST_FILE"

    echo
    log "Done: $created created, $updated updated, $skipped skipped, $failed failed."
    if [[ $DRY_RUN -eq 0 && -s $CRED_FILE ]]; then
        log "Generated passwords saved to $CRED_FILE (mode 600)."
    elif [[ $DRY_RUN -eq 0 ]]; then
        rm -f "$CRED_FILE"
    fi
}

while getopts ":f:iuc:o:nh" opt; do
    case $opt in
        f) LIST_FILE=$OPTARG ;;
        i) INSTALL=1 ;;
        u) UPDATE_EXISTING=1 ;;
        c) DEFAULTS_FILE=$OPTARG ;;
        o) CRED_FILE=$OPTARG ;;
        n) DRY_RUN=1 ;;
        h) usage; exit 0 ;;
        :) die "Option -$OPTARG requires an argument." ;;
        *) usage; exit 1 ;;
    esac
done

[[ -n $LIST_FILE ]] || { usage; exit 1; }
[[ -r $LIST_FILE ]] || die "Cannot read list file: $LIST_FILE"
[[ -z $DEFAULTS_FILE || -r $DEFAULTS_FILE ]] || die "Cannot read defaults file: $DEFAULTS_FILE"

if [[ $DRY_RUN -eq 0 ]]; then
    detect_distro
    find_client
    if [[ -z $CLIENT ]]; then
        [[ $INSTALL -eq 1 ]] || die "MariaDB client not found. Re-run with -i to install MariaDB."
        install_mariadb
    fi
    ensure_running
    printf 'SELECT 1;\n' | run_sql >/dev/null || die "Cannot connect to MariaDB as admin (run as root, or -c with a defaults file)."
    check_networking
fi

process_list
