#!/bin/sh
# --- Alpine guard (POSIX sh until the second "fi") -----------------------------
# This is the Alpine Linux version. It needs bash: if this was started with
# BusyBox sh (ash), bash is installed with apk when missing and the script
# re-runs itself under it.
if [ ! -f /etc/alpine-release ] && [ "${SKIP_ALPINE_CHECK:-0}" != 1 ]; then
    echo "This is the Alpine Linux version of the script; use the original on other distros." >&2
    exit 1
fi
if [ -z "${BASH_VERSION:-}" ]; then
    if ! command -v bash >/dev/null 2>&1; then
        echo "[*] bash is not installed; installing it with apk..." >&2
        apk add --no-cache bash >/dev/null 2>&1 || {
            echo "[!] Could not install bash (no repository access?). Install it first: apk add bash" >&2
            exit 1
        }
    fi
    exec bash "$0" "$@"
fi
# --------------------------------------------------------------------------------
# ======================================================================
# VSFTPD HARDENING SCRIPT — Alpine Linux version (CCDC)
# ======================================================================
# Description:
#   Hardens a vsftpd installation for competition use:
#     - Disables anonymous access
#     - Creates an allowed-user whitelist (userlist_deny=NO)
#     - Auto-detects chroot mode:
#         • Shared root: if existing config has local_root or you pass one
#         • Per-user: each user chrooted into their own home directory
#     - Sets secure file/directory permissions
#     - Configures passive port range (with firewall warning)
#     - Enables TLS if a certificate is available
#     - Strips version info from the banner
#     - Turns OFF vsftpd's seccomp sandbox: on Alpine (musl) it kills the
#       session child on directory listings ("500 OOPS: child died")
#     - Idempotent: safe to re-run
#
# Usage:
#   sh ./vsftpd-harden-agnostic.sh <userlist.txt> [ftp_root]   (as root)
#
#   userlist.txt  — one username per line (must be existing local users)
#   ftp_root      — optional shared FTP root directory
#                   If omitted, the script auto-detects:
#                     1. Reads local_root from existing vsftpd.conf → shared mode
#                     2. If no local_root found → per-user home directory mode
#
# Notes:
#   - Must be run as root.
#   - Backs up vsftpd.conf before making changes.
#   - Alpine: config is /etc/vsftpd/vsftpd.conf, service is OpenRC "vsftpd".
#   - Alpine's vsftpd checks /etc/shells when it isn't using PAM: FTP users
#     need a shell listed there (a nologin shell is rejected unless added).
# ======================================================================

set -euo pipefail

# ---------------------------
# Color helpers
# ---------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[+]${NC} $*"; }
warn()  { echo -e "${YELLOW}[!]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ---------------------------
# Pre-flight checks
# ---------------------------
if [[ $EUID -ne 0 ]]; then
    error "This script must be run as root (use su or doas)."
fi

if [[ -z "${1:-}" ]]; then
    echo "Usage: $0 <userlist.txt> [ftp_root]"
    echo "  userlist.txt — file with one allowed FTP username per line"
    echo "  ftp_root     — shared FTP root (optional; auto-detects if omitted)"
    exit 1
fi

USERLIST_INPUT="$1"
FTP_ROOT_ARG="${2:-}"    # empty if not provided — triggers auto-detection later

if [[ ! -f "$USERLIST_INPUT" ]]; then
    error "Userlist file not found: $USERLIST_INPUT"
fi

# ---------------------------
# Detect distro & package mgr
# ---------------------------
install_vsftpd() {
    if command -v vsftpd &>/dev/null; then
        info "vsftpd is already installed."
        return
    fi
    warn "vsftpd not found — installing with apk..."
    apk add --quiet --no-cache vsftpd vsftpd-openrc 2>/dev/null || apk add --quiet --no-cache vsftpd \
        || error "apk add vsftpd failed. Install vsftpd manually and re-run."
    info "vsftpd installed."
}

# ---------------------------
# Restart (OpenRC)
# ---------------------------
restart_vsftpd() {
    rc-update add vsftpd default >/dev/null 2>&1 || true
    if rc-service vsftpd restart; then
        info "vsftpd restarted & enabled (OpenRC)."
    else
        warn "vsftpd failed to start. Check: tail -n 30 /var/log/messages ; vsftpd $VSFTPD_CONF"
    fi
}

# ---------------------------
# Locate vsftpd.conf
# ---------------------------
find_vsftpd_conf() {
    for path in /etc/vsftpd.conf /etc/vsftpd/vsftpd.conf; do
        if [[ -f "$path" ]]; then
            VSFTPD_CONF="$path"
            info "Found config: $VSFTPD_CONF"
            return
        fi
    done
    error "Cannot find vsftpd.conf. Is vsftpd installed?"
}

# ---------------------------
# Idempotent config setter
# ---------------------------
# Sets key=value in vsftpd.conf idempotently.
# Removes ALL existing lines (commented or not) for the key, then appends once.
# Uses POSIX BRE only ([[:space:]] not \s) for BusyBox/Alpine compat.
set_conf() {
    local key="$1" value="$2"
    # Delete any existing lines for this key (commented or uncommented)
    sed -i "/^#\{0,1\}[[:space:]]*${key}=/d" "$VSFTPD_CONF"
    # Append the canonical value
    echo "${key}=${value}" >> "$VSFTPD_CONF"
}

# Removes a key entirely from the config (for obsolete directives).
remove_conf() {
    local key="$1"
    sed -i "/^#\{0,1\}[[:space:]]*${key}=/d" "$VSFTPD_CONF"
}

# ======================================================================
# MAIN
# ======================================================================
install_vsftpd
find_vsftpd_conf

# --- Backup original config ---
BACKUP="${VSFTPD_CONF}.bak.$(date +%Y%m%d%H%M%S)"
cp "$VSFTPD_CONF" "$BACKUP"
info "Config backed up to: $BACKUP"

# --- Strip comments and blank lines for a clean baseline ---
# The backup preserves the original. Working config should be unambiguous.
sed -i '/^[[:space:]]*#/d; /^[[:space:]]*$/d' "$VSFTPD_CONF"
info "Stripped stale comments from config (original preserved in backup)."

# ---------------------------
# 1. Disable anonymous access
# ---------------------------
info "Disabling anonymous login..."
set_conf "anonymous_enable" "NO"

# Remove stale anonymous directives — if red team re-enables anonymous_enable,
# these pre-configured permissions would be waiting.
for key in anon_upload_enable anon_mkdir_write_enable anon_other_write_enable anon_umask; do
    remove_conf "$key"
done

# Cap max_clients to a sane value (default configs sometimes have 5000+)
set_conf "max_clients" "50"

# ---------------------------
# 2. Enable local users
# ---------------------------
info "Enabling local user login..."
set_conf "local_enable" "YES"
set_conf "write_enable" "YES"

# ---------------------------
# 3. Detect and configure chroot mode
# ---------------------------
# Priority:
#   1. Explicit ftp_root argument      → shared mode
#   2. Existing local_root in config   → shared mode (preserve what was there)
#   3. Neither found                   → per-user home directory mode

CHROOT_MODE=""
FTP_ROOT=""

if [[ -n "$FTP_ROOT_ARG" ]]; then
    # User explicitly passed a shared root
    CHROOT_MODE="shared"
    FTP_ROOT="$FTP_ROOT_ARG"
    info "Chroot mode: SHARED (from argument: $FTP_ROOT)"
else
    # Check the backup (pre-strip) for an existing local_root
    EXISTING_ROOT="$(grep -E "^[[:space:]]*local_root=" "$BACKUP" 2>/dev/null | tail -1 | cut -d= -f2 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')" || true
    if [[ -n "$EXISTING_ROOT" ]]; then
        CHROOT_MODE="shared"
        FTP_ROOT="$EXISTING_ROOT"
        info "Chroot mode: SHARED (detected from existing config: $FTP_ROOT)"
    else
        CHROOT_MODE="per-user"
        info "Chroot mode: PER-USER (no local_root found — each user gets their home dir)"
    fi
fi

info "Configuring chroot ($CHROOT_MODE)..."
set_conf "chroot_local_user" "NO"
remove_conf "allow_writeable_chroot"

if [[ "$CHROOT_MODE" == "shared" ]]; then
    set_conf "local_root" "$FTP_ROOT"
else
    # Per-user mode: remove local_root so vsftpd uses each user's home dir
    remove_conf "local_root"
fi

# ---------------------------
# 4. Listen configuration
# ---------------------------
# Explicitly set one listener to avoid "could not bind" conflicts
# when both listen and listen_ipv6 default to YES.
info "Configuring listen directives..."
set_conf "listen" "YES"
set_conf "listen_ipv6" "NO"

# ---------------------------
# 5. Create & populate userlist
# ---------------------------
USERLIST_FILE="/etc/vsftpd.userlist"
info "Building allowed userlist: $USERLIST_FILE"

: > "$USERLIST_FILE"          # truncate (idempotent)
chmod 600 "$USERLIST_FILE"

ADDED=0
SKIPPED=0
# read without IFS= so leading/trailing whitespace is trimmed by default
# || [[ -n "$user" ]] ensures the last line is processed even without a trailing newline
while read -r user || [[ -n "$user" ]]; do
    [[ -z "$user" || "$user" == \#* ]] && continue   # skip blanks/comments
    if id "$user" &>/dev/null; then
        echo "$user" >> "$USERLIST_FILE"
        ADDED=$((ADDED + 1))
    else
        warn "User '$user' does not exist on this system — skipped."
        SKIPPED=$((SKIPPED + 1))
    fi
done < "$USERLIST_INPUT"

info "Added $ADDED user(s) to whitelist ($SKIPPED skipped)."

if [[ "$ADDED" -eq 0 ]]; then
    warn "WARNING: No valid users in whitelist — ALL FTP logins will be denied!"
    warn "Verify your userlist.txt contains valid local usernames."
fi

set_conf "userlist_enable" "YES"
set_conf "userlist_file"   "$USERLIST_FILE"
set_conf "userlist_deny"   "NO"

# ---------------------------
# 6. PAM service name
# ---------------------------
# Harmless when vsftpd isn't built with PAM; needed when it is.
info "Setting PAM service name..."
set_conf "pam_service_name" "vsftpd"

# Without PAM, vsftpd only accepts users whose shell is in /etc/shells
while read -r user || [[ -n "$user" ]]; do
    [[ -z "$user" ]] && continue
    ushell="$(getent passwd "$user" | cut -d: -f7)"
    if [[ -n "$ushell" ]] && ! grep -qxF "$ushell" /etc/shells 2>/dev/null; then
        warn "  $user has shell '$ushell', which isn't in /etc/shells; vsftpd may refuse the login."
        warn "    Fix: echo '$ushell' >> /etc/shells   (or give the user /bin/ash)"
    fi
done < "$USERLIST_FILE"

# ---------------------------
# 7. FTP root permissions
# ---------------------------
# Create ftp_users group if it doesn't exist
if ! getent group ftp_users &>/dev/null; then
    addgroup ftp_users
    info "Created group: ftp_users"
fi

# Add whitelisted users to ftp_users group (BusyBox: addgroup USER GROUP)
while read -r user || [[ -n "$user" ]]; do
    [[ -z "$user" ]] && continue
    id -nG "$user" 2>/dev/null | tr ' ' '\n' | grep -qx ftp_users || addgroup "$user" ftp_users 2>/dev/null || true
done < "$USERLIST_FILE"

# Helper: lock down a single chroot directory
# Usage: harden_chroot_dir <dir>
#   - dir itself: root-owned, 755 (vsftpd chroot requirement)
#   - dir/uploads: writable by ftp_users, setgid
#   - existing files: group-readable
harden_chroot_dir() {
    local dir="$1"
    if [[ ! -d "$dir" ]]; then
        mkdir -p "$dir"
        info "  Created: $dir"
    fi

    # Chroot root must be owned by root and not writable
    chown root:ftp_users "$dir"
    chmod 2775 "$dir"

    # Writable subdirectory for uploads
    local upload_dir="$dir/uploads"
    if [[ ! -d "$upload_dir" ]]; then
        mkdir -p "$upload_dir"
        info "  Created writable subdirectory: $upload_dir"
    fi
    chown root:ftp_users "$upload_dir"
    chmod 2775 "$upload_dir"

    # Fix ownership/permissions on all contents
    find "$dir" -mindepth 1 -type d -exec chown root:ftp_users {} \; -exec chmod 2775 {} \;
    find "$dir" -mindepth 1 -type f -exec chown root:ftp_users {} \; -exec chmod 0664 {} \;

    # Re-enforce chroot root (find -mindepth 1 won't touch it, but be safe)
    chmod 2775 "$dir"
}

if [[ "$CHROOT_MODE" == "shared" ]]; then
    info "Setting shared FTP root permissions on: $FTP_ROOT"
    harden_chroot_dir "$FTP_ROOT"
    info "Permissions applied (chroot root=755, uploads=2775, group=ftp_users)."
else
    info "Setting per-user home directory permissions..."
    while read -r user || [[ -n "$user" ]]; do
        home_dir="$(getent passwd "$user" 2>/dev/null | cut -d: -f6)" || true
        if [[ -z "$home_dir" || ! -d "$home_dir" ]]; then
            warn "  $user: home directory not found — skipping permissions"
            continue
        fi
        info "  Hardening: $user → $home_dir"
        harden_chroot_dir "$home_dir"
    done < "$USERLIST_FILE"
    info "Per-user permissions applied (each home=755, uploads/=2775, group=ftp_users)."
    warn "NOTE: Home directories are now root-owned and read-only (vsftpd chroot requirement)."
    warn "Users who also SSH in cannot write to ~ (only to ~/uploads/)."
    warn "If this is a problem, consider using a separate FTP-only directory structure."
fi

# ---------------------------
# 8. Passive mode (firewall-friendly)
# ---------------------------
info "Configuring passive mode..."
set_conf "pasv_enable"    "YES"
set_conf "pasv_min_port"  "40000"
set_conf "pasv_max_port"  "40100"
echo
warn "REMINDER: Open passive ports 40000-40100 in your firewall."
warn "  iptables:  iptables -A INPUT -p tcp --dport 40000:40100 -j ACCEPT && rc-service iptables save"
warn "  nftables:  nft add rule inet filter input tcp dport 40000-40100 accept   (persist in /etc/nftables.d/)"
warn "  awall:     add the port range to a policy in /etc/awall/optional/, then awall enable <policy> && awall activate"
echo

# ---------------------------
# 9. Sanitize banner (no version leak)
# ---------------------------
info "Setting neutral FTP banner..."
set_conf "ftpd_banner" "Welcome to FTP service."

# ---------------------------
# 10. Logging
# ---------------------------
info "Enabling transfer & command logging..."
set_conf "xferlog_enable" "YES"
set_conf "xferlog_std_format" "YES"
set_conf "dual_log_enable" "YES"
set_conf "log_ftp_protocol" "YES"

# ---------------------------
# 11. TLS (optional — enable if cert exists)
# ---------------------------
TLS_CERT="/etc/ssl/certs/vsftpd.pem"
TLS_KEY="/etc/ssl/private/vsftpd.key"

if [[ -f "$TLS_CERT" && -f "$TLS_KEY" ]]; then
    info "TLS certificate found — enabling FTPS..."
    set_conf "ssl_enable"       "YES"
    set_conf "rsa_cert_file"    "$TLS_CERT"
    set_conf "rsa_private_key_file" "$TLS_KEY"
    set_conf "force_local_data_ssl"  "YES"
    set_conf "force_local_logins_ssl" "YES"
    set_conf "ssl_tlsv1"        "NO"
    set_conf "ssl_sslv2"        "NO"
    set_conf "ssl_sslv3"        "NO"
    set_conf "ssl_tlsv1_1"      "NO"
    set_conf "ssl_tlsv1_2"      "YES"
else
    remove_conf "ssl_enable"
    warn "No TLS cert found at $TLS_CERT — skipping TLS."
    warn "To enable TLS, generate a cert and re-run:"
    warn "  apk add openssl && mkdir -p /etc/ssl/private && openssl req -x509 -nodes -days 365 -newkey rsa:2048 \\"
    warn "    -keyout $TLS_KEY -out $TLS_CERT"
fi

# ---------------------------
# 12. Additional hardening
# ---------------------------
info "Applying additional hardening..."
# Remove obsolete tcp_wrappers (removed in vsftpd 3.0+, can cause startup failure)
#remove_conf "tcp_wrappers"

set_conf "ls_recurse_enable"    "NO"
set_conf "local_umask"          "007"
set_conf "file_open_mode"       "0640"
set_conf "hide_ids"             "YES"       # show "ftp" instead of real uid/gid
set_conf "max_per_ip"           "3"         # limit concurrent connections per IP
set_conf "idle_session_timeout" "300"
set_conf "data_connection_timeout" "120"
# vsftpd's seccomp filter doesn't allow some syscalls musl makes, so on Alpine
# the session child dies on LIST/RETR ("500 OOPS: child died"). Keep it off.
set_conf "seccomp_sandbox"      "NO"

# ---------------------------
# 13. Enable writeable chroot
# ---------------------------
info "Enabling writeable chroot..."
set_conf "allow_writeable_chroot"    "YES"


# ---------------------------
# Done — restart service
# ---------------------------
echo
info "Configuration complete. Restarting vsftpd..."
restart_vsftpd

echo
info "========================================="
info " vsftpd hardening applied successfully."
info " Config  : $VSFTPD_CONF"
info " Backup  : $BACKUP"
info " Users   : $USERLIST_FILE ($ADDED users)"
if [[ "$CHROOT_MODE" == "shared" ]]; then
    info " Mode    : Shared root → $FTP_ROOT"
    info " Uploads : $FTP_ROOT/uploads (writable)"
else
    info " Mode    : Per-user home directories"
    info " Uploads : ~<user>/uploads (writable)"
fi
info "========================================="
