// ==UserScript==
// @name         bulk_scorecheck_password_update
// @namespace    ccdc-blue-team
// @version      3.1
// @description  Enumerate your team's services from the scoring engine, pick which ones to hit, and set the same checker credential across all accounts on each. Blue-team credential-rotation helper.
// @match        *://*/service/*
// @match        *://*/services*
// @match        *://*/overview*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  // Password elements across both UIs:
  //   Old (<= v2): <a class="editable-textfield password" data-pk data-url>pw</a>
  //   New (v3):    <input type="password" data-name="password" data-pk data-url value="pw">
  // Select ONLY password fields -- never the v3 username/host/port inputs, which
  // share the editable-field class but carry a different data-name.
  const PASSWORD_SELECTOR = 'a.editable-textfield.password, input[data-name="password"]';
  const UPDATE_URL_FALLBACK = '/api/service/update_account';

  // v3 requires an X-CSRFToken header on state-changing requests; older builds
  // have no token. Read it from a document's meta tag (empty string if absent).
  function getCsrfToken(doc) {
    const m = (doc || document).querySelector('meta[name="csrf-token"]');
    return m ? (m.getAttribute('content') || '') : '';
  }

  // ---- Exclusions ----------------------------------------------------------
  // Skip any SERVICE whose name carries a black-team marker. Matched
  // case-insensitively against the service name only. Add patterns as needed.
  const EXCLUDE_PATTERNS = [
    /bta/i,                // "BTA", "bta", "svc-bta", etc.
    /black[\s_\-]?team/i,  // "black team", "blackteam", "black-team"
  ];

  function isExcludedService(serviceName) {
    return EXCLUDE_PATTERNS.some(function (re) { return re.test(serviceName || ''); });
  }

  // ---- Discover the team id ------------------------------------------------
  // The service page's own navbar script calls /api/team/<id>/services/status.
  // Scrape it from any inline script so we don't hardcode a team number.
  // Works across pages: the service page uses /api/team/<id>/services/status,
  // the services page uses /api/team/<id>/services and /api/team/<id>/stats.
  function discoverTeamId() {
    const scripts = Array.from(document.querySelectorAll('script'));
    for (const s of scripts) {
      const m = (s.textContent || '').match(/\/api\/team\/(\d+)\//);
      if (m) return m[1];
    }
    return null;
  }

  async function fetchServices(teamId) {
    const res = await fetch('/api/team/' + teamId + '/services/status', {
      credentials: 'same-origin',
      cache: 'no-store',
    });
    if (!res.ok) throw new Error('services/status HTTP ' + res.status);
    const data = await res.json();
    // data is { "<service name>": { id, result, ... }, ... }
    return Object.keys(data).map(function (name) {
      return { name: name, id: String(data[name].id), up: data[name].result };
    }).sort(function (a, b) { return a.name.localeCompare(b.name); });
  }

  // ---- Per-service work ----------------------------------------------------
  // Returns { accounts: [...], csrf } -- the token is parsed from the fetched
  // page so each service's POSTs carry a valid token even on v3.
  async function fetchServiceAccounts(serviceId) {
    const res = await fetch('/service/' + serviceId, {
      credentials: 'same-origin',
      cache: 'no-store',
    });
    if (!res.ok) throw new Error('/service/' + serviceId + ' HTTP ' + res.status);
    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');

    const accounts = Array.from(doc.querySelectorAll(PASSWORD_SELECTOR)).map(function (el) {
      // Username: v3 has a sibling <input data-name="username"> in the row;
      // the old UI has it as plain text in the first cell.
      const tr = el.closest('tr');
      let username = '';
      if (tr) {
        const userInput = tr.querySelector('input[data-name="username"]');
        if (userInput) username = (userInput.value || '').trim();
        else {
          const firstCell = tr.querySelector('td');
          username = firstCell ? firstCell.textContent.trim() : '';
        }
      }
      return {
        pk: el.getAttribute('data-pk'),
        name: el.getAttribute('data-name') || 'password',
        url: el.getAttribute('data-url') || UPDATE_URL_FALLBACK,
        username: username,
      };
    });

    return { accounts: accounts, csrf: getCsrfToken(doc) };
  }

  async function updateOne(acct, newValue, csrf) {
    const body = new URLSearchParams();
    body.append('name', acct.name);
    body.append('value', newValue);
    body.append('pk', acct.pk);
    const headers = { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' };
    // Send the CSRF header when we have a token (v3); harmless to include.
    const token = csrf || getCsrfToken(document);
    if (token) headers['X-CSRFToken'] = token;
    const res = await fetch(acct.url, {
      method: 'POST',
      headers: headers,
      body: body.toString(),
      credentials: 'same-origin',
    });
    if (!res.ok) throw new Error('pk ' + acct.pk + ' HTTP ' + res.status);
  }

  async function applyToServices(services, newValue, statusEl, btn) {
    if (!newValue) { statusEl.textContent = 'Enter a password first.'; return; }
    if (services.length === 0) { statusEl.textContent = 'Select at least one service.'; return; }

    btn.disabled = true;
    let totalAccts = 0, okAccts = 0;
    const failures = [];
    const skipped = [];

    for (const svc of services) {
      statusEl.textContent = 'Reading ' + svc.name + '...';

      // Skip the whole service if its name trips an exclusion pattern.
      if (isExcludedService(svc.name)) {
        skipped.push(svc.name);
        continue;
      }

      let accts, csrf;
      try {
        const result = await fetchServiceAccounts(svc.id);
        accts = result.accounts;
        csrf = result.csrf;
      } catch (e) {
        failures.push(svc.name + ' (enumerate: ' + e.message + ')');
        continue;
      }

      for (const acct of accts) {
        totalAccts++;
        try {
          await updateOne(acct, newValue, csrf);
          okAccts++;
          statusEl.textContent = 'Updated ' + okAccts + '/' + totalAccts + ' accounts (' + svc.name + ')...';
        } catch (e) {
          failures.push(svc.name + '/' + (acct.username || 'pk' + acct.pk) + ' ' + e.message);
        }
      }
    }

    btn.disabled = false;
    let msg = 'Done: ' + okAccts + '/' + totalAccts + ' accounts across ' + services.length + ' service(s).';
    if (skipped.length) msg += ' Skipped (excluded): ' + skipped.join(', ') + '.';
    if (failures.length) msg += ' Failures: ' + failures.join('; ');
    statusEl.textContent = msg;

    // If we changed the service currently being viewed, reflect it inline.
    const here = (location.pathname.match(/\/service\/(\d+)/) || [])[1];
    const hereSvc = services.filter(function (s) { return s.id === here; })[0];
    if (here && hereSvc && !isExcludedService(hereSvc.name)) {
      document.querySelectorAll(PASSWORD_SELECTOR).forEach(function (el) {
        // Old UI: anchor (set text). New UI: input (set value).
        if (el.tagName === 'INPUT') el.value = newValue;
        else el.textContent = newValue;
      });
    }
  }

  // ---- UI ------------------------------------------------------------------
  async function injectUI() {
    // Hardened single-instance guard: a DOM check alone can race if the script
    // is injected more than once (multiple matching frames / re-runs), which
    // would leave two panels and two sets of handlers fighting. A shared flag
    // plus the DOM check makes sure only one panel + one set of handlers exist.
    if (window.__bulkPwPanelLoaded || document.getElementById('bulk-pw-panel')) return;
    window.__bulkPwPanelLoaded = true;

    // Pick a sensible content container across layouts. Prefer the service
    // detail column, then the v3 page wrapper / main content, then the old
    // page container -- but never the navbar's .container.
    const host = document.querySelector('.col-sm-9') ||
                 document.querySelector('#main-content .page-wrap') ||
                 document.querySelector('.page-wrap') ||
                 document.querySelector('#main-content') ||
                 document.querySelector('main .container') ||
                 document.querySelector('.md-page') ||
                 document.body;

    // Self-contained colours so the panel stays readable under every engine
    // theme (Midnight / Glass / Carbon / War Room / Daylight). We don't inherit
    // the page's font colour, and we don't use Bootstrap's themed .form-control
    // (which turns the input dark-on-dark) -- every element is styled explicitly.
    const panel = document.createElement('div');
    panel.id = 'bulk-pw-panel';
    panel.style.cssText =
      'margin:12px 0;padding:12px;border:1px solid #c7ccd1;border-radius:6px;' +
      'background:#ffffff;color:#1a1d21;' +
      'font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;' +
      'box-shadow:0 1px 4px rgba(0,0,0,0.35);';

    const INPUT_CSS = 'width:240px;padding:5px 8px;border:1px solid #adb5bd;border-radius:4px;' +
                      'background:#ffffff;color:#1a1d21;font-size:14px;';
    const APPLY_CSS = 'padding:5px 12px;border:none;border-radius:4px;background:#f0ad4e;' +
                      'color:#1a1d21;font-weight:600;cursor:pointer;';

    panel.innerHTML =
      '<div id="bulk-pw-header" style="cursor:pointer;user-select:none;display:flex;align-items:center;gap:6px;color:#1a1d21;">' +
      '  <span id="bulk-pw-caret" style="font-size:11px;width:10px;display:inline-block;">▼</span>' +
      '  <strong>Bulk credential rotation</strong>' +
      '</div>' +
      '<div id="bulk-pw-body">' +
      '  <div style="margin:8px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">' +
      '    <input id="bulk-pw-input" type="text" placeholder="new password" style="' + INPUT_CSS + '">' +
      '    <button id="bulk-pw-apply" style="' + APPLY_CSS + '">Apply to selected</button>' +
      '    <label style="font-weight:normal;margin:0;color:#1a1d21;display:inline-flex;align-items:center;gap:4px;"><input id="bulk-pw-all" type="checkbox"> select all</label>' +
      '    <span id="bulk-pw-count" style="color:#0d6efd;font-weight:bold;"></span>' +
      '    <span id="bulk-pw-status" style="color:#495057;"></span>' +
      '  </div>' +
      '  <div id="bulk-pw-list" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:2px 16px;border-top:1px solid #e0e0e0;padding-top:8px;color:#1a1d21;">Loading services...</div>' +
      '</div>';

    host.insertBefore(panel, host.firstChild);

    // Collapse / expand the whole box.
    const headerEl = panel.querySelector('#bulk-pw-header');
    const bodyEl = panel.querySelector('#bulk-pw-body');
    const caretEl = panel.querySelector('#bulk-pw-caret');
    let collapsed = false;
    headerEl.addEventListener('click', function () {
      collapsed = !collapsed;
      bodyEl.style.display = collapsed ? 'none' : '';
      caretEl.textContent = collapsed ? '▶' : '▼';
    });

    const listEl = panel.querySelector('#bulk-pw-list');
    const statusEl = panel.querySelector('#bulk-pw-status');
    const countEl = panel.querySelector('#bulk-pw-count');
    const inputEl = panel.querySelector('#bulk-pw-input');
    const applyEl = panel.querySelector('#bulk-pw-apply');
    const allEl = panel.querySelector('#bulk-pw-all');

    const teamId = discoverTeamId();
    if (!teamId) { listEl.textContent = 'Could not detect team id — open a /service/<id> page once so it can be read.'; return; }

    let services = [];
    try {
      services = await fetchServices(teamId);
    } catch (e) {
      listEl.textContent = 'Failed to load services: ' + e.message;
      return;
    }

    // The checkboxes themselves are the single source of truth. We never keep
    // a parallel "selected" structure that could drift out of sync with what
    // you actually see checked — every read walks the live boxes.
    const boxes = [];  // { idx, el } for non-excluded services only

    function selectableBoxes() { return boxes.map(function (b) { return b.el; }); }

    function syncMaster() {
      const els = selectableBoxes();
      const checked = els.filter(function (el) { return el.checked; }).length;
      // "Select all" is all-or-nothing: if ANY selectable service is
      // deselected, the master clears completely (no indeterminate dash).
      allEl.indeterminate = false;
      allEl.checked = els.length > 0 && checked === els.length;
      if (countEl) countEl.textContent = 'selected: ' + checked + ' / ' + els.length;
    }

    listEl.innerHTML = '';
    services.forEach(function (svc, i) {
      const id = 'bulk-pw-svc-' + i;
      const excluded = isExcludedService(svc.name);
      const dot = svc.up === 'True' ? '🟢' : (svc.up === 'False' ? '🔴' : '⚪');
      const tag = excluded ? ' <em style="color:#999;">(excluded)</em>' : '';

      const row = document.createElement('div');
      row.style.cssText = 'margin:0 0 4px;white-space:nowrap;' + (excluded ? 'opacity:0.5;' : '');
      row.innerHTML =
        '<input type="checkbox" id="' + id + '" data-idx="' + i + '"' + (excluded ? ' disabled' : '') + '> ' +
        '<label for="' + id + '" style="font-weight:normal;margin:0;cursor:pointer;color:#1a1d21;">' + dot + ' ' + svc.name + tag + '</label>';
      listEl.appendChild(row);

      if (!excluded) boxes.push({ idx: i, el: row.querySelector('input') });
    });

    // Delegated listener: any checkbox change in the list just refreshes the
    // master's display. It does NOT store selection anywhere.
    listEl.addEventListener('change', syncMaster);
    syncMaster(); // initialize counter / master state

    allEl.addEventListener('change', function () {
      const on = allEl.checked;
      selectableBoxes().forEach(function (el) { el.checked = on; });
      allEl.indeterminate = false;
      syncMaster(); // refresh counter (programmatic .checked changes don't fire 'change')
    });

    function selectedServices() {
      // Read straight off the live checkboxes at call time.
      return boxes
        .filter(function (b) { return b.el.checked; })
        .map(function (b) { return services[b.idx]; })
        .filter(Boolean);
    }

    applyEl.addEventListener('click', function () {
      const chosen = selectedServices();
      if (chosen.length === 0) { statusEl.textContent = 'Select at least one service.'; return; }
      applyToServices(chosen, inputEl.value, statusEl, applyEl);
    });
    inputEl.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); applyEl.click(); }
    });
  }

  injectUI();
})();