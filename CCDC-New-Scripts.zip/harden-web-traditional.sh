#!/bin/bash
# ============================================================
# harden-web-traditional.sh
# CCDC Web Hardening Script — Traditional Services
# OS Agnostic: RHEL/CentOS/Fedora and Debian/Ubuntu
# ============================================================
#
# FUNCTIONS:
#   detect_os           — Detects OS family (rhel or debian) and sets package manager
#   print_banner        — Prints script banner
#   print_result        — Prints [OK] or [SKIP] status for each action
#   harden_apache       — Hardens Apache if installed
#     - Disables ServerSignature
#     - Sets ServerTokens Prod
#     - Disables unnecessary modules (autoindex, status, cgi, userdir)
#     - Removes default welcome page
#     - Restricts .htaccess overrides
#     - Adds security headers
#     - Disables TRACE method
#     - Disables directory listing
#   harden_nginx        — Hardens Nginx if installed
#     - Sets server_tokens off
#     - Removes default site
#     - Adds rate limiting
#     - Restricts allowed HTTP methods
#     - Disables autoindex
#     - Adds security headers
#   harden_tomcat       — Hardens Tomcat if installed
#     - Removes default webapps (manager, host-manager, examples, docs, ROOT)
#     - Changes SHUTDOWN string to random value
#     - Disables AJP connector
#     - Removes server version from error pages
#     - Restricts manager to localhost
#   harden_caddy        — Hardens Caddy if installed
#     - Adds security headers
#     - Disables file browsing
#   set_file_permissions — Sets restrictive permissions on webroot and config files
#   restart_services     — Restarts only services that were modified
#   print_summary        — Prints a summary of all changes made
#
# ============================================================

set -euo pipefail

# ---------- Tracking ----------
CHANGES=()

# ---------- Output helpers ----------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

print_banner() {
    echo -e "${CYAN}"
    echo "============================================"
    echo "  CCDC Web Hardening — Traditional Services"
    echo "============================================"
    echo -e "${NC}"
}

print_result() {
    local status="$1"
    local msg="$2"
    if [[ "$status" == "ok" ]]; then
        echo -e "  ${GREEN}[OK]${NC}    $msg"
    elif [[ "$status" == "skip" ]]; then
        echo -e "  ${YELLOW}[SKIP]${NC}  $msg"
    elif [[ "$status" == "fail" ]]; then
        echo -e "  ${RED}[FAIL]${NC}  $msg"
    fi
}

# ---------- OS Detection ----------
detect_os() {
    echo -e "${CYAN}[*] Detecting OS...${NC}"
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        case "$ID" in
            rhel|centos|fedora|rocky|alma)
                OS_FAMILY="rhel"
                PKG_MGR="dnf"
                if ! command -v dnf &>/dev/null; then
                    PKG_MGR="yum"
                fi
                APACHE_SERVICE="httpd"
                APACHE_CONF="/etc/httpd/conf/httpd.conf"
                APACHE_CONF_DIR="/etc/httpd/conf.d"
                APACHE_MODULES_DIR="/etc/httpd/conf.modules.d"
                NGINX_CONF="/etc/nginx/nginx.conf"
                NGINX_CONF_DIR="/etc/nginx/conf.d"
                NGINX_DEFAULT="/etc/nginx/conf.d/default.conf"
                ;;
            debian|ubuntu|kali)
                OS_FAMILY="debian"
                PKG_MGR="apt"
                APACHE_SERVICE="apache2"
                APACHE_CONF="/etc/apache2/apache2.conf"
                APACHE_CONF_DIR="/etc/apache2/conf-enabled"
                APACHE_MODULES_DIR="/etc/apache2/mods-enabled"
                NGINX_CONF="/etc/nginx/nginx.conf"
                NGINX_CONF_DIR="/etc/nginx/conf.d"
                NGINX_DEFAULT="/etc/nginx/sites-enabled/default"
                ;;
            *)
                echo -e "${RED}[!] Unsupported OS: $ID${NC}"
                exit 1
                ;;
        esac
        echo -e "  OS: ${GREEN}$PRETTY_NAME${NC}"
        echo -e "  Family: ${GREEN}$OS_FAMILY${NC}"
        echo -e "  Package manager: ${GREEN}$PKG_MGR${NC}"
    else
        echo -e "${RED}[!] Cannot detect OS — /etc/os-release not found${NC}"
        exit 1
    fi
}

# ---------- File Permissions ----------
set_file_permissions() {
    echo -e "\n${CYAN}[*] Setting restrictive file permissions...${NC}"

    # Apache
    if [[ -d /etc/httpd ]]; then
        chmod 750 /etc/httpd
        chmod 640 "$APACHE_CONF" 2>/dev/null || true
        print_result "ok" "Set /etc/httpd permissions to 750, config to 640"
        CHANGES+=("Set Apache config permissions")
    elif [[ -d /etc/apache2 ]]; then
        chmod 750 /etc/apache2
        chmod 640 "$APACHE_CONF" 2>/dev/null || true
        print_result "ok" "Set /etc/apache2 permissions to 750, config to 640"
        CHANGES+=("Set Apache config permissions")
    fi

    # Nginx
    if [[ -f "$NGINX_CONF" ]]; then
        chmod 640 "$NGINX_CONF"
        print_result "ok" "Set nginx.conf permissions to 640"
        CHANGES+=("Set Nginx config permissions")
    fi

    # Web roots
    for webroot in /var/www/html /usr/share/nginx/html /var/www; do
        if [[ -d "$webroot" ]]; then
            chmod -R 755 "$webroot"
            print_result "ok" "Set $webroot permissions to 755"
            CHANGES+=("Set $webroot permissions")
        fi
    done
}

# ---------- Apache Hardening ----------
harden_apache() {
    echo -e "\n${CYAN}[*] Checking for Apache...${NC}"

    if ! command -v httpd &>/dev/null && ! command -v apache2 &>/dev/null; then
        print_result "skip" "Apache not installed"
        return
    fi

    echo -e "  ${GREEN}Apache found — hardening...${NC}"

    # Disable ServerSignature and set ServerTokens
    if [[ -f "$APACHE_CONF" ]]; then
        # ServerSignature Off
        if grep -qi "^ServerSignature" "$APACHE_CONF"; then
            sed -i 's/^ServerSignature.*/ServerSignature Off/' "$APACHE_CONF"
        else
            echo "ServerSignature Off" >> "$APACHE_CONF"
        fi
        print_result "ok" "ServerSignature Off"
        CHANGES+=("Apache: ServerSignature Off")

        # ServerTokens Prod
        if grep -qi "^ServerTokens" "$APACHE_CONF"; then
            sed -i 's/^ServerTokens.*/ServerTokens Prod/' "$APACHE_CONF"
        else
            echo "ServerTokens Prod" >> "$APACHE_CONF"
        fi
        print_result "ok" "ServerTokens Prod"
        CHANGES+=("Apache: ServerTokens Prod")

        # Disable TRACE method
        if ! grep -qi "TraceEnable" "$APACHE_CONF"; then
            echo "TraceEnable Off" >> "$APACHE_CONF"
        else
            sed -i 's/^TraceEnable.*/TraceEnable Off/' "$APACHE_CONF"
        fi
        print_result "ok" "TRACE method disabled"
        CHANGES+=("Apache: TRACE disabled")

        # Disable directory listing
        if grep -q "Options Indexes" "$APACHE_CONF"; then
            sed -i '/Options Indexes/s/.*/Options -Indexes/' "$APACHE_CONF"
        fi
        print_result "ok" "Directory listing disabled"
        CHANGES+=("Apache: Directory listing disabled")

        # Restrict .htaccess
        if grep -q "AllowOverride All" "$APACHE_CONF"; then
            sed -i 's/AllowOverride All/AllowOverride None/' "$APACHE_CONF"
        fi
        print_result "ok" ".htaccess overrides restricted"
        CHANGES+=("Apache: .htaccess restricted")
    fi

    # Security headers config
    HEADERS_CONF="$APACHE_CONF_DIR/security-headers.conf"
    cat > "$HEADERS_CONF" << 'HEADEREOF'
<IfModule mod_headers.c>
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Content-Security-Policy "default-src 'self';"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always unset X-Powered-By
</IfModule>
HEADEREOF
    print_result "ok" "Security headers added to $HEADERS_CONF"
    CHANGES+=("Apache: Security headers added")

    # Enable headers module
    if [[ "$OS_FAMILY" == "debian" ]]; then
        a2enmod headers &>/dev/null || true
        print_result "ok" "Enabled mod_headers (Debian)"
    fi

    # Disable unnecessary modules
    if [[ "$OS_FAMILY" == "debian" ]]; then
        for mod in autoindex status cgi userdir; do
            if a2dismod "$mod" &>/dev/null; then
                print_result "ok" "Disabled module: $mod"
                CHANGES+=("Apache: Disabled module $mod")
            else
                print_result "skip" "Module $mod already disabled or not available"
            fi
        done
    elif [[ "$OS_FAMILY" == "rhel" ]]; then
        # Comment out LoadModule lines for unwanted modules
        for mod in autoindex_module status_module cgi_module userdir_module; do
            for conf_file in "$APACHE_MODULES_DIR"/*.conf; do
                if [[ -f "$conf_file" ]] && grep -q "^LoadModule $mod" "$conf_file"; then
                    sed -i "s/^LoadModule $mod/#LoadModule $mod/" "$conf_file"
                    print_result "ok" "Disabled module: $mod"
                    CHANGES+=("Apache: Disabled module $mod")
                fi
            done
        done
    fi

    # Remove default welcome page and autoindex config
    if [[ "$OS_FAMILY" == "rhel" ]]; then
        if [[ -f /etc/httpd/conf.d/welcome.conf ]]; then
            rm -f /etc/httpd/conf.d/welcome.conf
            print_result "ok" "Removed default welcome page"
            CHANGES+=("Apache: Removed welcome page")
        fi
        if [[ -f /etc/httpd/conf.d/autoindex.conf ]]; then
            rm -f /etc/httpd/conf.d/autoindex.conf
            print_result "ok" "Removed autoindex.conf"
            CHANGES+=("Apache: Removed autoindex.conf")
        fi
    elif [[ "$OS_FAMILY" == "debian" ]]; then
        if [[ -f /var/www/html/index.html ]]; then
            if grep -qi "apache" /var/www/html/index.html 2>/dev/null; then
                rm -f /var/www/html/index.html
                print_result "ok" "Removed default index page"
                CHANGES+=("Apache: Removed default index")
            fi
        fi
    fi

    RESTART_APACHE=true
}

# ---------- Nginx Hardening ----------
harden_nginx() {
    echo -e "\n${CYAN}[*] Checking for Nginx...${NC}"

    if ! command -v nginx &>/dev/null; then
        print_result "skip" "Nginx not installed"
        return
    fi

    echo -e "  ${GREEN}Nginx found — hardening...${NC}"

    if [[ -f "$NGINX_CONF" ]]; then
        # server_tokens off
        if grep -q "server_tokens" "$NGINX_CONF"; then
            sed -i 's/.*server_tokens.*/    server_tokens off;/' "$NGINX_CONF"
        else
            sed -i '/http {/a\    server_tokens off;' "$NGINX_CONF"
        fi
        print_result "ok" "server_tokens off"
        CHANGES+=("Nginx: server_tokens off")

        # Disable autoindex globally
        if grep -q "autoindex on" "$NGINX_CONF"; then
            sed -i 's/autoindex on/autoindex off/g' "$NGINX_CONF"
        fi
        print_result "ok" "autoindex disabled"
        CHANGES+=("Nginx: autoindex off")
    fi

    # Remove default site
    if [[ -f "$NGINX_DEFAULT" ]]; then
        rm -f "$NGINX_DEFAULT"
        print_result "ok" "Removed default site"
        CHANGES+=("Nginx: Removed default site")
    fi

    # Security headers and rate limiting config
    cat > "$NGINX_CONF_DIR/security-hardening.conf" << 'NGXEOF'
# Rate limiting
limit_req_zone $binary_remote_addr zone=general:10m rate=10r/s;

server {
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Content-Security-Policy "default-src 'self';" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Restrict HTTP methods
    if ($request_method !~ ^(GET|HEAD|POST)$) {
        return 405;
    }
}
NGXEOF
    print_result "ok" "Security headers and rate limiting added"
    CHANGES+=("Nginx: Security headers added")
    CHANGES+=("Nginx: Rate limiting added")
    CHANGES+=("Nginx: HTTP methods restricted to GET/HEAD/POST")

    RESTART_NGINX=true
}

# ---------- Tomcat Hardening ----------
harden_tomcat() {
    echo -e "\n${CYAN}[*] Checking for Tomcat...${NC}"

    # Find Tomcat installation
    TOMCAT_HOME=""
    for path in /opt/tomcat /usr/share/tomcat /var/lib/tomcat* /opt/tomcat*; do
        if [[ -d "$path" && -f "$path/conf/server.xml" ]]; then
            TOMCAT_HOME="$path"
            break
        fi
    done

    if [[ -z "$TOMCAT_HOME" ]]; then
        print_result "skip" "Tomcat not installed"
        return
    fi

    echo -e "  ${GREEN}Tomcat found at $TOMCAT_HOME — hardening...${NC}"

    # Remove default webapps
    for app in manager host-manager examples docs ROOT; do
        if [[ -d "$TOMCAT_HOME/webapps/$app" ]]; then
            rm -rf "$TOMCAT_HOME/webapps/$app"
            print_result "ok" "Removed webapp: $app"
            CHANGES+=("Tomcat: Removed $app")
        else
            print_result "skip" "Webapp $app not present"
        fi
    done

    SERVER_XML="$TOMCAT_HOME/conf/server.xml"

    if [[ -f "$SERVER_XML" ]]; then
        # Change SHUTDOWN string
        RANDOM_SHUTDOWN=$(head /dev/urandom | tr -dc A-Za-z0-9 | head -c 16)
        sed -i "s/shutdown=\"SHUTDOWN\"/shutdown=\"$RANDOM_SHUTDOWN\"/" "$SERVER_XML"
        print_result "ok" "SHUTDOWN string changed to random value"
        CHANGES+=("Tomcat: SHUTDOWN string randomized")

        # Disable AJP connector
        if grep -q '<!-- *<Connector.*protocol="AJP' "$SERVER_XML"; then
            print_result "skip" "AJP connector already commented out"
        elif grep -q '<Connector.*protocol="AJP' "$SERVER_XML"; then
            sed -i 's|<Connector\(.*protocol="AJP\)|<!-- <Connector\1|' "$SERVER_XML"
            sed -i 's|\(protocol="AJP[^/]*\)/>\(.*\)|\1/> -->\2|' "$SERVER_XML"
            print_result "ok" "AJP connector disabled"
            CHANGES+=("Tomcat: AJP disabled")
        else
            print_result "skip" "No AJP connector found"
        fi

        # Remove server version from error pages
        if ! grep -q "showServerInfo" "$SERVER_XML"; then
            sed -i 's|<Host |<Host errorReportValveClass="org.apache.catalina.valves.ErrorReportValve" showServerInfo="false" showReport="false" |' "$SERVER_XML"
            print_result "ok" "Server version hidden from error pages"
            CHANGES+=("Tomcat: Version hidden from errors")
        fi
    fi

    # Restrict manager to localhost if context.xml exists
    CONTEXT_XML="$TOMCAT_HOME/conf/context.xml"
    if [[ -f "$CONTEXT_XML" ]]; then
        if ! grep -q "RemoteAddrValve" "$CONTEXT_XML"; then
            sed -i '/<\/Context>/i\    <Valve className="org.apache.catalina.valves.RemoteAddrValve" allow="127\\.\\d+\\.\\d+\\.\\d+|::1" />' "$CONTEXT_XML"
            print_result "ok" "Manager restricted to localhost"
            CHANGES+=("Tomcat: Manager localhost only")
        fi
    fi

    RESTART_TOMCAT=true
}

# ---------- Caddy Hardening ----------
harden_caddy() {
    echo -e "\n${CYAN}[*] Checking for Caddy...${NC}"

    if ! command -v caddy &>/dev/null; then
        print_result "skip" "Caddy not installed"
        return
    fi

    echo -e "  ${GREEN}Caddy found — hardening...${NC}"

    CADDY_CONF=""
    for path in /etc/caddy/Caddyfile /etc/caddy/caddy.conf; do
        if [[ -f "$path" ]]; then
            CADDY_CONF="$path"
            break
        fi
    done

    if [[ -z "$CADDY_CONF" ]]; then
        print_result "fail" "Caddy config not found"
        return
    fi

    # Add security headers if not present
    if ! grep -q "X-Frame-Options" "$CADDY_CONF"; then
        cat >> "$CADDY_CONF" << 'CADDYEOF'

# Security headers
(security_headers) {
    header {
        X-Frame-Options "SAMEORIGIN"
        X-Content-Type-Options "nosniff"
        X-XSS-Protection "1; mode=block"
        Content-Security-Policy "default-src 'self';"
        Referrer-Policy "strict-origin-when-cross-origin"
        -Server
    }
}
CADDYEOF
        print_result "ok" "Security headers added"
        CHANGES+=("Caddy: Security headers added")
    fi

    # Disable file browsing
    if grep -q "file_server browse" "$CADDY_CONF"; then
        sed -i 's/file_server browse/file_server/' "$CADDY_CONF"
        print_result "ok" "File browsing disabled"
        CHANGES+=("Caddy: File browsing disabled")
    else
        print_result "skip" "File browsing already disabled or not set"
    fi

    RESTART_CADDY=true
}

# ---------- Restart Services ----------
restart_services() {
    echo -e "\n${CYAN}[*] Restarting modified services...${NC}"

    if [[ "${RESTART_APACHE:-false}" == true ]]; then
        if systemctl restart "$APACHE_SERVICE" &>/dev/null; then
            print_result "ok" "Restarted $APACHE_SERVICE"
        else
            print_result "fail" "Failed to restart $APACHE_SERVICE"
        fi
    fi

    if [[ "${RESTART_NGINX:-false}" == true ]]; then
        if nginx -t &>/dev/null && systemctl restart nginx &>/dev/null; then
            print_result "ok" "Restarted nginx"
        else
            print_result "fail" "Failed to restart nginx — check config with: nginx -t"
        fi
    fi

    if [[ "${RESTART_TOMCAT:-false}" == true ]]; then
        TOMCAT_SVC=""
        for svc in tomcat tomcat9 tomcat10; do
            if systemctl list-units --type=service --all | grep -q "$svc"; then
                TOMCAT_SVC="$svc"
                break
            fi
        done
        if [[ -n "$TOMCAT_SVC" ]]; then
            if systemctl restart "$TOMCAT_SVC" &>/dev/null; then
                print_result "ok" "Restarted $TOMCAT_SVC"
            else
                print_result "fail" "Failed to restart $TOMCAT_SVC"
            fi
        else
            print_result "skip" "No Tomcat service found — restart manually"
        fi
    fi

    if [[ "${RESTART_CADDY:-false}" == true ]]; then
        if systemctl restart caddy &>/dev/null; then
            print_result "ok" "Restarted caddy"
        else
            print_result "fail" "Failed to restart caddy"
        fi
    fi
}

# ---------- Summary ----------
print_summary() {
    echo -e "\n${CYAN}============================================${NC}"
    echo -e "${CYAN}  HARDENING SUMMARY${NC}"
    echo -e "${CYAN}============================================${NC}"
    if [[ ${#CHANGES[@]} -eq 0 ]]; then
        echo -e "  ${YELLOW}No changes were made.${NC}"
    else
        echo -e "  ${GREEN}${#CHANGES[@]} changes applied:${NC}\n"
        for change in "${CHANGES[@]}"; do
            echo -e "    • $change"
        done
    fi
    echo -e "\n${CYAN}============================================${NC}"
}

# ---------- Main ----------
main() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}[!] This script must be run as root (use sudo).${NC}"
        exit 1
    fi

    print_banner
    detect_os
    set_file_permissions
    harden_apache
    harden_nginx
    harden_tomcat
    harden_caddy
    restart_services
    print_summary
}

main "$@"
