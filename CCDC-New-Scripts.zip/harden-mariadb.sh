#!/usr/bin/env bash
#
# harden-mariadb.sh - Harden MariaDB server configuration on Red Hat- and Debian-family Linux.
#
# What it does:
#   * Writes one drop-in file (99-hardening.cnf), loaded last, containing:
#       [mysqld]  local-infile=0, symbolic-links=0, secure-file-priv=<dir>, general-log=0,
#                 log-warnings=2, allow-suspicious-udfs=0, secure-auth=1, old-passwords=0,
#                 disconnect-on-expired-password=1   (+ skip-name-resolve=1 if requested)
#       [client]  local-infile=0
#   * Comments out skip-grant-tables wherever it appears in existing config files.
#   * Tightens ownership/permissions of config files, the data directory and log files.
#   * Creates a mysql-only secure_file_priv directory (SELinux-labelled on RHEL).
#   * Validates the new config, optionally restarts, and rolls back automatically on failure.
#   * Runs a READ-ONLY account audit (reports only; never creates, drops or alters accounts).
#
# What it deliberately never touches:
#   users/accounts, TLS/SSL, port, bind-address, skip-networking or any other listener setting.
#
# Every run saves the previous config and permissions under /var/backups/mariadb-hardening/
# together with a restore.sh that undoes the changes.

set -euo pipefail

SCRIPT_NAME=$(basename "$0")
DROPIN_NAME="99-hardening.cnf"
SFP_DEFAULT="/var/lib/mysql-files"
UNSET="<unset>"
TS=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="/var/backups/mariadb-hardening/$TS"
PROTECTED_DIRS=(/ /etc /var /var/lib /var/log /usr /opt /home /root /tmp /run /srv /boot)

DRY_RUN=0
DO_RESTART=0
SKIP_NAME_RESOLVE=0
FORCE=0
DO_AUDIT=1
WARNINGS=0

if [[ -t 1 ]]; then
  C_R=$'\e[31m' C_Y=$'\e[33m' C_G=$'\e[32m' C_B=$'\e[1m' C_0=$'\e[0m'
else
  C_R='' C_Y='' C_G='' C_B='' C_0=''
fi
info() { printf '%s[INFO]%s %s\n' "$C_B" "$C_0" "$*"; }
ok()   { printf '%s[ OK ]%s %s\n' "$C_G" "$C_0" "$*"; }
warn() { printf '%s[WARN]%s %s\n' "$C_Y" "$C_0" "$*" >&2; WARNINGS=$((WARNINGS + 1)); }
die()  { printf '%s[FAIL]%s %s\n' "$C_R" "$C_0" "$*" >&2; exit 1; }
run()  { if (( DRY_RUN )); then printf '    [dry-run] %s\n' "$*"; else "$@"; fi; }

usage() {
  cat <<EOF
Usage: sudo $SCRIPT_NAME [options]

  -n, --dry-run          Show what would change; modify nothing.
  -r, --restart          Restart MariaDB after applying (auto-rollback if it fails to start).
      --skip-name-resolve  Also set skip-name-resolve=1 (skipped if hostname-based accounts
                         exist, unless --force is given).
      --force            Apply --skip-name-resolve even if it may break hostname-based accounts.
      --no-audit         Skip the read-only account audit.
  -h, --help             Show this help.

Never modifies users, TLS/SSL, ports, bind addresses or networking.
EOF
}

while (( $# )); do
  case $1 in
    -n|--dry-run)        DRY_RUN=1 ;;
    -r|--restart)        DO_RESTART=1 ;;
    --skip-name-resolve) SKIP_NAME_RESOLVE=1 ;;
    --force)             FORCE=1 ;;
    --no-audit)          DO_AUDIT=0 ;;
    -h|--help)           usage; exit 0 ;;
    *)                   usage >&2; die "Unknown option: $1" ;;
  esac
  shift
done

(( EUID == 0 )) || die "Must be run as root (sudo $SCRIPT_NAME)"

# --------------------------------------------------------------------------- helpers

find_bin() {
  local b
  for b in "$@"; do
    if [[ $b == /* ]]; then
      if [[ -x $b ]]; then printf '%s\n' "$b"; return 0; fi
    elif command -v "$b" >/dev/null 2>&1; then
      command -v "$b"; return 0
    fi
  done
  return 1
}

is_protected() {
  local p d
  p=$(readlink -f -- "$1" 2>/dev/null || printf '%s' "$1")
  for d in "${PROTECTED_DIRS[@]}"; do [[ $p == "$d" ]] && return 0; done
  return 1
}

# Run "<cmd> <path>" for every path matched by: find <find-args...>
apply_find() {
  local -a cmd
  local p
  read -r -a cmd <<<"$1"; shift
  while IFS= read -r -d '' p; do
    run "${cmd[@]}" "$p"
  done < <(find "$@" -print0 2>/dev/null)
}

# Effective server option list, as mariadbd would read it.
load_defaults() {
  local out
  [[ -n $PRINT_DEFAULTS ]] || return 0
  if out=$("$PRINT_DEFAULTS" --mysqld 2>/dev/null); then
    printf '%s\n' "$out"
  else
    "$PRINT_DEFAULTS" mysqld server mariadb mariadbd client-server galera 2>/dev/null || true
  fi
}

# Last effective value of a server option (handles -/_ , loose-, skip-/disable-/enable-).
opt_value() {
  local want=${1//_/-}
  printf '%s\n' "$DEFAULTS_BEFORE" | awk -v want="$want" -v unset="$UNSET" -v q="'" '
    {
      line = $0; sub(/^--/, "", line)
      eq = index(line, "=")
      key = eq ? substr(line, 1, eq - 1) : line
      val = eq ? substr(line, eq + 1) : "1"
      gsub(/_/, "-", key); sub(/^loose-/, "", key)
      if (val ~ /^".*"$/ || val ~ ("^" q ".*" q "$")) val = substr(val, 2, length(val) - 2)
      if (key == want)                  { found = val; seen = 1 }
      else if (key == "skip-" want)     { found = "0"; seen = 1 }
      else if (key == "disable-" want)  { found = "0"; seen = 1 }
      else if (key == "enable-" want)   { found = "1"; seen = 1 }
    }
    END { print (seen ? found : unset) }'
}

sql() { "$CLIENT" -NB --connect-timeout=5 -e "$1" 2>/dev/null; }

validate_config() {
  if command -v timeout >/dev/null 2>&1; then
    timeout 60 "$MYSQLD" --user=mysql --verbose --help >/dev/null 2>"$1"
  else
    "$MYSQLD" --user=mysql --verbose --help >/dev/null 2>"$1"
  fi
}

rollback_config() {
  warn "Rolling back configuration files from $BACKUP_DIR"
  rm -f -- "$DROPIN"
  tar -xpf "$BACKUP_DIR/config.tar" -C /
}

# --------------------------------------------------------------------------- detection

os_ids=$(. /etc/os-release 2>/dev/null; printf ' %s %s ' "${ID:-}" "${ID_LIKE:-}")
case $os_ids in
  *" rhel "*|*" fedora "*|*" centos "*)
    OS_FAMILY=redhat
    CONFIG_PATHS=(/etc/my.cnf /etc/my.cnf.d)
    CONF_DIR=/etc/my.cnf.d
    DEFAULT_SOCKET=/var/lib/mysql/mysql.sock
    DISTRO_LOG_DIRS=(/var/log/mariadb /var/log/mysql)
    ;;
  *" debian "*|*" ubuntu "*)
    OS_FAMILY=debian
    CONFIG_PATHS=(/etc/mysql)
    CONF_DIR=/etc/mysql/mariadb.conf.d
    [[ -d $CONF_DIR ]] || CONF_DIR=/etc/mysql/conf.d
    DEFAULT_SOCKET=/run/mysqld/mysqld.sock
    DISTRO_LOG_DIRS=(/var/log/mysql)
    ;;
  *)
    die "Unsupported distribution (expected a Red Hat or Debian family system)"
    ;;
esac
[[ -d $CONF_DIR ]] || die "Config include directory $CONF_DIR not found - is mariadb-server installed?"
DROPIN="$CONF_DIR/$DROPIN_NAME"

MYSQLD=$(find_bin /usr/sbin/mariadbd /usr/sbin/mysqld /usr/libexec/mariadbd /usr/libexec/mysqld mariadbd mysqld) \
  || die "MariaDB server binary not found - is mariadb-server installed?"
MYSQLD_VERSION=$("$MYSQLD" --version 2>/dev/null || true)
[[ $MYSQLD_VERSION == *MariaDB* ]] || die "$MYSQLD does not look like MariaDB: ${MYSQLD_VERSION:-no version output}"
CLIENT=$(find_bin mariadb mysql) || CLIENT=""
PRINT_DEFAULTS=$(find_bin my_print_defaults mariadb-print-defaults) || PRINT_DEFAULTS=""
id -u mysql >/dev/null 2>&1 || die "OS account 'mysql' not found - is mariadb-server installed?"

SERVICE=""
if command -v systemctl >/dev/null 2>&1; then
  for s in mariadb mysql mysqld; do
    if systemctl cat "$s.service" >/dev/null 2>&1; then SERVICE=$s; break; fi
  done
fi

EXISTING_CONFIG_PATHS=()
for p in "${CONFIG_PATHS[@]}"; do [[ -e $p ]] && EXISTING_CONFIG_PATHS+=("$p"); done
CONFIG_FILES=()
while IFS= read -r -d '' f; do CONFIG_FILES+=("$f"); done \
  < <(find "${EXISTING_CONFIG_PATHS[@]}" -type f -name '*.cnf' -print0 2>/dev/null)

include_found=0
for f in ${CONFIG_FILES[@]+"${CONFIG_FILES[@]}"}; do
  if grep -Eqs "^[[:space:]]*!includedir[[:space:]]+${CONF_DIR}/?[[:space:]]*$" "$f"; then include_found=1; break; fi
done
(( include_found )) || die "No '!includedir $CONF_DIR' found in the main config; the drop-in would be ignored."

[[ -n $PRINT_DEFAULTS ]] || warn "my_print_defaults not found; assuming distribution default paths"
DEFAULTS_BEFORE=$(load_defaults)

DATADIR=$(opt_value datadir)
[[ $DATADIR == "$UNSET" || -z $DATADIR ]] && DATADIR=/var/lib/mysql
DATADIR=$(readlink -f -- "$DATADIR" 2>/dev/null || printf '%s' "$DATADIR")
SOCKET=$(opt_value socket)
[[ $SOCKET == "$UNSET" || -z $SOCKET ]] && SOCKET=$DEFAULT_SOCKET

info "System:   $OS_FAMILY family ($(. /etc/os-release; printf '%s' "${PRETTY_NAME:-unknown}"))"
info "Server:   $MYSQLD_VERSION"
info "Service:  ${SERVICE:-<none detected>}"
info "Config:   drop-in $DROPIN"
info "Datadir:  $DATADIR   Socket: $SOCKET"
(( DRY_RUN )) && info "DRY RUN - no changes will be made"

# --------------------------------------------------------------------------- settings

# secure_file_priv: keep an existing absolute directory, otherwise use a dedicated one.
SFP_DIR=""
cur_sfp=$(opt_value secure_file_priv)
if [[ $cur_sfp == /* ]]; then
  SFP_DIR=$cur_sfp
elif [[ $cur_sfp != "$UNSET" && -n $cur_sfp ]]; then
  warn "secure_file_priv is set to '$cur_sfp' (not an absolute path); leaving it unchanged"
else
  SFP_DIR=$SFP_DEFAULT
fi

SETTINGS=(
  "local_infile=0"                          # no LOAD DATA LOCAL (client file exfiltration)
  "symbolic_links=0"                        # no symlinked tables pointing outside datadir
  "general_log=0"                           # general log records statements, incl. passwords
  "log_warnings=2"                          # log aborted connections and access-denied errors
  "allow_suspicious_udfs=0"                 # only load UDFs with proper entry points
  "loose_secure_auth=1"                     # refuse pre-4.1 password hashes
  "loose_old_passwords=0"                   # never generate pre-4.1 password hashes
  "loose_disconnect_on_expired_password=1"  # expired-password clients cannot run sandboxed
)
[[ -n $SFP_DIR ]] && SETTINGS+=("secure_file_priv=$SFP_DIR")

if (( SKIP_NAME_RESOLVE )); then
  if [[ -n $CLIENT ]] && sql 'SELECT 1' >/dev/null; then
    host_accts=$(sql "SELECT CONCAT(QUOTE(User),'@',QUOTE(Host)) FROM mysql.user
                      WHERE Host NOT IN ('', 'localhost', '127.0.0.1', '::1', '%')
                        AND Host NOT REGEXP '^[0-9.%_/]+\$' AND Host NOT LIKE '%:%'") || host_accts=""
    if [[ -n $host_accts ]]; then
      warn "skip-name-resolve would stop these hostname-based accounts from matching: $(tr '\n' ' ' <<<"$host_accts")"
      (( FORCE )) || { warn "Not enabling skip-name-resolve (use --force to override)"; SKIP_NAME_RESOLVE=0; }
    fi
  elif (( ! FORCE )); then
    warn "Cannot connect to check for hostname-based accounts; not enabling skip-name-resolve (use --force)"
    SKIP_NAME_RESOLVE=0
  fi
  (( SKIP_NAME_RESOLVE )) && SETTINGS+=("skip_name_resolve=1")
fi

info "Server settings (current -> hardened):"
for kv in "${SETTINGS[@]}"; do
  key=${kv%%=*}; key=${key#loose_}
  cur=$(opt_value "$key")
  [[ $cur == "$UNSET" ]] && cur="(default)"
  printf '      %-32s %s -> %s\n' "$key" "$cur" "${kv#*=}"
done

render_dropin() {
  local kv key
  printf '# Generated by %s on %s.\n' "$SCRIPT_NAME" "$(date '+%Y-%m-%d %H:%M:%S')"
  printf '# Re-running the script regenerates this file; manual edits will be lost.\n'
  printf '# Intentionally does not set users, TLS/SSL, port, bind-address or skip-networking.\n\n'
  printf '[mysqld]\n'
  for kv in "${SETTINGS[@]}"; do
    key=${kv%%=*}
    printf '%s = %s\n' "${key//_/-}" "${kv#*=}"
  done
  printf '\n[client]\nloose-local-infile = 0\n'
}

# --------------------------------------------------------------------------- backup

DATADIR_OK=1
if [[ ! -d $DATADIR ]]; then
  warn "Datadir $DATADIR does not exist; skipping datadir permissions"; DATADIR_OK=0
elif is_protected "$DATADIR"; then
  warn "Datadir resolves to system directory $DATADIR; skipping datadir permissions"; DATADIR_OK=0
fi

# Log files/dirs: those configured with absolute paths plus the distro defaults.
LOG_TARGETS=()
for opt in log_error slow_query_log_file general_log_file; do
  v=$(opt_value "$opt")
  [[ $v == /* ]] || continue
  if is_protected "$(dirname -- "$v")"; then LOG_TARGETS+=("$v"); else LOG_TARGETS+=("$(dirname -- "$v")"); fi
done
for d in "${DISTRO_LOG_DIRS[@]}"; do [[ -d $d ]] && LOG_TARGETS+=("$d"); done
if (( ${#LOG_TARGETS[@]} )); then
  deduped=()
  while IFS= read -r t; do deduped+=("$t"); done < <(printf '%s\n' "${LOG_TARGETS[@]}" | awk '!seen[$0]++')
  LOG_TARGETS=("${deduped[@]}")
fi

if (( ! DRY_RUN )); then
  install -d -m 0700 "$BACKUP_DIR"
  rel=()
  for p in "${EXISTING_CONFIG_PATHS[@]}" /root/.my.cnf; do [[ -e $p ]] && rel+=("${p#/}"); done
  tar -cpf "$BACKUP_DIR/config.tar" -C / "${rel[@]}"

  snapshot() { find "$@" ! -type l ! -type s -printf '%m %U %G %p\0' 2>/dev/null || true; }
  {
    printf '#!/usr/bin/env bash\n# Undo %s run of %s\nset -u\n' "$SCRIPT_NAME" "$TS"
    printf 'rm -f -- %q\n' "$DROPIN"
    printf 'tar -xpf %q -C /\n' "$BACKUP_DIR/config.tar"
    if [[ -n $SFP_DIR && ! -e $SFP_DIR ]]; then
      printf 'rmdir --ignore-fail-on-non-empty -- %q 2>/dev/null\n' "$SFP_DIR"
    fi
    while IFS= read -r -d '' rec; do
      mode=${rec%% *}; rest=${rec#* }
      uid=${rest%% *}; rest=${rest#* }
      gid=${rest%% *}; path=${rest#* }
      printf 'chown %s:%s -- %q; chmod %s -- %q\n' "$uid" "$gid" "$path" "$mode" "$path"
    done < <(
      (( DATADIR_OK )) && snapshot "$DATADIR" \( -perm /o=rwx -o -perm /g=w \)
      for t in ${LOG_TARGETS[@]+"${LOG_TARGETS[@]}"}; do [[ -e $t ]] && snapshot "$t"; done
      [[ -n $SFP_DIR && -e $SFP_DIR ]] && snapshot "$SFP_DIR" -maxdepth 0
      true
    )
    printf 'echo "Restored. Restart MariaDB to apply: systemctl restart %s"\n' "${SERVICE:-mariadb}"
  } >"$BACKUP_DIR/restore.sh"
  chmod 0700 "$BACKUP_DIR/restore.sh"
  ok "Backup saved to $BACKUP_DIR (undo with $BACKUP_DIR/restore.sh)"

  VALIDATE_BASELINE=0
  if validate_config "$BACKUP_DIR/validate-before.log"; then
    VALIDATE_BASELINE=1
  else
    warn "Existing config fails '$MYSQLD --verbose --help'; pre-restart validation disabled"
  fi
fi

# --------------------------------------------------------------------------- secure_file_priv dir

if [[ -n $SFP_DIR ]]; then
  if is_protected "$SFP_DIR"; then
    warn "secure_file_priv points at system directory $SFP_DIR; not changing its permissions"
  else
    if [[ ! -d $SFP_DIR ]]; then
      info "Creating secure_file_priv directory $SFP_DIR"
      run install -d -o mysql -g mysql -m 0750 "$SFP_DIR"
    elif [[ $(stat -c %U "$SFP_DIR") == mysql ]]; then
      run chmod 0750 "$SFP_DIR"
    else
      warn "$SFP_DIR is not owned by mysql; permissions left unchanged"
    fi

    if [[ $SFP_DIR == "$SFP_DEFAULT" ]] && command -v selinuxenabled >/dev/null 2>&1 && selinuxenabled; then
      if command -v semanage >/dev/null 2>&1; then
        if ! semanage fcontext -l 2>/dev/null | grep -F "${SFP_DIR}(/.*)?" >/dev/null; then
          run semanage fcontext -a -t mysqld_db_t "${SFP_DIR}(/.*)?"
        fi
      fi
      run restorecon -R "$SFP_DIR"
      if (( ! DRY_RUN )) && [[ $(stat -c %C "$SFP_DIR") != *:mysqld_db_t:* ]]; then
        run chcon -R -t mysqld_db_t "$SFP_DIR"
        warn "Applied a non-persistent SELinux label to $SFP_DIR; install policycoreutils-python-utils (semanage) to persist it"
      fi
    fi

    if command -v aa-status >/dev/null 2>&1 && [[ $(aa-status 2>/dev/null || true) == *mariadbd* || $(aa-status 2>/dev/null || true) == *mysqld* ]]; then
      warn "An AppArmor profile for mariadbd is loaded; make sure it allows $SFP_DIR"
    fi
  fi
fi

# --------------------------------------------------------------------------- drop-in + dangerous options

info "Writing $DROPIN"
if (( DRY_RUN )); then
  render_dropin | sed 's/^/      | /'
else
  tmp=$(mktemp "$CONF_DIR/.hardening.XXXXXX")
  render_dropin >"$tmp"
  chown root:root "$tmp"
  chmod 0644 "$tmp"
  mv -f -- "$tmp" "$DROPIN"
fi

for f in ${CONFIG_FILES[@]+"${CONFIG_FILES[@]}"}; do
  [[ $f == "$DROPIN" ]] && continue
  if grep -Eqs '^[[:space:]]*(loose[-_])?skip[-_]grant[-_]tables([[:space:]]|=|$)' "$f"; then
    warn "skip-grant-tables found in $f (disables all authentication) - commenting it out"
    run sed -i -E 's/^([[:space:]]*(loose[-_])?skip[-_]grant[-_]tables([[:space:]]|=|$))/# [disabled by harden-mariadb] \1/' "$f"
  fi
done

# --------------------------------------------------------------------------- permissions

info "Tightening config file ownership/permissions"
apply_find "chown root:root" "${EXISTING_CONFIG_PATHS[@]}" \( -type d -o -type f -name '*.cnf' \) \( ! -user root -o ! -group root \)
apply_find "chmod go-w"      "${EXISTING_CONFIG_PATHS[@]}" \( -type d -o -type f -name '*.cnf' \) -perm /022
apply_find "chmod a-x"       "${EXISTING_CONFIG_PATHS[@]}" -type f -name '*.cnf' -perm /111
[[ -f /etc/mysql/debian.cnf ]] && apply_find "chmod 0600" /etc/mysql/debian.cnf -maxdepth 0 -perm /077
[[ -f /root/.my.cnf ]] && apply_find "chmod 0600" /root/.my.cnf -maxdepth 0 -perm /077

while IFS= read -r f; do
  [[ $f == /etc/mysql/debian.cnf ]] && continue
  if [[ $(stat -c %a "$f") == *[4-7] ]]; then
    warn "$f contains a password and is world-readable; consider 'chown root:mysql' + 'chmod 0640'"
  fi
done < <(grep -lEs '^[[:space:]]*(password|wsrep[-_]sst[-_]auth)[[:space:]]*=' ${CONFIG_FILES[@]+"${CONFIG_FILES[@]}"} || true)

if (( DATADIR_OK )); then
  info "Tightening datadir permissions ($DATADIR)"
  owner=$(stat -c %U "$DATADIR")
  [[ $owner == mysql ]] || warn "$DATADIR is owned by '$owner', expected 'mysql' (not changed)"

  # Directories leading to the socket must keep o+x so local clients can still connect.
  keep=()
  d=$(readlink -f -- "$(dirname -- "$SOCKET")" 2>/dev/null || dirname -- "$SOCKET")
  while [[ $d == "$DATADIR" || $d == "$DATADIR"/* ]]; do
    keep+=("$d")
    [[ $d == "$DATADIR" ]] && break
    d=$(dirname -- "$d")
  done
  excl=()
  for d in ${keep[@]+"${keep[@]}"}; do excl+=(! -path "$d"); done

  # Only entries owned by mysql: stripping 'other' bits can't lock mysqld out of them.
  apply_find "chmod o-rwx" "$DATADIR" -user mysql ! -type l ! -type s -perm /o=rwx ${excl[@]+"${excl[@]}"}
  for d in ${keep[@]+"${keep[@]}"}; do apply_find "chmod o-rw" "$d" -maxdepth 0 -user mysql -perm /o=rw; done
  apply_find "chmod g-w" "$DATADIR" -maxdepth 0 -user mysql -perm /g=w

  not_mysql=()
  while IFS= read -r f; do not_mysql+=("$f"); done < <(find "$DATADIR" ! -user mysql 2>/dev/null | head -n 5)
  (( ${#not_mysql[@]} )) && warn "Entries in datadir not owned by mysql (not changed), e.g.: ${not_mysql[*]}"
fi

if (( ${#LOG_TARGETS[@]} )); then
  info "Tightening log permissions (${LOG_TARGETS[*]})"
  for t in "${LOG_TARGETS[@]}"; do
    [[ -e $t ]] && apply_find "chmod o-rwx" "$t" -user mysql ! -type l ! -type s -perm /o=rwx
  done
fi

for h in /root/.mysql_history /root/.mariadb_history; do
  [[ -s $h && ! -L $h ]] && warn "$h may contain sensitive statements; consider removing it and setting MYSQL_HISTFILE=/dev/null"
done

proc_users=$(ps -C mariadbd,mysqld -o user= 2>/dev/null | sort -u | tr '\n' ' ' || true)
[[ " $proc_users " == *" root "* ]] && warn "MariaDB server process is running as root"

# --------------------------------------------------------------------------- validate / restart

if (( ! DRY_RUN )) && (( VALIDATE_BASELINE )); then
  if validate_config "$BACKUP_DIR/validate-after.log"; then
    ok "New configuration passes validation"
  else
    tail -n 20 "$BACKUP_DIR/validate-after.log" >&2 || true
    rollback_config
    die "New configuration failed validation; changes to config files were rolled back"
  fi
fi

RESTARTED=0
if (( DO_RESTART )) && (( ! DRY_RUN )); then
  if [[ -z $SERVICE ]]; then
    warn "No systemd service found; restart MariaDB manually to apply"
  else
    info "Restarting $SERVICE"
    if systemctl restart "$SERVICE"; then
      ok "$SERVICE restarted"
      RESTARTED=1
    else
      journalctl -u "$SERVICE" -n 25 --no-pager >&2 2>/dev/null || true
      rollback_config
      if systemctl restart "$SERVICE"; then
        die "$SERVICE failed to start with hardened config; previous config restored and service restarted"
      fi
      die "$SERVICE failed to start, and also fails after rollback - see: journalctl -u $SERVICE"
    fi
  fi
fi

# --------------------------------------------------------------------------- runtime checks + audit

if [[ -n $CLIENT ]] && sql 'SELECT 1' >/dev/null; then
  if (( RESTARTED )); then
    info "Running values:"
    sql "SHOW GLOBAL VARIABLES WHERE Variable_name IN ('local_infile','have_symlink','secure_file_priv',
         'general_log','log_warnings','secure_auth','old_passwords','disconnect_on_expired_password',
         'skip_name_resolve')" | while IFS=$'\t' read -r n v; do printf '      %-32s %s\n' "$n" "$v"; done
  fi

  if (( DO_AUDIT )); then
    info "Read-only account audit (nothing is changed):"
    audit() {
      local label=$1 out line
      if ! out=$(sql "$2"); then info "  could not check: $label"; return 0; fi
      if [[ -z $out ]]; then ok "  none: $label"; return 0; fi
      warn "  found: $label"
      while IFS= read -r line; do printf '        %s\n' "$line"; done <<<"$out"
    }
    acct="CONCAT(QUOTE(User),'@',QUOTE(Host))"
    audit "anonymous accounts" \
      "SELECT $acct FROM mysql.user WHERE User=''"
    audit "accounts with an empty password" \
      "SELECT $acct FROM mysql.user WHERE User NOT IN ('', 'mariadb.sys') AND IFNULL(is_role,'N')<>'Y'
         AND plugin IN ('', 'mysql_native_password', 'mysql_old_password')
         AND IFNULL(authentication_string,'')='' AND IFNULL(Password,'')=''"
    audit "root accounts allowed from non-local hosts" \
      "SELECT $acct FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost','127.0.0.1','::1')"
    audit "accounts allowed from any host ('%')" \
      "SELECT $acct FROM mysql.user WHERE Host='%'"
    audit "non-root accounts with SUPER/FILE/GRANT/PROCESS/SHUTDOWN" \
      "SELECT $acct FROM mysql.user WHERE User NOT IN ('root','mysql','mariadb.sys')
         AND 'Y' IN (Super_priv, File_priv, Grant_priv, Process_priv, Shutdown_priv)"
    audit "test databases" \
      "SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='test' OR SCHEMA_NAME LIKE 'test!_%' ESCAPE '!'"
    audit "database-level grants on test* databases" \
      "SELECT CONCAT($acct,' ON ',QUOTE(Db)) FROM mysql.db WHERE Db LIKE 'test%'"
  fi
elif (( DO_AUDIT )); then
  info "Cannot connect as root over the local socket; skipped runtime checks and audit"
fi

# --------------------------------------------------------------------------- summary

echo
if (( DRY_RUN )); then
  info "Dry run complete; nothing was changed."
else
  ok "Hardening applied. Backup and undo script: $BACKUP_DIR"
  (( RESTARTED )) || info "Restart MariaDB to load the new settings: systemctl restart ${SERVICE:-mariadb}"
fi
(( WARNINGS )) && info "$WARNINGS warning(s) above need review."
exit 0
