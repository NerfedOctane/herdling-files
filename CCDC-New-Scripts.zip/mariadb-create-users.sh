#!/usr/bin/env bash
#
# mariadb-create-users.sh
# Create MariaDB users from a list file. Works on Red Hat family
# (RHEL, CentOS, Rocky, Alma, Fedora) and Debian family (Debian, Ubuntu).
#
# List file format (one user per line, comma separated):
#   username,host,password,database,privileges
#
#   - host        defaults to localhost
#   - password    left empty -> a random one is generated
#   - database    left empty -> no GRANT is issued; "*" means all databases
#   - privileges  defaults to "ALL PRIVILEGES"; separate several with ';'
#                 (e.g. SELECT;INSERT;UPDATE)
#   - blank lines and lines starting with '#' are ignored
#
# Example:
#   alice,localhost,S3cret!,appdb,ALL PRIVILEGES
#   bob,%,,reports,SELECT
#   carol,10.0.0.%,,,
#
set -euo pipefail

SCRIPT_NAME=$(basename "$0")
LIST_FILE=""
INSTALL=0
DRY_RUN=0
UPDATE_EXISTING=0
DEFAULTS_FILE=""
CRED_FILE="./mariadb-credentials-$(date +%Y%m%d-%H%M%S).txt"
PASSWORD_LENGTH=20

usage() {
    cat <<EOF
Usage: $SCRIPT_NAME -f LIST_FILE [options]

Options:
  -f FILE   List of users to create (required)
  -i        Install and start MariaDB server if it is missing
  -u        Update password/grants for users that already exist
  -c FILE   MariaDB client defaults file with admin credentials
            (default: connect as root over the unix socket)
  -o FILE   Where to write generated passwords (default: $CRED_FILE)
  -n        Dry run: print the SQL (passwords masked) without running it
  -h        Show this help
EOF
}

log()  { printf '[INFO]  %s\n' "$*"; }
warn() { printf '[WARN]  %s\n' "$*" >&2; }
die()  { printf '[ERROR] %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- distro ---

detect_distro() {
    [[ -r /etc/os-release ]] || die "Cannot read /etc/os-release; unsupported system."
    # shellcheck disable=SC1091
    . /etc/os-release
    local ids=" ${ID:-} ${ID_LIKE:-} "

    case "$ids" in
        *" debian "*|*" ubuntu "*)
            DISTRO_FAMILY="debian"
            PKG_INSTALL="apt-get install -y mariadb-server mariadb-client"
            PKG_UPDATE="apt-get update"
            ;;
        *" rhel "*|*" fedora "*|*" centos "*|*" rocky "*|*" almalinux "*)
            DISTRO_FAMILY="redhat"
            if command -v dnf >/dev/null 2>&1; then
                PKG_INSTALL="dnf install -y mariadb-server mariadb"
            else
                PKG_INSTALL="yum install -y mariadb-server mariadb"
            fi
            PKG_UPDATE=""
            ;;
        *)
            die "Unsupported distribution: ${PRETTY_NAME:-unknown}"
            ;;
    esac
    log "Detected ${PRETTY_NAME:-$ID} ($DISTRO_FAMILY family)"
}

find_client() {
    if command -v mariadb >/dev/null 2>&1; then
        CLIENT="mariadb"
    elif command -v mysql >/dev/null 2>&1; then
        CLIENT="mysql"
    else
        CLIENT=""
    fi
}

install_mariadb() {
    [[ $EUID -eq 0 ]] || die "Installing packages requires root (use sudo)."
    log "Installing MariaDB server..."
    [[ -n $PKG_UPDATE ]] && $PKG_UPDATE
    $PKG_INSTALL
    systemctl enable --now mariadb
    find_client
}

ensure_running() {
    if command -v systemctl >/dev/null 2>&1 && ! systemctl is-active --quiet mariadb; then
        if [[ $INSTALL -eq 1 ]]; then
            log "Starting mariadb service..."
            systemctl enable --now mariadb
        else
            warn "mariadb service does not appear to be running (use -i to start it)."
        fi
    fi
}

# ------------------------------------------------------------------- SQL ---

# Escape a value for use inside single-quoted SQL strings.
sql_escape() {
    local s=$1
    s=${s//\\/\\\\}
    s=${s//\'/\\\'}
    printf '%s' "$s"
}

gen_password() {
    if command -v openssl >/dev/null 2>&1; then
        openssl rand -base64 48 | tr -dc 'A-Za-z0-9' | head -c "$PASSWORD_LENGTH"
    else
        LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$PASSWORD_LENGTH"
    fi
}

run_sql() {
    if [[ $DRY_RUN -eq 1 ]]; then
        # Mask anything between IDENTIFIED BY '...'
        sed -E "s/(IDENTIFIED BY ')([^']|\\\\')*'/\1********'/g"
        return 0
    fi
    # SQL goes through stdin so passwords never appear in the process list.
    if [[ -n $DEFAULTS_FILE ]]; then
        "$CLIENT" --defaults-extra-file="$DEFAULTS_FILE" --batch "$@"
    else
        "$CLIENT" -u root --batch "$@"
    fi
}

user_exists() {
    [[ $DRY_RUN -eq 1 ]] && return 1
    local count
    count=$(printf "SELECT COUNT(*) FROM mysql.user WHERE User='%s' AND Host='%s';\n" \
                "$(sql_escape "$1")" "$(sql_escape "$2")" | run_sql --skip-column-names 2>/dev/null | tail -n1)
    [[ ${count:-0} -gt 0 ]]
}

# ------------------------------------------------------------ validation ---

valid_user()  { [[ $1 =~ ^[A-Za-z0-9_.-]{1,80}$ ]]; }
valid_host()  { [[ $1 =~ ^[A-Za-z0-9_.%:-]{1,255}$ ]]; }
valid_db()    { [[ $1 == "*" || $1 =~ ^[A-Za-z0-9_\$]{1,64}$ ]]; }
PRIVS_RE='^[A-Za-z ]+(;[A-Za-z ]+)*$'
valid_privs() { [[ $1 =~ $PRIVS_RE ]]; }

trim() { local s=$1; s=${s#"${s%%[![:space:]]*}"}; s=${s%"${s##*[![:space:]]}"}; printf '%s' "$s"; }

# ------------------------------------------------------------------ main ---

process_list() {
    local line_no=0 created=0 updated=0 skipped=0 failed=0
    local user host pass db privs generated sql target action

    if [[ $DRY_RUN -eq 0 ]]; then
        ( umask 077; : > "$CRED_FILE" )
    fi

    while IFS= read -r line || [[ -n $line ]]; do
        line_no=$((line_no + 1))
        line=$(trim "${line%$'\r'}")
        [[ -z $line || $line == \#* ]] && continue

        IFS=',' read -r user host pass db privs <<<"$line"
        user=$(trim "${user:-}")
        host=$(trim "${host:-}");   host=${host:-localhost}
        pass=$(trim "${pass:-}")
        db=$(trim "${db:-}")
        privs=$(trim "${privs:-}"); privs=${privs:-ALL PRIVILEGES}

        if ! valid_user "$user"; then warn "Line $line_no: invalid username '$user', skipped."; failed=$((failed+1)); continue; fi
        if ! valid_host "$host"; then warn "Line $line_no: invalid host '$host', skipped.";     failed=$((failed+1)); continue; fi
        if [[ -n $db ]] && ! valid_db "$db"; then warn "Line $line_no: invalid database '$db', skipped."; failed=$((failed+1)); continue; fi
        if ! valid_privs "$privs"; then warn "Line $line_no: invalid privileges '$privs', skipped."; failed=$((failed+1)); continue; fi

        generated=0
        if [[ -z $pass ]]; then
            pass=$(gen_password)
            generated=1
        fi

        target="'$(sql_escape "$user")'@'$(sql_escape "$host")'"

        if user_exists "$user" "$host"; then
            if [[ $UPDATE_EXISTING -eq 0 ]]; then
                log "User $user@$host already exists, skipped (use -u to update)."
                skipped=$((skipped+1))
                continue
            fi
            sql="ALTER USER $target IDENTIFIED BY '$(sql_escape "$pass")';"
            action="updated"
        else
            sql="CREATE USER $target IDENTIFIED BY '$(sql_escape "$pass")';"
            action="created"
        fi

        if [[ -n $db ]]; then
            local scope
            if [[ $db == "*" ]]; then scope="*.*"; else scope="\`$db\`.*"; fi
            sql+=$'\n'"GRANT ${privs//;/, } ON $scope TO $target;"
        fi

        if printf '%s\n' "$sql" | run_sql; then
            log "User $user@$host $action${db:+ (grants on $db)}."
            [[ $action == created ]] && created=$((created+1)) || updated=$((updated+1))
            if [[ $generated -eq 1 && $DRY_RUN -eq 0 ]]; then
                printf '%s@%s\t%s\n' "$user" "$host" "$pass" >> "$CRED_FILE"
            fi
        else
            warn "Failed to create/update $user@$host."
            failed=$((failed+1))
        fi
    done < "$LIST_FILE"

    echo
    log "Done: $created created, $updated updated, $skipped skipped, $failed failed."
    if [[ $DRY_RUN -eq 0 && -s $CRED_FILE ]]; then
        log "Generated passwords saved to $CRED_FILE (mode 600)."
    elif [[ $DRY_RUN -eq 0 ]]; then
        rm -f "$CRED_FILE"
    fi
}

while getopts ":f:iuc:o:nh" opt; do
    case $opt in
        f) LIST_FILE=$OPTARG ;;
        i) INSTALL=1 ;;
        u) UPDATE_EXISTING=1 ;;
        c) DEFAULTS_FILE=$OPTARG ;;
        o) CRED_FILE=$OPTARG ;;
        n) DRY_RUN=1 ;;
        h) usage; exit 0 ;;
        :) die "Option -$OPTARG requires an argument." ;;
        *) usage; exit 1 ;;
    esac
done

[[ -n $LIST_FILE ]] || { usage; exit 1; }
[[ -r $LIST_FILE ]] || die "Cannot read list file: $LIST_FILE"
[[ -z $DEFAULTS_FILE || -r $DEFAULTS_FILE ]] || die "Cannot read defaults file: $DEFAULTS_FILE"

if [[ $DRY_RUN -eq 0 ]]; then
    detect_distro
    find_client
    if [[ -z $CLIENT ]]; then
        [[ $INSTALL -eq 1 ]] || die "MariaDB client not found. Re-run with -i to install MariaDB."
        install_mariadb
    fi
    ensure_running
    printf 'SELECT 1;\n' | run_sql >/dev/null || die "Cannot connect to MariaDB as admin (try sudo, or -c with a defaults file)."
fi

process_list
