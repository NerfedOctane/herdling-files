#!/bin/bash
#
# mass_user_keep.sh — variant of mass_user_delete.sh
#
# Takes a list of users to KEEP (include system users!) and deletes every
# other local account in /etc/passwd.
#
# Usage: sudo ./mass_user_keep.sh [-n] [-y] [-k] <keeplist.txt>
#   -n  dry run: show what would be deleted, change nothing
#   -y  skip the confirmation prompt
#   -k  kill a user's processes before deleting them (otherwise userdel
#       fails for users that are logged in / running processes)
#
# Keep-list format: one username per line. Blank lines and '#' comments are
# ignored, surrounding whitespace and Windows line endings are stripped.
#
# Safety nets (always on, regardless of the keep list):
#   - root and the user who invoked sudo are never deleted
#   - a home directory is only removed (-r) if it is owned by the user being
#     deleted and is not a system path like /, /bin, /var, /usr/sbin, etc.
#     This prevents e.g. forgetting "bin" in the keep list from wiping /bin.

set -uo pipefail

error() { echo "[ERROR] $*" >&2; exit 1; }
info()  { echo "[*] $*"; }

usage() {
    echo "Usage: sudo $0 [-n] [-y] [-k] <keeplist.txt>"
    echo "  keeplist.txt — list of users to KEEP; every other local user is deleted"
    echo "  -n  dry run    -y  no confirmation    -k  kill user processes first"
    exit 1
}

DRY_RUN=0
ASSUME_YES=0
KILL_PROCS=0
while getopts ":nyk" opt; do
    case "$opt" in
        n) DRY_RUN=1 ;;
        y) ASSUME_YES=1 ;;
        k) KILL_PROCS=1 ;;
        *) usage ;;
    esac
done
shift $((OPTIND - 1))

# ---------------------------
# Pre-flight checks
# ---------------------------
[[ -z "${1:-}" ]] && usage

if [[ $EUID -ne 0 && $DRY_RUN -eq 0 ]]; then
    error "This script must be run as root (use sudo)."
fi

KEEPLIST_INPUT="$1"
[[ -f "$KEEPLIST_INPUT" ]] || error "Keep list file not found: $KEEPLIST_INPUT"

# ---------------------------
# Build keep set
# ---------------------------
declare -A KEEP=()
while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%%#*}"          # strip comments
    line="${line//$'\r'/}"      # strip CR
    line="$(echo "$line" | xargs)"  # trim whitespace
    [[ -z "$line" ]] && continue
    KEEP["$line"]=1
done < "$KEEPLIST_INPUT"

# Hard-coded safety: never delete root or whoever ran sudo
KEEP["root"]=1
[[ -n "${SUDO_USER:-}" ]] && KEEP["$SUDO_USER"]=1

[[ ${#KEEP[@]} -le 2 ]] && info "WARNING: keep list only contains root/invoking user — did you forget system users?"

# Warn about keep-list entries that don't exist (likely typos)
for u in "${!KEEP[@]}"; do
    getent passwd "$u" >/dev/null || info "Note: '$u' is in keep list but does not exist on this system"
done

# ---------------------------
# Determine users to delete (local accounts only)
# ---------------------------
TO_DELETE=()
while IFS=: read -r user _ uid _ _ home _; do
    [[ -z "$user" || "$user" == \#* ]] && continue
    [[ -n "${KEEP[$user]:-}" ]] && continue
    TO_DELETE+=("$user")
done < /etc/passwd

if [[ ${#TO_DELETE[@]} -eq 0 ]]; then
    info "Nothing to delete — every local user is in the keep list."
    exit 0
fi

info "The following ${#TO_DELETE[@]} user(s) will be DELETED:"
for u in "${TO_DELETE[@]}"; do
    printf '    %-20s uid=%-6s home=%s\n' "$u" "$(id -u "$u" 2>/dev/null)" "$(getent passwd "$u" | cut -d: -f6)"
done

if [[ $DRY_RUN -eq 1 ]]; then
    info "Dry run — no changes made."
    exit 0
fi

if [[ $ASSUME_YES -eq 0 ]]; then
    read -r -p "Proceed? [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]] || { info "Aborted."; exit 0; }
fi

# ---------------------------
# Helpers
# ---------------------------
# Paths whose removal would break the system
is_protected_path() {
    local p
    p="$(readlink -f "$1" 2>/dev/null || echo "$1")"
    case "$p" in
        ""|/|/bin|/sbin|/lib|/lib32|/lib64|/libx32|/usr|/usr/*bin|/usr/lib*|/usr/share|/usr/local|\
        /etc|/var|/var/lib|/var/spool|/var/run|/var/log|/var/cache|/var/mail|/var/www|/run|/proc|/sys|\
        /dev|/boot|/opt|/srv|/tmp|/root|/home|/nonexistent|/dev/null)
            return 0 ;;
    esac
    return 1
}

# ---------------------------
# Delete
# ---------------------------
deleted=0; failed=0
for user in "${TO_DELETE[@]}"; do
    uid="$(id -u "$user" 2>/dev/null)" || { info "Skipping $user (no longer exists)"; continue; }
    home="$(getent passwd "$user" | cut -d: -f6)"

    # Does this UID belong to another account we're keeping? (e.g. a UID 0
    # backdoor shares root's UID). If so, killing its processes would kill
    # the kept user's processes too (pkill -u 0 = kill every root process),
    # and userdel needs -f because it sees the kept user's processes.
    shared_uid=0
    [[ "$uid" == 0 ]] && shared_uid=1
    for k in "${!KEEP[@]}"; do
        [[ "$(id -u "$k" 2>/dev/null)" == "$uid" ]] && { shared_uid=1; break; }
    done

    if [[ $KILL_PROCS -eq 1 ]]; then
        if [[ $shared_uid -eq 1 ]]; then
            info "Not killing processes for $user (UID $uid is shared with a kept account)"
        else
            pkill -KILL -u "$uid" 2>/dev/null && sleep 0.5
        fi
    fi

    remove_home=0
    if [[ -n "$home" && -d "$home" ]] && ! is_protected_path "$home" \
       && [[ "$(stat -c %u "$home" 2>/dev/null)" == "$uid" ]]; then
        remove_home=1
    fi

    # A home owned by a shared UID (e.g. root) isn't really this user's
    if [[ $shared_uid -eq 1 && "$home" != /home/* ]]; then
        remove_home=0
    fi

    args=()
    [[ $remove_home -eq 1 ]] && args+=(-r)
    [[ $shared_uid -eq 1 ]] && args+=(-f)
    userdel ${args[@]+"${args[@]}"} "$user"
    rc=$?
    # userdel exit 12 = account removed but home dir/mail spool couldn't be removed
    if [[ $rc -eq 0 || $rc -eq 12 ]]; then
        info "Deleted $user$([[ $remove_home -eq 1 ]] && echo " (home $home removed)" || echo " (home kept: ${home:-none})")"
        ((deleted++))
    else
        echo "[!] Failed to delete $user (userdel exit $rc)" >&2
        ((failed++))
    fi
done

info "Done. Deleted: $deleted  Failed: $failed"
[[ $failed -eq 0 ]]
