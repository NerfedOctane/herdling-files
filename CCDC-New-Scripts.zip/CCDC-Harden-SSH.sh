#!/usr/bin/env bash

if [ -z "${BASH_VERSION:-}" ]; then
  echo "Run this with bash: sudo bash $0" >&2
  exit 1
fi

if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root. Try: sudo bash $0" >&2
  exit 1
fi

set -uo pipefail
shopt -s nullglob

ASSUME_YES=false
KEEP_SFTP=false
SET_IMMUTABLE=true

SCRIPT_NAME=harden-ssh.sh
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_ROOT=/root/ssh-hardening-backups
BUTTERFARM=/root/butterfarm

usage() {
  cat <<EOF
Usage: sudo bash $SCRIPT_NAME [options]

  -y, --yes              Don't ask for confirmation
      --keep-sftp        Keep the SFTP subsystem (scp from OpenSSH 9+ clients
                         needs it; 'scp -O' works without it)
      --no-immutable     Don't chattr +i sshd_config and /etc/shadow
  -h, --help             Show this help
EOF
}

while (( $# )); do
  case $1 in
    -y|--yes)           ASSUME_YES=true ;;
    --keep-sftp)        KEEP_SFTP=true ;;
    --no-immutable)     SET_IMMUTABLE=false ;;
    -h|--help)          usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

BACKUP_DIR="" LOG="" WORK_DIR=""
DISTRO_FAMILY="" DISTRO_NAME="" SVC="" INIT="" STARTUP_FILE="" ADMIN_GROUPS=""
SSHD_BIN="" SSH_BIN="" SSH_VER=""
PORTS_BEFORE="" PORTS_AFTER="" CONFIG_TEST_OUTPUT=""
KEEP_LINES=() FINDINGS=() WARNINGS=() SYSTEMD_QUARANTINED=() ADMINS=()

if [[ -t 1 ]]; then
  C_RED=$'\e[1;31m' C_GRN=$'\e[1;32m' C_YEL=$'\e[1;33m' C_BLU=$'\e[1;34m'
  C_MAG=$'\e[1;35m' C_BLD=$'\e[1m' C_RST=$'\e[0m'
else
  C_RED="" C_GRN="" C_YEL="" C_BLU="" C_MAG="" C_BLD="" C_RST=""
fi

_log() {
  local color=$1 tag=$2; shift 2
  printf '%s[%s]%s %s\n' "$color" "$tag" "$C_RST" "$*"
  if [[ -n $LOG ]]; then printf '[%s] %s\n' "$tag" "$*" >>"$LOG"; fi
}
info()    { _log "$C_BLU" "INFO" "$@"; }
ok()      { _log "$C_GRN" " OK " "$@"; }
warn()    { _log "$C_YEL" "WARN" "$@"; WARNINGS+=("$*"); }
finding() { _log "$C_MAG" "FLAG" "$@"; FINDINGS+=("$*"); }
die()     { _log "$C_RED" "FAIL" "$@"; exit 1; }

step() {
  printf '\n%s==> %s%s\n' "$C_BLD" "$*" "$C_RST"
  if [[ -n $LOG ]]; then printf '\n==> %s\n' "$*" >>"$LOG"; fi
}

show() {
  [[ -n ${1:-} ]] || return 0
  printf '%s\n' "$1" | sed 's/^/        /'
  if [[ -n $LOG ]]; then printf '%s\n' "$1" | sed 's/^/        /' >>"$LOG"; fi
}

ask() {
  local reply=""
  if [[ -t 0 ]]; then
    read -r -p "$1 [y/N] " reply
  elif { exec 3</dev/tty; } 2>/dev/null; then
    read -r -u 3 -p "$1 [y/N] " reply
    exec 3<&-
  else
    die "No terminal to confirm on. Re-run with --yes."
  fi
  [[ $reply =~ ^[Yy]([Ee][Ss])?$ ]]
}

have() { command -v "$1" >/dev/null 2>&1; }

unlock() {
  have chattr || return 0
  local p
  for p in "$@"; do
    if [[ -d $p && ! -L $p ]]; then chattr -R -ia "$p" 2>/dev/null
    elif [[ -e $p && ! -L $p ]]; then chattr -ia "$p" 2>/dev/null
    fi
  done
  return 0
}

relabel() {
  have restorecon || return 0
  restorecon -F "$@" 2>/dev/null
  return 0
}

backup() {
  local p=$1
  grep -qxE "[RN] $(printf '%s' "$p" | sed 's/[]\/$*.^[]/\\&/g')" "$BACKUP_DIR/manifest" 2>/dev/null && return 0
  if [[ -e $p || -L $p ]]; then
    if cp -a --parents -- "$p" "$BACKUP_DIR/files/" 2>/dev/null; then
      echo "R $p" >>"$BACKUP_DIR/manifest"
    else
      warn "Could not back up $p"
      return 1
    fi
  else
    echo "N $p" >>"$BACKUP_DIR/manifest"
  fi
}

quarantine() {
  local p=$1
  [[ -e $p || -L $p ]] || return 1
  unlock "$p"
  if ! cp -a --parents -- "$p" "$BACKUP_DIR/quarantine/" 2>/dev/null; then
    warn "Could not copy $p to quarantine, leaving it in place"
    return 1
  fi
  rm -rf -- "$p" || { warn "Could not remove $p"; return 1; }
}

install_file() {
  local src=$1 dest=$2 mode=$3
  unlock "$dest"
  backup "$dest" || return 1
  [[ -L $dest ]] && rm -f -- "$dest"
  cp -- "$src" "$dest" || return 1
  chown root:root "$dest"
  chmod "$mode" "$dest"
  relabel "$dest"
}

restore_manifest() {
  local kind path
  while read -r kind path; do
    [[ -n ${path:-} ]] || continue
    unlock "$path"
    rm -rf -- "$path"
    [[ $kind == R ]] && cp -a -- "$BACKUP_DIR/files$path" "$path"
  done < <(tac "$BACKUP_DIR/manifest")
  : >"$BACKUP_DIR/manifest"
  relabel -R /etc/ssh
}

osr() { sed -n "s/^$1=//p" /etc/os-release 2>/dev/null | tr -d '"' | head -n1; }

detect_platform() {
  local id like
  id=$(osr ID) like=$(osr ID_LIKE)
  DISTRO_NAME=$(osr PRETTY_NAME)
  case " $id $like " in
    *" debian "*|*" ubuntu "*)            DISTRO_FAMILY=debian ;;
    *" rhel "*|*" fedora "*|*" centos "*) DISTRO_FAMILY=rhel ;;
  esac
  if [[ -z $DISTRO_FAMILY ]]; then
    if [[ -f /etc/debian_version ]]; then DISTRO_FAMILY=debian
    elif [[ -f /etc/redhat-release ]]; then DISTRO_FAMILY=rhel
    fi
  fi
  [[ -n $DISTRO_FAMILY ]] || die "Not a Debian- or Red Hat-family system; nothing changed."
  [[ -n $DISTRO_NAME ]] || DISTRO_NAME=$(head -n1 /etc/redhat-release /etc/debian_version 2>/dev/null | tail -n1)

  if [[ $DISTRO_FAMILY == debian ]]; then
    SVC=ssh  STARTUP_FILE=/etc/default/ssh    ADMIN_GROUPS="sudo admin wheel"
  else
    SVC=sshd STARTUP_FILE=/etc/sysconfig/sshd ADMIN_GROUPS="wheel sudo"
  fi

  SSHD_BIN=$(command -v sshd 2>/dev/null || true)
  [[ -z $SSHD_BIN && -x /usr/sbin/sshd ]] && SSHD_BIN=/usr/sbin/sshd
  if [[ -z $SSHD_BIN ]]; then
    if [[ $DISTRO_FAMILY == debian ]]; then die "sshd isn't installed. Install it first: apt-get install openssh-server"
    else die "sshd isn't installed. Install it first: dnf install openssh-server"; fi
  fi
  SSH_BIN=$(command -v ssh 2>/dev/null || echo /usr/bin/ssh)
  SSH_VER=$("$SSH_BIN" -V 2>&1 | grep -oE 'OpenSSH_[0-9]+\.[0-9]+' | head -n1)
  SSH_VER=${SSH_VER#OpenSSH_}

  if have systemctl && [[ -d /run/systemd/system ]]; then
    INIT=systemd
    if ! unit_exists "$SVC.service"; then
      local alt
      for alt in ssh sshd; do unit_exists "$alt.service" && { SVC=$alt; break; }; done
    fi
  else
    INIT=sysv
  fi

  info "Distro:  $DISTRO_NAME ($DISTRO_FAMILY family)"
  info "OpenSSH: ${SSH_VER:-unknown}, service '$SVC' ($INIT)"
}

unit_exists() {
  local out
  out=$(systemctl list-unit-files "$1" 2>/dev/null)
  [[ $out == *"$1"* ]]
}

ssh_version_at_least() {
  local maj=${SSH_VER%%.*} min=${SSH_VER#*.}
  [[ $maj =~ ^[0-9]+$ && $min =~ ^[0-9]+$ ]] || return 1
  (( maj > $1 || (maj == $1 && min >= $2) ))
}

check_access() {
  step "Pre-flight: making sure you won't be locked out"
  local uid_min=1000 v user uid shell hash groups g sudo_out is_admin others=()
  if [[ -r /etc/login.defs ]]; then
    v=$(awk '$1=="UID_MIN"{print $2}' /etc/login.defs)
    [[ $v =~ ^[0-9]+$ ]] && uid_min=$v
  fi

  while IFS=: read -r user _ uid _ _ _ shell; do
    [[ $uid =~ ^[0-9]+$ ]] || continue
    (( uid >= uid_min && uid < 65534 )) || continue
    case $shell in */nologin|*/false|*/sync|"") continue ;; esac
    hash=$(awk -F: -v u="$user" '$1==u{print $2; exit}' /etc/shadow 2>/dev/null)
    [[ -n $hash && ${hash:0:1} != '!' && ${hash:0:1} != '*' ]] || continue

    is_admin=false
    if have sudo; then
      if have timeout; then sudo_out=$(timeout 5 sudo -n -l -U "$user" 2>/dev/null)
      else sudo_out=$(sudo -n -l -U "$user" 2>/dev/null); fi
      [[ $sudo_out == *"may run the following"* ]] && is_admin=true
    fi
    groups=" $(id -nG "$user" 2>/dev/null) "
    for g in $ADMIN_GROUPS; do [[ $groups == *" $g "* ]] && is_admin=true; done
    if $is_admin; then ADMINS+=("$user"); else others+=("$user"); fi
  done < <(getent passwd)

  if (( ${#ADMINS[@]} )); then
    ok "Accounts that can still SSH in and get root via sudo: ${ADMINS[*]}"
  elif (( ${#others[@]} )); then
    warn "No sudo-capable account has a password. These can SSH in but need 'su' and the root password: ${others[*]}"
  else
    warn "No non-root account has a password and a login shell. Once root login is off, NOBODY can SSH in. Make one first (useradd -m -G ${ADMIN_GROUPS%% *} NAME && passwd NAME) unless you have console access."
  fi

  if [[ -n ${SSH_CONNECTION:-} && -z ${SUDO_USER:-} ]]; then
    warn "You're logged in directly as root over SSH. This session stays open, but new root SSH logins will be refused."
  fi
}

confirm_plan() {
  local lock_note=""
  $SET_IMMUTABLE || lock_note=" (skipped, --no-immutable)"
  step "Plan"
  cat <<EOF
  On this host this will:
    - turn off root SSH login and SSH key login (passwords only)
    - replace sshd_config, remove /etc/ssh/sshd_config.d, restart $SVC
    - replace /etc/ssh/ssh_config with the hardened client config
    - remove nullok from PAM
    - quarantine authorized_keys, ~/.ssh/rc, /etc/ssh/sshrc and nologin files
    - chattr +i sshd_config and /etc/shadow$lock_note
    - save locked copies of sshd_config and ssh_config to $BUTTERFARM
  Everything it changes is backed up first, with a restore.sh to undo it.
EOF
  $ASSUME_YES && return 0
  ask "Continue?" || die "Aborted. Nothing was changed."
}

setup_backup() {
  step "Backup"
  BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"
  mkdir -p "$BACKUP_DIR"/files "$BACKUP_DIR"/quarantine "$BACKUP_DIR"/snapshot \
    || die "Can't create $BACKUP_DIR"
  WORK_DIR=$(mktemp -d /etc/ssh/.harden-ssh.XXXXXX) || die "Can't create a work dir in /etc/ssh"
  trap 'rm -rf -- "$WORK_DIR"' EXIT
  chmod 700 "$BACKUP_ROOT" "$BACKUP_DIR"
  : >"$BACKUP_DIR/manifest"
  LOG="$BACKUP_DIR/harden-ssh.log"

  local p
  for p in /etc/ssh /etc/pam.d "$STARTUP_FILE"; do
    [[ -e $p ]] && cp -a --parents -- "$p" "$BACKUP_DIR/snapshot/" 2>/dev/null
  done
  write_restore_script
  ok "Backups, log and restore.sh: $BACKUP_DIR"
}

write_restore_script() {
  {
    echo '#!/usr/bin/env bash'
    echo "SSHD_BIN='$SSHD_BIN'"
    echo "SVC='$SVC'"
    cat <<'EOF'
set -u
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }
DIR=$(cd "$(dirname "$0")" && pwd)
command -v chattr >/dev/null && chattr -ia /etc/ssh/sshd_config /etc/shadow 2>/dev/null

if [[ -s $DIR/authselect-undo ]] && command -v authselect >/dev/null; then
  while read -r args; do
    [[ -n $args ]] && authselect $args >/dev/null && echo "authselect $args"
  done <"$DIR/authselect-undo"
fi

tac "$DIR/manifest" | while read -r kind path; do
  [[ -n ${path:-} ]] || continue
  command -v chattr >/dev/null && chattr -R -ia "$path" 2>/dev/null
  rm -rf -- "$path"
  if [[ $kind == R ]]; then
    cp -a -- "$DIR/files$path" "$path" && echo "restored $path"
  else
    echo "removed  $path (it didn't exist before)"
  fi
done

command -v restorecon >/dev/null && restorecon -RF /etc/ssh /etc/pam.d 2>/dev/null
command -v systemctl >/dev/null && systemctl daemon-reload 2>/dev/null
[[ -f /etc/debian_version ]] && mkdir -p /run/sshd

if "$SSHD_BIN" -t; then
  if command -v systemctl >/dev/null && [[ -d /run/systemd/system ]]; then
    systemctl restart "$SVC"
  else
    service "$SVC" restart
  fi && echo "sshd restarted on the original config."
else
  echo "sshd -t fails on the restored config. Fix it before restarting sshd." >&2
  exit 1
fi
EOF
  } >"$BACKUP_DIR/restore.sh"
  chmod 700 "$BACKUP_DIR/restore.sh"
}

config_test() {
  local kind=$1 f=$2 out
  if [[ $kind == server ]]; then
    "$SSHD_BIN" -t -f "$f" 2>&1
  elif ssh_version_at_least 6 8; then
    "$SSH_BIN" -F "$f" -G localhost 2>&1 >/dev/null
  else
    out=$("$SSH_BIN" -F "$f" -o BatchMode=yes -o ConnectTimeout=2 -p 1 127.0.0.1 true 2>&1 >/dev/null)
    printf '%s\n' "$out"
    [[ ! $out =~ line\ [0-9]+ ]]
  fi
}

make_compatible() {
  local kind=$1 f=$2 out rc n directive i
  local protected='^(permitrootlogin|passwordauthentication|permitemptypasswords|usepam|port|listenaddress)$'
  for (( i = 0; i < 15; i++ )); do
    out=$(config_test "$kind" "$f"); rc=$?

    n=$(grep -F -- "$f" <<<"$out" | grep -oE 'line [0-9]+' | head -n1 | grep -oE '[0-9]+')
    if [[ -z $n && $out == *"AuthorizedKeysCommand set without"* ]]; then
      n=$(grep -niE '^[[:space:]]*authorizedkeyscommand[[:space:]]' "$f" | head -n1 | cut -d: -f1)
    fi
    if [[ -z $n ]]; then
      CONFIG_TEST_OUTPUT=$out
      (( rc == 0 ))
      return
    fi

    directive=$(sed -n "${n}p" "$f" | awk '{print $1}')
    if [[ -z $directive || $directive == \#* || ${directive,,} =~ $protected ]]; then
      CONFIG_TEST_OUTPUT=$out
      return 1
    fi
    sed -i "${n}s/^/# not supported by this OpenSSH: /" "$f"
    warn "This OpenSSH doesn't support '$directive' in the $kind config; commented it out"
    if [[ ${directive,,} == disableforwarding ]]; then
      printf '%s\n' "" \
        "AllowTcpForwarding no" "AllowAgentForwarding no" "AllowStreamLocalForwarding no" \
        "X11Forwarding no" "GatewayPorts no" >>"$f"
    fi
  done
  CONFIG_TEST_OUTPUT=$out
  return 1
}

effective_ports() {
  "$SSHD_BIN" -T 2>/dev/null | awk '$1=="port"{print $2}' | sort -un | paste -sd, -
}

audit_sshd_file() {
  local f=$1 hits
  hits=$(
    {
      grep -inE '^[[:space:]]*(match|forcecommand|authorizedkeyscommand|authorizedprincipals(file|command)|trustedusercakeys|permitemptypasswords[[:space:]]+yes|permitrootlogin[[:space:]]+yes|permituserenvironment[[:space:]]+yes|permittunnel[[:space:]]+(yes|point-to-point|ethernet)|gatewayports[[:space:]]+(yes|clientspecified)|hostbasedauthentication[[:space:]]+yes|ignorerhosts[[:space:]]+no|strictmodes[[:space:]]+no)([[:space:]]|$)' "$f"
      grep -inE '^[[:space:]]*include[[:space:]]' "$f" \
        | grep -viE 'include[[:space:]]+/etc/ssh/sshd_config\.d/\*\.conf[[:space:]]*$'
      grep -inE '^[[:space:]]*authorizedkeysfile[[:space:]]' "$f" \
        | grep -viE 'authorizedkeysfile([[:space:]]+(%h/)?\.ssh/authorized_keys2?)+[[:space:]]*$|authorizedkeysfile[[:space:]]+none[[:space:]]*$'
    } 2>/dev/null | grep -viE 'authorizedkeyscommand[[:space:]]+none[[:space:]]*$' | sort -t: -k1,1n -u
  )
  if [[ -n $hits ]]; then
    finding "$f had settings worth a look (none of them survive in the new config):"
    show "$hits"
  fi
}

fix_hostkeys() {
  local keys=(/etc/ssh/ssh_host_*_key) k perm owner group
  if (( ${#keys[@]} == 0 )); then
    finding "No SSH host keys found (sshd can't start without them); generating new ones"
    ssh-keygen -A >/dev/null 2>&1 || warn "ssh-keygen -A failed"
    relabel -R /etc/ssh
    keys=(/etc/ssh/ssh_host_*_key)
    (( ${#keys[@]} )) || { warn "Still no host keys; sshd won't start until you run: ssh-keygen -A"; return 0; }
  fi
  for k in "${keys[@]}"; do
    read -r perm owner group < <(stat -c '%a %U %G' "$k")
    if [[ $owner != root ]] || (( 8#$perm & 8#027 )) \
       || { (( 8#$perm & 8#040 )) && [[ $group != root && $group != ssh_keys ]]; }; then
      finding "Host key $k had loose permissions ($perm $owner:$group); set to 600 root:root"
      unlock "$k"
      chown root:root "$k"
      chmod 600 "$k"
    fi
    [[ -f $k.pub ]] && { chown root:root "$k.pub"; chmod 644 "$k.pub"; }
  done
  ok "Host keys checked (${#keys[@]} found)"
}

build_sshd_config() {
  local out=$1
  {
    if (( ${#KEEP_LINES[@]} )); then
      printf '%s\n' "${KEEP_LINES[@]}"
      echo
    fi
    if [[ $DISTRO_FAMILY == rhel ]]; then
      echo "SyslogFacility AUTHPRIV"
      echo
    fi
    cat <<'EOF'
PermitRootLogin no

PasswordAuthentication yes
AuthenticationMethods password
PubkeyAuthentication no
AuthorizedKeysFile none
AuthorizedKeysCommand none
GSSAPIAuthentication no
HostbasedAuthentication no
IgnoreRhosts yes
PermitEmptyPasswords no
UsePAM yes

MaxAuthTries 3
LoginGraceTime 30

DisableForwarding yes
PermitTunnel no
PermitUserEnvironment no
PermitUserRC no
EOF
    if $KEEP_SFTP; then
      echo
      echo "Subsystem sftp internal-sftp"
    fi
  } >"$out"
}

remove_dropins() {
  local d=/etc/ssh/sshd_config.d f name
  local stock='^(50-redhat|50-cloud-init|60-cloudimg-settings|40-redhat-crypto-policies)\.conf$'
  if [[ ! -e $d && ! -L $d ]]; then
    ok "No sshd_config.d drop-in directory"
    return 0
  fi
  for f in "$d"/* "$d"/.[!.]*; do
    name=${f##*/}
    if [[ $name =~ $stock ]]; then info "Drop-in $name is a distro default"
    else finding "Drop-in $f is not a distro default"; fi
    [[ -f $f ]] && audit_sshd_file "$f"
  done
  unlock "$d"
  backup "$d" || return 1
  if rm -rf -- "$d"; then
    ok "Removed $d (nothing includes it any more)"
  else
    warn "Could not remove $d. The new sshd_config doesn't include it, so it's ignored anyway."
  fi
}

sanitize_startup_options() {
  local f=$STARTUP_FILE hits n
  if [[ ! -f $f ]]; then
    ok "No $f"
    return 0
  fi
  hits=$(grep -nE '^[[:space:]]*(export[[:space:]]+)?(SSHD_OPTS|OPTIONS|CRYPTO_POLICY)=' "$f" \
         | grep -vE "=[[:space:]]*(\"\"|'')?[[:space:]]*$" \
         | grep -vE "=[\"']?-u0[\"']?[[:space:]]*$")
  if [[ -z $hits ]]; then
    ok "$f passes no extra options to sshd"
    return 0
  fi
  finding "$f passes extra options to sshd at startup (these override sshd_config):"
  show "$hits"
  unlock "$f"
  backup "$f" || return 1
  for n in $(cut -d: -f1 <<<"$hits"); do
    sed -i "${n}s/^/# disabled by $SCRIPT_NAME: /" "$f"
  done
  relabel "$f"
  ok "Commented those lines out"
}

check_service_overrides() {
  [[ $INIT == systemd ]] || return 0
  local unit="$SVC.service" frag dropins p exec_line
  frag=$(systemctl show -p FragmentPath "$unit" 2>/dev/null | cut -d= -f2-)
  dropins=$(systemctl show -p DropInPaths "$unit" 2>/dev/null | cut -d= -f2-)

  if [[ $frag == /etc/systemd/* || $frag == /run/systemd/system/* ]]; then
    case $(readlink -f "$frag") in
      /lib/systemd/*|/usr/lib/systemd/*|/dev/null) ;;
      *)
        finding "$unit is replaced by a custom unit file $frag:"
        show "$(grep -E '^[[:space:]]*(ExecStart|Environment)' "$frag")"
        quarantine "$frag" && SYSTEMD_QUARANTINED+=("$frag") ;;
    esac
  fi

  for p in $dropins; do
    case $p in
      /etc/systemd/*|/run/systemd/system/*)
        finding "Drop-in override for $unit: $p"
        show "$(grep -vE '^[[:space:]]*(#|$)' "$p")"
        quarantine "$p" && SYSTEMD_QUARANTINED+=("$p") ;;
      *) info "Vendor drop-in for $unit left alone: $p" ;;
    esac
  done
  systemctl daemon-reload

  exec_line=$(systemctl show -p ExecStart "$unit" 2>/dev/null | grep -oE 'argv\[\]=[^;]*')
  if [[ $exec_line =~ [[:space:]]-(f|o|p) ]]; then
    finding "ExecStart for $unit passes -f/-o/-p to sshd: ${exec_line#argv[]=}. Check the unit with: systemctl cat $unit"
  else
    ok "No systemd overrides changing how sshd starts"
  fi
}

service_status() {
  if [[ $INIT == systemd ]]; then
    systemctl status --no-pager -l -n 15 "$SVC.service" 2>&1 | tail -n 15
  else
    service "$SVC" status 2>&1 | tail -n 15
  fi
}

proc_args() { { tr '\0' ' ' <"/proc/$1/cmdline"; } 2>/dev/null; }

sshd_listeners() {
  local pid args
  for pid in $(pgrep -x sshd 2>/dev/null); do
    args=$(proc_args "$pid")
    [[ -n $args ]] || continue
    if [[ $args == *"[listener]"* || $args != "sshd: "* ]]; then echo "$pid"; fi
  done
}

svc_ctl() {
  if [[ $INIT == systemd ]]; then
    systemctl "$1" "$SVC.service" >/dev/null 2>&1
  else
    service "$SVC" "$1" >/dev/null 2>&1 || "/etc/init.d/$SVC" "$1" >/dev/null 2>&1
  fi
}

restart_sshd() {
  local old pid args new=""
  if [[ $INIT == systemd ]]; then
    systemctl daemon-reload
    if [[ $(systemctl is-enabled "$SVC.service" 2>/dev/null) == masked ]]; then
      finding "$SVC.service was masked (can't start); unmasked it"
      systemctl unmask "$SVC.service" >/dev/null 2>&1
    fi
    if [[ $(systemctl is-enabled ssh.socket 2>/dev/null) != enabled \
       && $(systemctl is-enabled "$SVC.service" 2>/dev/null) != enabled ]]; then
      finding "$SVC.service wasn't enabled at boot; enabled it"
      systemctl enable "$SVC.service" >/dev/null 2>&1
    fi
  fi

  old=" $(sshd_listeners | paste -sd' ' -) "
  svc_ctl stop
  sleep 1
  for pid in $(sshd_listeners); do
    [[ $old == *" $pid "* ]] || continue
    args=$(proc_args "$pid")
    [[ -n $args ]] || continue
    finding "sshd PID $pid wasn't controlled by the $SVC service; killed it ($args)"
    kill "$pid" 2>/dev/null
    sleep 1
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
  done

  svc_ctl start || return 1
  sleep 1
  [[ $INIT == systemd ]] && { systemctl is-active --quiet "$SVC.service" || return 1; }
  for pid in $(sshd_listeners); do
    [[ $old == *" $pid "* ]] || new=$pid
  done
  [[ -n $new ]]
}

rollback_sshd() {
  warn "Rolling back the sshd changes"
  restore_manifest
  local p
  for p in ${SYSTEMD_QUARANTINED[@]+"${SYSTEMD_QUARANTINED[@]}"}; do
    cp -a -- "$BACKUP_DIR/quarantine$p" "$p"
  done
  [[ $INIT == systemd ]] && systemctl daemon-reload
  if "$SSHD_BIN" -t >/dev/null 2>&1 && restart_sshd; then
    ok "sshd is running on the original config again"
  else
    warn "sshd still isn't healthy after rollback. Check: $SSHD_BIN -t"
  fi
}

verify_effective() {
  local eff line key want got bad=0
  eff=$("$SSHD_BIN" -T 2>/dev/null) || { warn "sshd -T failed; couldn't double-check the live settings"; return; }
  info "Live settings according to sshd -T:"
  for line in "permitrootlogin no" "passwordauthentication yes" "authenticationmethods password" \
              "pubkeyauthentication no" "authorizedkeysfile none" "authorizedkeyscommand none" \
              "gssapiauthentication no" "hostbasedauthentication no" "ignorerhosts yes" \
              "permitemptypasswords no" "usepam yes" "maxauthtries 3" "logingracetime 30" \
              "disableforwarding yes" "permittunnel no" "permituserenvironment no" "permituserrc no"; do
    key=${line%% *} want=${line#* }
    got=$(awk -v k="$key" '$1==k { $1=""; sub(/^ +/, ""); print; exit }' <<<"$eff")
    if [[ -z $got ]]; then
      show "$(printf '%-24s %s' "$key" "(not reported by this OpenSSH)")"
    elif [[ ${got,,} == "$want" ]]; then
      show "$(printf '%-24s %s' "$key" "$got")"
    else
      show "$(printf '%-24s %s   <-- expected %s' "$key" "$got" "$want")"
      bad=1
    fi
  done
  if (( bad )); then
    warn "Some live settings don't match the hardened config; something is overriding it"
  else
    ok "Live settings match the hardened config"
  fi
}

harden_sshd() {
  step "Inbound SSH: /etc/ssh/sshd_config"
  local cfg=/etc/ssh/sshd_config work="$WORK_DIR/sshd_config" line out

  [[ $DISTRO_FAMILY == debian ]] && { mkdir -p /run/sshd; chmod 755 /run/sshd; }
  PORTS_BEFORE=$(effective_ports)
  check_running_sshd "as found"

  if [[ -L $cfg ]]; then finding "$cfg was a symlink to $(readlink -f "$cfg"); it will be a real file again"; fi
  if [[ -f $cfg ]]; then audit_sshd_file "$cfg"; else finding "$cfg was missing"; fi

  KEEP_LINES=()
  if [[ -f $cfg ]]; then
    while IFS= read -r line; do KEEP_LINES+=("$line"); done < <(
      awk 'tolower($1)=="match"{exit} tolower($1)~/^(port|listenaddress|addressfamily)$/{print $1, $2}' "$cfg")
    (( ${#KEEP_LINES[@]} )) && info "Keeping from the old config: ${KEEP_LINES[*]}"
  fi

  fix_hostkeys

  build_sshd_config "$work"
  if ! make_compatible server "$work"; then
    warn "The hardened config fails 'sshd -t':"
    show "$CONFIG_TEST_OUTPUT"
    die "sshd config was not changed."
  fi
  ok "New config passes sshd -t"

  remove_dropins
  install_file "$work" "$cfg" 600 || { rollback_sshd; die "Couldn't write $cfg; rolled back."; }
  ok "Wrote hardened $cfg"

  sanitize_startup_options
  check_service_overrides

  if ! out=$("$SSHD_BIN" -t 2>&1); then
    warn "sshd -t fails on the final config:"
    show "$out"
    rollback_sshd
    die "Rolled back. sshd was not restarted with the new config."
  fi
  show "$out"
  ok "sshd -t passed on the live config"

  if restart_sshd; then
    ok "$SVC restarted and running"
  else
    warn "$SVC didn't come back up with the new config:"
    show "$(service_status)"
    rollback_sshd
    die "Rolled back to the original sshd config."
  fi

  PORTS_AFTER=$(effective_ports)
  if [[ -n $PORTS_BEFORE && $PORTS_BEFORE != "$PORTS_AFTER" ]]; then
    warn "sshd port changed from $PORTS_BEFORE to $PORTS_AFTER (the old port came from a drop-in or startup option). Check the firewall and scoring."
  fi
  verify_effective
}

build_ssh_config() {
  local out=$1
  {
    if [[ $DISTRO_FAMILY == rhel && -f /etc/crypto-policies/back-ends/openssh.config ]]; then
      echo "Include /etc/crypto-policies/back-ends/openssh.config"
      echo
    fi
    cat <<'EOF'
Host *
    StrictHostKeyChecking ask
    UserKnownHostsFile ~/.ssh/known_hosts
    HashKnownHosts yes
    ForwardAgent no
    ForwardX11 no
    ForwardX11Trusted no
    ClearAllForwardings yes
    Tunnel no
    PermitLocalCommand no
    ProxyCommand none
    ProxyJump none
    ControlMaster no
    ControlPath none
    GSSAPIAuthentication no
    HostbasedAuthentication no
EOF
  } >"$out"
}

harden_ssh_client() {
  step "Outbound SSH: /etc/ssh/ssh_config"
  local work="$WORK_DIR/ssh_config"
  build_ssh_config "$work"
  if ! make_compatible client "$work"; then
    warn "The hardened ssh_config doesn't parse on this OpenSSH; left the old one in place:"
    show "$CONFIG_TEST_OUTPUT"
    return 0
  fi
  if install_file "$work" /etc/ssh/ssh_config 644; then
    ok "Wrote hardened /etc/ssh/ssh_config ($DISTRO_FAMILY layout; /etc/ssh/ssh_config.d is no longer read)"
  else
    warn "Couldn't write /etc/ssh/ssh_config"
  fi
}

NULLOK_RE='^[^#]*[[:space:]]nullok'

strip_nullok() {
  local f
  f=$(readlink -f "$1")
  unlock "$f"
  backup "$f" || return 1
  sed -i -E 's/[[:space:]]nullok(_secure)?([[:space:]]|$)/\2/' "$f"
  relabel "$f"
  ! grep -qE "$NULLOK_RE" "$f"
}

fix_nullok_rhel() {
  local cur f
  if have authselect; then
    cur=$(authselect current 2>&1)
    info "authselect current:"
    show "$cur"
    if [[ $cur == *"No existing configuration"* || $cur == *"no existing configuration"* ]]; then
      info "authselect isn't managing PAM here; editing the files directly"
    else
      if grep -qxE -- '- with-nullok' <<<"$cur"; then
        finding "authselect feature with-nullok was turned on"
        authselect disable-feature with-nullok >/dev/null 2>&1 \
          && echo "enable-feature with-nullok" >>"$BACKUP_DIR/authselect-undo"
      fi
      if grep -qxE -- '- without-nullok' <<<"$cur"; then
        ok "authselect feature without-nullok is already on"
      elif authselect enable-feature without-nullok >/dev/null 2>&1; then
        echo "disable-feature without-nullok" >>"$BACKUP_DIR/authselect-undo"
        ok "authselect enable-feature without-nullok"
      else
        warn "authselect enable-feature without-nullok failed (PAM files may have been hand-edited); editing them directly"
      fi
      info "authselect check:"
      show "$(authselect check 2>&1)"
    fi
  fi
  for f in /etc/pam.d/system-auth /etc/pam.d/password-auth; do
    [[ -e $f ]] || continue
    if grep -qE "$NULLOK_RE" "$f"; then
      if strip_nullok "$f"; then ok "Removed nullok from $f by hand"; else warn "nullok still in $f"; fi
    fi
  done
}

fix_nullok() {
  step "PAM: removing nullok"
  local f left
  if [[ $DISTRO_FAMILY == debian ]]; then
    f=/etc/pam.d/common-auth
    if [[ -e $f ]] && grep -qE "$NULLOK_RE" "$f"; then
      if strip_nullok "$f"; then ok "Removed nullok from $f"; else warn "nullok still in $f"; fi
    else
      ok "$f has no nullok"
    fi
  else
    fix_nullok_rhel
  fi

  while IFS= read -r f; do
    [[ -n $f ]] || continue
    finding "nullok was also in $f"
    strip_nullok "$f" || warn "Couldn't remove nullok from $f"
  done < <(grep -lE "$NULLOK_RE" /etc/pam.d/* 2>/dev/null)

  left=$(grep -nE "$NULLOK_RE" /etc/pam.d/* 2>/dev/null)
  if [[ -z $left ]]; then
    ok "No nullok left anywhere in /etc/pam.d"
  else
    warn "nullok is still present:"
    show "$left"
  fi
}

remove_persistence() {
  step "Removing SSH persistence and login blockers"
  local f home count found=false

  for f in /etc/nologin /run/nologin; do
    if [[ -e $f ]]; then
      quarantine "$f" && finding "Removed $f; it blocks every non-root login"
      found=true
    fi
  done

  if [[ -e /etc/ssh/sshrc ]]; then
    finding "/etc/ssh/sshrc runs for every SSH login (first lines below); quarantined"
    show "$(head -n 20 /etc/ssh/sshrc)"
    quarantine /etc/ssh/sshrc
    found=true
  fi

  while IFS= read -r home; do
    [[ -n $home && -d $home/.ssh ]] || continue
    for f in "$home/.ssh/authorized_keys" "$home/.ssh/authorized_keys2"; do
      [[ -e $f || -L $f ]] || continue
      count=$(grep -cvE '^[[:space:]]*(#|$)' "$f" 2>/dev/null)
      quarantine "$f" && finding "Quarantined $f (${count:-0} key(s)); key login is off anyway"
      found=true
    done
    f="$home/.ssh/rc"
    if [[ -e $f ]]; then
      finding "$f runs whenever that user logs in (first lines below); quarantined"
      show "$(head -n 20 "$f")"
      quarantine "$f"
      found=true
    fi
    if [[ -e $home/.ssh/environment ]]; then
      finding "$home/.ssh/environment exists (ignored now that PermitUserEnvironment is no)"
    fi
    if [[ -e $home/.ssh/config ]]; then
      info "$home/.ssh/config overrides the system ssh_config for that user; worth a look"
    fi
  done < <({ getent passwd | cut -d: -f6; echo /root; } | sort -u)

  $found || ok "No authorized_keys, rc scripts or nologin files found"
}

audit_packages() {
  local out bad fix
  if [[ $DISTRO_FAMILY == debian ]] && have dpkg; then
    out=$(dpkg -V openssh-server openssh-client openssh-sftp-server 2>&1)
    fix="apt-get install --reinstall openssh-server openssh-client"
  elif have rpm; then
    out=$(rpm -V openssh openssh-server openssh-clients 2>&1)
    fix="dnf reinstall openssh openssh-server openssh-clients  (yum on older releases)"
  else
    return 0
  fi
  bad=$(grep -vE '[[:space:]][cdglr][[:space:]]+/' <<<"$out" \
        | grep -E '[[:space:]]/(usr/)?(s?bin|lib|lib64|libexec)/')
  if [[ -n $bad ]]; then
    finding "OpenSSH package files were changed outside the package manager (possible trojaned binary):"
    show "$bad"
    info "Reinstall them from the repo with: $fix"
  else
    ok "sshd/ssh binaries and unit files match the installed packages"
  fi
}

check_running_sshd() {
  local when=${1:-now} pid args k keys bad listeners=()
  local crypto='^(ciphers|macs|kexalgorithms|gssapikexalgorithms|gssapikeyexchange|hostkeyalgorithms|pubkeyacceptedkeytypes|pubkeyacceptedalgorithms|casignaturealgorithms|hostbasedacceptedkeytypes|hostbasedacceptedalgorithms|requiredrsasize)$'
  for pid in $(sshd_listeners); do
    listeners+=("$pid")
    args=$(proc_args "$pid")
    bad=()
    [[ " $args " =~ [[:space:]]-f[[:space:]/] ]] && bad+=("-f (another config file)")
    [[ " $args " =~ [[:space:]]-p[[:space:]]?[0-9] ]] && bad+=("-p (extra port)")
    keys=$(grep -oE '(^|[[:space:]])-o[[:space:]]?[A-Za-z]+' <<<"$args" | sed -E 's/.*-o[[:space:]]?//')
    for k in $keys; do [[ ${k,,} =~ $crypto ]] || bad+=("-o $k"); done
    if (( ${#bad[@]} )); then
      finding "sshd PID $pid ($when) runs with ${bad[*]}: $args"
    fi
  done
  if (( ${#listeners[@]} > 1 )); then
    finding "${#listeners[@]} sshd listeners running ($when), PIDs ${listeners[*]}; there should be one"
  elif (( ${#listeners[@]} == 1 )); then
    ok "One sshd listener running (PID ${listeners[0]})"
  elif [[ $when == "as found" ]]; then
    info "No sshd listener was running when the script started (stopped, or waiting on ssh.socket)"
  else
    warn "No sshd listener is running"
  fi
}

audit_listeners() {
  have ss || return 0
  local lines port extra=()
  lines=$(ss -tlnp 2>/dev/null | grep -E '"sshd')
  if [[ -z $lines ]]; then
    warn "No listening socket owned by sshd found"
    return 0
  fi
  info "sshd is listening on:"
  show "$(awk '{print $4}' <<<"$lines" | sort -u)"
  for port in $(awk '{n=split($4,a,":"); print a[n]}' <<<"$lines" | sort -un); do
    [[ ",$PORTS_AFTER," == *",$port,"* ]] || extra+=("$port")
  done
  if (( ${#extra[@]} )); then
    finding "sshd is listening on port(s) not in sshd_config: ${extra[*]} (rogue sshd or socket override?)"
  fi
}

audit_accounts() {
  local uid0 empty
  uid0=$(awk -F: '$3==0 && $1!="root"{print $1}' /etc/passwd | paste -sd' ' -)
  if [[ -n $uid0 ]]; then
    finding "Accounts with UID 0 besides root: $uid0 (root-equivalent; PermitRootLogin no blocks them over SSH too)"
  fi
  empty=$(awk -F: '$2==""{print $1}' /etc/shadow 2>/dev/null | paste -sd' ' -)
  if [[ -n $empty ]]; then
    finding "Accounts with an EMPTY password: $empty. Without nullok they can't log in, but set a password or lock them (passwd -l NAME)"
  else
    ok "No accounts with empty passwords"
  fi
}

show_sessions() {
  local who_out conns
  who_out=$(who 2>/dev/null)
  if have ss; then
    conns=$(ss -tnp state established 2>/dev/null | grep -E '"sshd' | awk '{print $4}' \
            | sed -E 's/:[0-9]+$//' | sort | uniq -c | sort -rn)
  fi
  info "Logged in right now (who):"
  show "${who_out:-(nobody)}"
  info "Open SSH connections by source address:"
  show "${conns:-(none)}"
  info "Anything you don't recognize may be red team. Kick a session: pkill -KILL -t pts/N"
}

audit_system() {
  step "Audit"
  audit_packages
  check_running_sshd
  audit_listeners
  audit_accounts
  show_sessions
}

save_butterfarm() {
  step "Saving copies of the SSH configs to $BUTTERFARM"
  local f dest
  if [[ -L $BUTTERFARM || ( -e $BUTTERFARM && ! -d $BUTTERFARM ) ]]; then
    finding "$BUTTERFARM was a symlink or a file, not a directory; replaced it"
    unlock "$BUTTERFARM"
    rm -f -- "$BUTTERFARM"
  fi
  mkdir -p "$BUTTERFARM" || { warn "Can't create $BUTTERFARM"; return 0; }
  unlock "$BUTTERFARM"
  chown root:root "$BUTTERFARM"
  chmod 700 "$BUTTERFARM"
  for f in /etc/ssh/sshd_config /etc/ssh/ssh_config; do
    dest="$BUTTERFARM/${f##*/}"
    if [[ ! -f $f ]]; then
      warn "$f doesn't exist; nothing to save"
      continue
    fi
    unlock "$dest"
    [[ -L $dest ]] && rm -f -- "$dest"
    if ! cp -- "$f" "$dest"; then
      warn "Couldn't copy $f to $dest"
      continue
    fi
    chown root:root "$dest"
    chmod 600 "$dest"
    if have chattr && chattr +i "$dest" 2>/dev/null; then
      ok "Saved $f to $dest (root:root 600, chattr +i)"
    else
      warn "Saved $f to $dest, but chattr +i failed (filesystem may not support it)"
    fi
  done
}

lock_files() {
  step "Locking files (chattr +i)"
  if ! $SET_IMMUTABLE; then
    info "Skipped (--no-immutable)"
    return 0
  fi
  have chattr || { warn "chattr isn't available"; return 0; }
  local f
  for f in /etc/ssh/sshd_config /etc/shadow; do
    if chattr +i "$f" 2>/dev/null; then ok "chattr +i $f"
    else warn "chattr +i $f failed (filesystem may not support it)"; fi
  done
}

summary() {
  step "Summary"
  local i login_as="a sudo user"
  (( ${#ADMINS[@]} )) && login_as=${ADMINS[*]}

  if (( ${#FINDINGS[@]} )); then
    printf '%s%d thing(s) found that may be red team activity:%s\n' "$C_MAG" "${#FINDINGS[@]}" "$C_RST"
    for i in "${FINDINGS[@]}"; do printf '  - %s\n' "${i%:}"; done
  else
    ok "Nothing suspicious found"
  fi
  if (( ${#WARNINGS[@]} )); then
    printf '\n%s%d warning(s):%s\n' "$C_YEL" "${#WARNINGS[@]}" "$C_RST"
    for i in "${WARNINGS[@]}"; do printf '  - %s\n' "${i%:}"; done
  fi

  cat <<EOF

${C_BLD}Remember${C_RST}
  - Root can't SSH in any more. Log in as $login_as and use sudo/su.
  - SSH keys are off; it's passwords only. Make sure scored users have strong ones.
EOF
  if $SET_IMMUTABLE; then
    cat <<EOF
  - /etc/shadow is immutable, so passwd will fail until you unlock it:
        chattr -i /etc/shadow ; passwd USER ; chattr +i /etc/shadow
  - sshd_config is immutable too. To edit it:
        chattr -i /etc/ssh/sshd_config ; (edit) ; sshd -t ; chattr +i /etc/ssh/sshd_config
EOF
  fi
  $KEEP_SFTP || echo "  - SFTP is off, so scp from OpenSSH 9+ clients fails. Use 'scp -O', or re-run with --keep-sftp."
  cat <<EOF
  - Hardened config copies:   $BUTTERFARM (immutable; chattr -i before replacing them)
  - Undo the config changes:  bash $BACKUP_DIR/restore.sh
  - Quarantined files:        $BACKUP_DIR/quarantine
  - Full log:                 $LOG
EOF
}

main() {
  detect_platform
  check_access
  confirm_plan
  setup_backup
  harden_sshd
  harden_ssh_client
  fix_nullok
  remove_persistence
  save_butterfarm
  audit_system
  lock_files
  summary
}

main
