#!/bin/bash

set -euo pipefail

filename="$1"
filepath=$(readlink -f "$filename")

# ---------------------------
# Pre-flight checks
# ---------------------------
if [[ $EUID -ne 0 ]]; then
    error "This script must be run as root (use sudo)."
fi

if [[ -z "${1:-}" ]]; then
    echo "Usage: sudo $0 <userlist.txt> userdelete-list.txt"
    echo "  userlist.txt — list of users to mass delete"
    exit 1
fi

USERLIST_INPUT="$1"
if [[ ! -f "$USERLIST_INPUT" ]]; then
    error "Userlist file not found: $USERLIST_INPUT"
fi

while read -r user; do
    # Skip empty lines
    [ -z "$user" ] && continue

    sudo userdel -r $user
done < "$filepath"
