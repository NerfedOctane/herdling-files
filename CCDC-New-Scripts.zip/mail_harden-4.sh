#!/usr/bin/env bash
# ==========================================================================================
# mail_harden.sh  -  CCDC mail box: fix the DEFAULT / MISCONFIGURED settings attackers abuse
# Category : Mail / Hardening   (--audit and --remote: Mail / Detection)
# Covers   : Dovecot (IMAP/POP3), Exim or Postfix (SMTP), RainLoop/SnappyMail webmail,
#            mailbox permissions, fail2ban, and the competition default password.
#            Known-CVE work lives in the companion script mail_cve.sh.
#
# Every run starts with STEP 0, the distro check: Debian/Ubuntu or RHEL-family continue,
# anything else (Arch, NixOS, FreeBSD...) exits before touching anything.
#
# Modes (pick one; default = harden):
#   (no mode)            HARDEN: backup -> Dovecot -> mailboxes -> Postfix/Exim -> webmail ->
#                        web server -> fail2ban -> new passwords. Each change is validated
#                        and reverted automatically if the validator rejects it.
#   --audit              READ-ONLY report of the same areas plus mail persistence (pipe
#                        aliases, .forward, sieve), rogue accounts and brute-force sources.
#   --remote HOST [URL]  From ANOTHER machine (no root needed): checks the box the way the
#                        scorer / red team see it. URL = webmail, e.g. http://HOST/rainloop
#   --passwords          Only change passwords (see password options below).
#   --rollback [DIR]     Undo one hardening run (no DIR = list backups, newest first).
#
# Harden options:
#   --scoring-ip IP[,IP]  extra IPs fail2ban must never ban (SECCDC infra always ignored)
#   --disable pop3|imap   turn off the protocol you are NOT scored on
#   --allow-plaintext     don't force TLS on IMAP/POP3 (only if the scorer needs 110/143 plain)
#   --lock-relay          only localhost may relay through Exim/Postfix (recommended)
#   --exim-tls-auth-only  Debian Exim: SMTP AUTH only after STARTTLS
#   --webmail-path DIR    RainLoop/SnappyMail folder (auto-detected otherwise)
#   --keep-admin          keep the webmail admin panel (moved to a random URL)
#   --force-tls           webmail -> IMAP/SMTP over STARTTLS even on this box
#   --no-webmail  --no-fail2ban  --no-install
#   --rotate | --rotate-every MIN | --no-rotate    password step at the end (default: ask)
# Password options (--passwords, or the end-of-harden prompt):
#   --one | --each        one password for all users | one per user (typed, hidden, twice)
#   --every MIN           ask again every MIN minutes (run inside tmux/screen)
#   --users a,b  --exclude x,y  --include-root  --from-file user:pass-file  --dry-run
#   --allow-domain        override the domain-joined stop (almost never correct)
#
# Safety  : never touches seccdc* (Black Team) accounts or the BTA agent; never bans
#           10.250.250.0/24 or 169.254.169.254; refuses password changes on domain-joined boxes.
# Usage   : sudo ./mail_harden.sh --audit | tee /root/audit-before.txt
#           sudo ./mail_harden.sh --lock-relay --exim-tls-auth-only
#           ./mail_harden.sh --remote 10.250.76.12 http://10.250.76.12/rainloop
#           sudo ./mail_harden.sh --rollback
# ==========================================================================================
set -u
MODE=harden; RB_DIR=""; RHOST=""; RURL=""
IGNORE=""; DISABLE=""; ALLOW_PLAIN=0; LOCK_RELAY=0; EXIM_TLS_AUTH=0; WMPATH=""; KEEP_ADMIN=0
FORCE_TLS=0; DO_WEB=1; F2B=1; INSTALL=1; ROTATE=0; ROTATE_EVERY=""; NO_ROTATE=0
PW_ONE=0; PW_EACH=0; PW_EVERY=0; PW_USERS=""; PW_EXCL=""; PW_ROOT=0; PW_FILE=""; PW_DRY=0; ALLOW_DOMAIN=0
INFRA="10.250.250.0/24 169.254.169.254"   # SECCDC scoring infra + BTA metadata: never ban
usage(){ awk 'NR>1 && /^#/{sub(/^# ?/,""); print; next} NR>1{exit}' "$0"; }
while [[ $# -gt 0 ]]; do
  case $1 in
    --audit) MODE=audit ;;
    --remote) MODE=remote; RHOST=${2:-}; shift; [[ ${2:-} == http* ]] && { RURL=$2; shift; } ;;
    --passwords) MODE=passwords ;;
    --rollback) MODE=rollback; [[ ${2:-} == /* ]] && { RB_DIR=$2; shift; } ;;
    --scoring-ip) IGNORE="${2//,/ }"; shift ;;
    --disable) DISABLE=${2:-}; shift ;;
    --allow-plaintext) ALLOW_PLAIN=1 ;;
    --lock-relay|--lock-mynetworks) LOCK_RELAY=1 ;;
    --exim-tls-auth-only) EXIM_TLS_AUTH=1 ;;
    --webmail-path) WMPATH=${2:-}; shift ;;
    --keep-admin) KEEP_ADMIN=1 ;;
    --force-tls) FORCE_TLS=1 ;;
    --no-webmail) DO_WEB=0 ;;
    --no-fail2ban) F2B=0 ;;
    --no-install) INSTALL=0 ;;
    --rotate) ROTATE=1 ;;
    --rotate-every) ROTATE=1; ROTATE_EVERY=${2:-}; shift ;;
    --no-rotate) NO_ROTATE=1 ;;
    --one) PW_ONE=1 ;;
    --each) PW_EACH=1 ;;
    --every) PW_EVERY=${2:-0}; shift ;;
    --users) PW_USERS="${2//,/ }"; shift ;;
    --exclude) PW_EXCL=" ${2//,/ } "; shift ;;
    --include-root) PW_ROOT=1 ;;
    --from-file) PW_FILE=${2:-}; shift ;;
    --dry-run) PW_DRY=1 ;;
    --allow-domain) ALLOW_DOMAIN=1 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1 (try --help)"; exit 1 ;;
  esac; shift
done
[[ -z $DISABLE || $DISABLE == pop3 || $DISABLE == imap ]] || { echo "--disable takes pop3 or imap"; exit 1; }
[[ $MODE == remote && -z $RHOST ]] && { echo "--remote needs a host: --remote 10.0.0.5 [http://10.0.0.5/rainloop]"; exit 1; }

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[1m'; N=$'\e[0m'
bad(){ echo "${R}[!]${N} $*"; }
ok(){ echo "${G}[+]${N} $*"; }
warn(){ echo "${Y}[*]${N} $*"; }
hdr(){ echo; echo "${B}== $* ==${N}"; }
svc(){ systemctl "$1" "$2" >/dev/null 2>&1 || service "$2" "$1" >/dev/null 2>&1; }

# ==========================================================================================
# STEP 0: DISTRO CHECK - runs before anything else, in every mode.
# /etc/os-release is PARSED (not sourced, so a tampered file can't run code as root).
#   ID / ID_LIKE contains debian|ubuntu        -> debian
#   ID / ID_LIKE contains rhel|fedora|centos   -> rhel
#   known IDs (kali, mint, rocky, alma, ol...) -> mapped; os-release missing -> marker files
#   anything else                              -> "unknown" -> exit 1, nothing changed
# The result sets the per-distro toolkit every later step uses instead of hard-coded names.
# ==========================================================================================
detect_distro(){
  DISTRO=unknown
  local f=${OSRELEASE:-/etc/os-release} id="" like=""
  if [[ -r $f ]]; then
    id=$(sed -n 's/^ID=//p' "$f" | tr -d "\"' " | head -n1)
    like=$(sed -n 's/^ID_LIKE=//p' "$f" | tr -d "\"'" | head -n1)
  fi
  if [[ -n $id$like ]]; then
    case " $id $like " in
      *" debian "*|*" ubuntu "*) DISTRO=debian ;;
      *" rhel "*|*" fedora "*|*" centos "*) DISTRO=rhel ;;
    esac
    [[ $DISTRO == unknown ]] && case $id in
      linuxmint|kali|raspbian|pop) DISTRO=debian ;;
      rocky|almalinux|ol|oracle|amzn|scientific) DISTRO=rhel ;;
    esac
  else
    [[ -f /etc/debian_version ]] && DISTRO=debian
    [[ -f /etc/redhat-release ]] && DISTRO=rhel
  fi
  case $DISTRO in
    debian) PKG=apt-get; WEBSVC=apache2; WEBUSER=www-data; MAILLOG=/var/log/mail.log; EXIMSVC=exim4 ;;
    rhel)   PKG=$(command -v dnf || command -v yum); PKG=${PKG##*/}; WEBSVC=httpd; WEBUSER=apache
            MAILLOG=/var/log/maillog; EXIMSVC=exim ;;
  esac
}
detect_distro
[[ $DISTRO == unknown ]] && { echo "[!] Unsupported distro - Debian/Ubuntu or RHEL-family only. Nothing was changed."; exit 1; }
echo "[*] Distro detected: $DISTRO  (pkg=$PKG, web=$WEBSVC/$WEBUSER, maillog=$MAILLOG)"

# ==========================================================================================
# REMOTE MODE - run from a teammate VM / jump box. Dovecot trusts connections from the
# mail server itself, so cleartext tests run ON the box give false "OK"s. No root needed.
# ==========================================================================================
remote_check(){
  local H=$RHOST r rcpt vrfy out old body ver adm loc p
  hdr "Remote check of $H${RURL:+ + $RURL}"
  rbad(){ echo "${R}[FAIL]${N} $*"; }; rok(){ echo "${G}[ OK ]${N} $*"; }; rinfo(){ echo "${Y}[info]${N} $*"; }
  port_open(){ timeout 3 bash -c 'exec 3<>/dev/tcp/$0/$1' "$H" "$1" 2>/dev/null; }
  if port_open 143; then
    r=$(timeout 8 bash -c 'exec 3<>/dev/tcp/$0/143 || exit 1; IFS= read -r -t3 l <&3; printf "%s\n" "$l"
        printf "a1 LOGIN ccdcprobe ccdcprobe\r\n" >&3
        while IFS= read -r -t3 l <&3; do printf "%s\n" "$l"; [[ $l == a1\ * ]] && break; done
        printf "a2 LOGOUT\r\n" >&3' "$H" 2>/dev/null)
    grep -qiE 'LOGINDISABLED|PRIVACYREQUIRED|disallowed' <<<"$r" && rok "IMAP 143 refuses cleartext login" \
      || rbad "IMAP 143 accepts cleartext LOGIN - passwords sniffable"
  else rinfo "143 closed"; fi
  if port_open 110; then
    r=$(timeout 8 bash -c 'exec 3<>/dev/tcp/$0/110 || exit 1; IFS= read -r -t3 l <&3
        printf "USER ccdcprobe\r\n" >&3; IFS= read -r -t3 l <&3; printf "%s\n" "$l"; printf "QUIT\r\n" >&3' "$H" 2>/dev/null)
    [[ $r == +OK* ]] && rbad "POP3 110 accepts cleartext USER - passwords sniffable" || rok "POP3 110 refuses cleartext auth"
  else rinfo "110 closed"; fi
  if command -v openssl >/dev/null; then
    for p in 993 995; do
      port_open "$p" || { rinfo "$p closed"; continue; }
      out=$(echo | timeout 6 openssl s_client -connect "$H:$p" 2>/dev/null)
      if grep -q 'Cipher is ' <<<"$out" && ! grep -q 'Cipher is (NONE)' <<<"$out"; then rok "$p TLS works"; else rbad "$p TLS handshake failed"; fi
      old=$(echo | timeout 6 openssl s_client -connect "$H:$p" -tls1_1 -cipher 'DEFAULT@SECLEVEL=0' 2>/dev/null)
      if grep -q 'Cipher is ' <<<"$old" && ! grep -q 'Cipher is (NONE)' <<<"$old"; then rbad "$p still accepts TLS 1.1"; else rok "$p rejects TLS 1.1"; fi
    done
  else rinfo "openssl missing - TLS checks skipped"; fi
  if port_open 25; then
    r=$(timeout 15 bash -c 'exec 3<>/dev/tcp/$0/25 || exit 1
        rd(){ while IFS= read -r -t5 l <&3; do printf "%s\n" "$l"; [[ $l =~ ^[0-9]{3}\  ]] && break; done; }
        rd; printf "EHLO probe.example\r\n" >&3; rd
        printf "MAIL FROM:<probe@example.com>\r\n" >&3; rd
        printf "RCPT TO:<probe@example.net>\r\n" >&3; echo "#RCPT"; rd
        printf "VRFY root\r\n" >&3; echo "#VRFY"; rd
        printf "QUIT\r\n" >&3; rd' "$H" 2>/dev/null)
    rcpt=$(awk '/^#RCPT/{getline; print}' <<<"$r"); vrfy=$(awk '/^#VRFY/{getline; print}' <<<"$r")
    rinfo "SMTP banner: $(head -n1 <<<"$r" | tr -d '\r')"
    [[ $rcpt == 250* ]] && rbad "OPEN RELAY: accepted mail for an outside domain" || rok "relay denied (${rcpt%$'\r'})"
    [[ $vrfy == 250* ]] && rbad "VRFY confirms users" || rok "VRFY doesn't confirm users"
    grep -qiE 'exim [0-9]|postfix \(' <<<"$(head -n1 <<<"$r")" && rinfo "SMTP banner reveals software/version"
    grep -q '250-AUTH' <<<"$r" && rbad "SMTP offers AUTH before STARTTLS - passwords sniffable"
  else rinfo "25 closed"; fi
  if [[ -n $RURL ]] && command -v curl >/dev/null; then
    RURL=${RURL%/}
    body=$(curl -sk -m 8 "$RURL/data/_data_/_default_/configs/application.ini")
    ver=$(curl -sk -m 8 "$RURL/data/VERSION" | head -c 20)
    if grep -q '^\[' <<<"$body" || [[ $ver =~ ^[0-9]+\.[0-9]+ ]]; then rbad "webmail DATA FOLDER downloadable: $RURL/data/"
    else rok "webmail data folder not downloadable"; fi
    adm=$(curl -sk -m 8 "$RURL/?admin")
    grep -qE 'RainLoopAdminLogin|"AdminLogin"|b-admin-menu' <<<"$adm" && rbad "admin panel reachable at $RURL/?admin" || rok "no admin panel at $RURL/?admin"
    if [[ $RURL == http://* ]]; then
      loc=$(curl -sk -m 8 -o /dev/null -w '%{http_code} %{redirect_url}' "$RURL/")
      [[ $loc == 30[1278]\ https://* ]] && rok "webmail HTTP redirects to HTTPS" || rinfo "webmail on plain HTTP: browser logins sniffable"
    fi
    curl -skI -m 8 "$RURL/" | grep -iE '^(server|x-powered-by):' | tr -d '\r' | sed "s/^/${Y}[info]${N} header: /"
  fi
  echo; rinfo "Now log in as a scored user (IMAPS + webmail), read and send one message: hardened-but-broken = FAIL"
}
[[ $MODE == remote ]] && { remote_check; exit 0; }
[[ $EUID -eq 0 ]] || { echo "Run as root (sudo)"; exit 1; }

# ---- shared helpers -----------------------------------------------------------------------
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
EXIM=$(command -v exim4 || command -v exim || true)
dc(){ doveconf -h "$1" 2>/dev/null; }

# dove_enforce DROPIN KEY... : after a restart, make sure each KEY really has the value our
# drop-in sets. A later-sorting conf.d file (zz-*.conf) or local.conf wins in Dovecot - a
# classic red-team trick to undo hardening - so any other file setting that key is commented
# out (originals are in the backup), then the config is re-validated and Dovecot restarted.
dove_enforce(){
  local drop=$1 k want f hit=0; shift; local LC_ALL=C
  for k in "$@"; do
    grep -q "^$k = " "$drop" || continue                  # only keys this drop-in sets
    want=$(sed -n "s/^$k = //p" "$drop" | tail -n1)
    [[ $(doveconf -h "$k" 2>/dev/null) == "$want" ]] && continue
    for f in /etc/dovecot/conf.d/*.conf /etc/dovecot/local.conf; do
      [[ -f $f && $f != *ccdc* ]] || continue               # never our own files
      # only files that load AFTER ours can override it: later in C sort order, or local.conf
      [[ $f == */local.conf ]] || [[ $(basename "$f") > $(basename "$drop") ]] || continue
      grep -qE "^[[:space:]]*${k}[[:space:]]*=" "$f" || continue
      sed -i -E "s/^([[:space:]]*)(${k}[[:space:]]*=)/\1#CCDC-overridden \2/" "$f"
      bad "$f was overriding '$k' (planted?) - neutralized it"; hit=1
    done
  done
  ((hit)) || return 0
  if doveconf -n >/dev/null 2>&1 && svc restart dovecot; then
    for k in "$@"; do grep -q "^$k = " "$drop" || continue; want=$(sed -n "s/^$k = //p" "$drop" | tail -n1)
      [[ $(doveconf -h "$k" 2>/dev/null) == "$want" ]] && ok "  $k = ${want:-(empty)} now effective" || bad "  $k still '$(doveconf -h "$k")' - check dovecot.conf includes by hand"; done
  else bad "Dovecot rejected the config after neutralizing - restore with the rollback command"; fi
}
exim_relay_open(){ printf 'EHLO probe.example\r\nMAIL FROM:<probe@example.com>\r\nRCPT TO:<probe@example.net>\r\nQUIT\r\n' \
                   | "$EXIM" -bh 192.0.2.77 2>/dev/null | grep -q '^250 Accepted'; }
exim_auth_notls(){ printf 'EHLO probe.example\r\nQUIT\r\n' | "$EXIM" -bh 192.0.2.77 2>/dev/null | grep -q '^250-AUTH'; }
broad(){ local re1='/[0-7]([[:space:],:;]|$)' re2='(^|[[:space:],:;])0\.0\.0\.0'; [[ " $1 " =~ $re1 || $1 =~ $re2 || $1 == *'*'* ]]; }
TS=$(date +%Y%m%d-%H%M%S); BK=""
record(){ [[ -n $BK ]] && echo "$1" >> "$BK/added-files.txt"; }   # every file this run writes (rollback deletes, then restores tar)
touched(){ [[ -n $BK ]] && echo "$1" >> "$BK/services.txt"; }

# ==========================================================================================
# ROLLBACK MODE - delete the files a run wrote, restore its config tarball and recorded
# permissions, restart the services it touched. Password changes are NOT undone.
# ==========================================================================================
rollback(){
  local b=$1 f s m u g p
  if [[ -z $b || ! -f $b/etc.tgz ]]; then
    echo "Usage: $0 --rollback /root/ccdc-backups/<dir>"
    echo "Backups from BOTH scripts, newest first (mail-* = mail_harden.sh, cve-* = mail_cve.sh)."
    echo "Undo NEWEST FIRST, one at a time: each backup also contains every earlier run's changes."
    ls -td /root/ccdc-backups/*/ 2>/dev/null | while IFS= read -r d; do [[ -f $d/etc.tgz ]] && echo "  ${d%/}"; done
    return 1
  fi
  hdr "Rollback from $b"
  [[ -f $b/added-files.txt ]] && sort -u "$b/added-files.txt" | while IFS= read -r f; do [[ -n $f ]] && rm -f "$f" && echo "[-] removed $f"; done
  tar xzpPf "$b/etc.tgz" && ok "configs restored from etc.tgz"
  [[ -f /etc/exim4/update-exim4.conf.conf ]] && command -v update-exim4.conf >/dev/null && update-exim4.conf
  for f in "$b"/*perms.txt; do
    [[ -f $f ]] || continue
    while read -r m u g p; do [[ -e $p ]] && chown "$u:$g" "$p" && chmod "$m" "$p"; done < "$f"
    ok "permissions restored ($(basename "$f"))"
  done
  [[ -s $b/services.txt ]] && sort -u "$b/services.txt" | while IFS= read -r s; do
    svc restart "$s" && ok "$s restarted" || bad "$s failed to restart - journalctl -u $s -n 30"
  done
  warn "password changes are not part of a rollback"
}
[[ $MODE == rollback ]] && { rollback "$RB_DIR"; exit $?; }

# ==========================================================================================
# PASSWORDS - replace the competition default password (now, and optionally on a timer).
# Rules = scoring engine's: 12+ chars, upper+lower+digit, symbols only ) ( ' . , @ | = : ; / - !
# ==========================================================================================
domain_joined(){
  realm list 2>/dev/null | grep -qi 'realm-name' && return 0
  systemctl is-active sssd >/dev/null 2>&1 && return 0
  grep -qiE '^(passwd|shadow):.*\b(sss|ldap|winbind)\b' /etc/nsswitch.conf 2>/dev/null && return 0
  grep -rqsE '^[^#]*pam_(sss|ldap|winbind)\.so' /etc/pam.d/ 2>/dev/null && return 0
  return 1
}
pw_ok(){ local p=$1 re="^[A-Za-z0-9)(.,@|=:;/!'-]+$"
  [[ ${#p} -ge 12 ]] || { echo "too short (12+ chars)"; return 1; }
  [[ $p =~ $re ]] || { echo "character the scoring engine rejects (allowed symbols: ) ( ' . , @ | = : ; / - !)"; return 1; }
  [[ $p =~ [A-Z] && $p =~ [a-z] && $p =~ [0-9] ]] || { echo "needs upper, lower and a digit"; return 1; }
  [[ ${p,,} == *trying-our-best* ]] && { echo "that is the competition default"; return 1; }
  return 0; }
genpw(){ local p=""; until [[ $p =~ [0-9] && $p =~ [a-z] && $p =~ [A-Z] ]]; do
  p=$(LC_ALL=C tr -dc 'A-HJ-NP-Za-km-z2-9' </dev/urandom | head -c 14); done; echo "$p"; }
ask_pw(){ local a b why
  while :; do
    read -rsp "  new password for $1 (blank = generate): " a </dev/tty; echo >/dev/tty
    [[ -z $a ]] && { echo ""; return; }
    why=$(pw_ok "$a") || { echo "  [!] rejected: $why" >/dev/tty; continue; }
    read -rsp "  confirm: " b </dev/tty; echo >/dev/tty
    [[ $a == "$b" ]] && { echo "$a"; return; }
    echo "  [!] didn't match" >/dev/tty
  done; }
rotate_round(){
  local pdb=pam pfile="" users=$PW_USERS u p why common="" out hash
  declare -A PW=(); declare -A TYPED=()
  if command -v doveconf >/dev/null; then
    pdb=$(doveconf -n 2>/dev/null | awk '/^passdb/{ if($2!="{"){print $2; exit} f=1; next } f && $1=="driver"{print $3; exit}')
    [[ $pdb == passwd-file ]] && pfile=$(doveconf -n | awk '/^passdb/{f=1} f && ($1=="args" || $1=="passwd_file_path"){print $NF; exit}')
  fi
  warn "Dovecot checks passwords via: ${pdb:-pam}${pfile:+ ($pfile)}"
  [[ ${pdb:-pam} =~ ^(pam|shadow|passwd|passwd-file)$ ]] || warn "passdb '$pdb' (ldap/sql?) - only system/passwd-file passwords are changed here"
  if [[ -n $PW_FILE ]]; then
    while IFS=: read -r u p; do
      [[ -z $u || $u == \#* ]] && continue
      if why=$(pw_ok "$p"); then PW[$u]=$p; TYPED[$u]=1; else bad "$u in $PW_FILE rejected: $why"; fi
    done < "$PW_FILE"
  else
    if [[ -z $users ]]; then
      if [[ $pdb == passwd-file && -f $pfile ]]; then users=$(cut -d: -f1 "$pfile" | grep -v '^#')
      else users=$(awk -F: '$3>=1000 && $3<65534 && $7 !~ /(nologin|false)$/ {print $1}' /etc/passwd); fi
    fi
    ((PW_ROOT)) && [[ " $users " != *" root "* ]] && users="root $users"
    if ((PW_ONE)) && ! ((PW_DRY)); then echo "  users: $(tr '\n' ' ' <<<"$users")"; common=$(ask_pw "ALL listed users"); fi
    for u in $users; do
      if ((PW_ONE)) && [[ -n $common ]]; then PW[$u]=$common; TYPED[$u]=1
      elif ((PW_EACH)) && ! ((PW_DRY)); then p=$(ask_pw "$u"); if [[ -n $p ]]; then PW[$u]=$p; TYPED[$u]=1; else PW[$u]=$(genpw); fi
      else PW[$u]=$(genpw); fi
    done
  fi
  mkdir -p /root/ccdc-backups/passwords; chmod 700 /root/ccdc-backups /root/ccdc-backups/passwords
  out=/root/ccdc-backups/passwords/passwords-$(date +%Y%m%d-%H%M%S).csv
  ((PW_DRY)) || ( umask 077; echo "user,password" > "$out" )
  [[ $pdb == passwd-file ]] && ! ((PW_DRY)) && cp -p "$pfile" "/root/ccdc-backups/passwords/$(basename "$pfile").$(date +%s)"
  for u in $(printf '%s\n' "${!PW[@]}" | sort); do
    [[ ${u,,} == seccdc* ]] && { echo "[-] skip $u (seccdc = Black Team, never touched)"; continue; }
    [[ $PW_EXCL == *" $u "* ]] && { echo "[-] skip $u (excluded)"; continue; }
    ((PW_DRY)) && { echo "[dry] would change $u"; continue; }
    p=${PW[$u]}
    if [[ $pdb == passwd-file ]]; then
      grep -q "^$u:" "$pfile" || { bad "$u not in $pfile"; continue; }
      hash=$(doveadm pw -s SHA512-CRYPT -p "$p")
      awk -F: -v OFS=: -v u="$u" -v h="$hash" '$1==u{$2=h}1' "$pfile" > "$pfile.tmp" && cat "$pfile.tmp" > "$pfile" && rm -f "$pfile.tmp"
    else
      id "$u" >/dev/null 2>&1 || { bad "no such user $u"; continue; }
      printf '%s:%s\n' "$u" "$p" | chpasswd || { bad "chpasswd failed for $u"; continue; }
    fi
    command -v doveadm >/dev/null && doveadm kick "$u" >/dev/null 2>&1
    printf '"%s","%s"\n' "$u" "$p" >> "$out"
    if [[ -n ${TYPED[$u]:-} ]]; then printf '[+] %-18s changed (typed password)\n' "$u"; else printf '[+] %-18s %s\n' "$u" "$p"; fi
  done
  ((PW_DRY)) && return 0
  command -v doveadm >/dev/null && doveadm auth cache flush >/dev/null 2>&1
  ok "saved to $out (root only); live IMAP/POP3 sessions kicked"
  bad "SUBMIT changed scored-account passwords at https://10.250.250.10/ - with PAM this is also the SSH password, tell the team"
}
passwords(){
  hdr "Passwords"
  if domain_joined && ! ((ALLOW_DOMAIN)); then
    bad "box looks DOMAIN-JOINED (SSSD/realm/LDAP): local changes desync from AD and break scoring."
    bad "change passwords on the domain controller instead (or --allow-domain if these are truly local)"; return 2
  fi
  [[ $PW_EVERY =~ ^[0-9]+$ ]] || PW_EVERY=0
  (( (PW_ONE || PW_EACH) )) && [[ ! -t 0 ]] && { bad "typed passwords need a terminal"; return 1; }
  (( PW_EVERY > 0 && !PW_ONE && !PW_EACH )) && PW_ONE=1
  rotate_round
  while (( PW_EVERY > 0 )); do
    echo; warn "next rotation in $PW_EVERY min (Ctrl-C to stop)"; sleep $((PW_EVERY*60))
    printf '\a'; hdr "Periodic rotation $(date +%H:%M)"; rotate_round
  done
}
[[ $MODE == passwords ]] && { passwords; exit $?; }
offer_passwords(){   # end of a harden run
  local yn mode every
  ((NO_ROTATE)) && return 0
  [[ -t 0 ]] || { warn "no terminal - change passwords now: sudo $0 --passwords --one"; return 0; }
  hdr "Default passwords"
  if ((ROTATE)); then yn=y; else read -rp "Change the default passwords now (recommended)? [Y/n] " yn </dev/tty; fi
  [[ ${yn,,} == n* ]] && { bad "skipped - accounts may still use the competition default"; return 0; }
  read -rp "  1) one password for all users   2) one per user   [1]: " mode </dev/tty
  [[ $mode == 2 ]] && PW_EACH=1 || PW_ONE=1
  read -rp "  Also change root's password? [y/N]: " yn </dev/tty; [[ ${yn,,} == y* ]] && PW_ROOT=1
  every=$ROTATE_EVERY
  [[ -n $every ]] || read -rp "  Ask again every N minutes (0 = only now) [0]: " every </dev/tty
  [[ $every =~ ^[0-9]+$ ]] && PW_EVERY=$every
  ((PW_EVERY > 0)) && warn "periodic rotation keeps this terminal busy - use tmux/screen"
  passwords
}

# ==========================================================================================
# WEBMAIL (RainLoop / SnappyMail) - shared by --audit (report) and harden (fix).
# Found by its data folder, because a never-configured RainLoop has NO application.ini and
# silently runs on built-in defaults: admin panel ON at /?admin with admin/12345.
# ==========================================================================================
ini_get(){ [[ -f $1 ]] || return 0; awk -v s="${2:+[$2]}" -v k="$3" '
  BEGIN{ insec=(s=="") }
  /^[ \t]*\[/ { t=$0; gsub(/[ \t]/,"",t); insec=(t==s); next }
  insec { kk=$0; sub(/=.*/,"",kk); gsub(/[ \t]/,"",kk)
          if (kk==k) { v=substr($0,index($0,"=")+1); gsub(/^[ \t]+|[ \t]+$/,"",v); gsub(/^"|"$/,"",v); print v; exit } }' "$1"; }
ini_set(){ local f=$1 tmp; tmp=$(mktemp)
  awk -v s="${2:+[$2]}" -v k="$3" -v line="$3 = $4" '
  BEGIN{ insec=(s==""); seen=(s=="") }
  /^[ \t]*\[/ { t=$0; gsub(/[ \t]/,"",t); if (insec && !done) { print line; done=1 }
                insec=(t==s); if (insec) seen=1; print; next }
  insec { kk=$0; sub(/=.*/,"",kk); gsub(/[ \t]/,"",kk); if (kk==k) { if (!done) print line; done=1; next } }
  { print }
  END { if (insec && !done) { print line; done=1 } if (!seen) { print ""; print s; print line } }' "$f" > "$tmp" \
  && cat "$tmp" > "$f"; rm -f "$tmp"; }
set_opt(){ local cur; cur=$(ini_get "$1" "$2" "$3"); [[ $cur == "${4//\"/}" ]] && return
  ini_set "$1" "$2" "$3" "$4" && ok "  [$2] $3 = $4 (was: ${cur:-unset})"; }
islocal(){ local h=${1,,}
  [[ $h == localhost || $h == 127.* || $h == ::1 || $h == "$(hostname)" || $h == "$(hostname -f 2>/dev/null)" ]] && return 0
  ip -o addr 2>/dev/null | awk '{sub(/\/.*/,"",$4); print $4}' | grep -qxF "$h"; }
imap_plain_probe(){ timeout 8 bash -c 'exec 3<>/dev/tcp/$0/$1 || exit 1; IFS= read -r -t3 l <&3; printf "%s\n" "$l"
  printf "a1 LOGIN ccdcprobe ccdcprobe\r\n" >&3
  while IFS= read -r -t3 l <&3; do printf "%s\n" "$l"; [[ $l == a1\ * ]] && break; done
  printf "a2 LOGOUT\r\n" >&3' "$1" "$2" 2>/dev/null; }
smtp_ehlo(){ timeout 8 bash -c 'exec 3<>/dev/tcp/$0/$1 || exit 1
  rd(){ while IFS= read -r -t4 l <&3; do printf "%s\n" "$l"; [[ $l =~ ^[0-9]{3}\  ]] && break; done; }
  rd >/dev/null; printf "EHLO ccdc.probe\r\n" >&3; rd; printf "QUIT\r\n" >&3' "$1" "$2" 2>/dev/null; }
tls_ok(){ local o a=(-connect "$2:$3"); [[ $1 != ssl ]] && a+=(-starttls "$1")
  o=$(echo | timeout 8 openssl s_client "${a[@]}" 2>/dev/null)
  grep -q 'Cipher is ' <<<"$o" && ! grep -q 'Cipher is (NONE)' <<<"$o"; }
exposure_test(){   # is DATA downloadable from the local web server? prints the URL that worked
  command -v curl >/dev/null || return 2
  local docroot rel base url ver; ver=$(head -c 40 "$1/VERSION" 2>/dev/null)
  for docroot in /var/www/html /var/www /usr/share/nginx/html /srv/www/htdocs /srv/http; do
    [[ $1 == "$docroot"/* ]] || continue
    rel=${1#"$docroot"}
    for base in http://127.0.0.1 https://127.0.0.1; do
      url="$base$rel/_data_/_default_/configs/application.ini"
      curl -sk -m 5 "$url" 2>/dev/null | grep -q '^\[' && { echo "$url"; return 0; }
      url="$base$rel/VERSION"
      [[ -n $ver && $(curl -sk -m 5 "$url" 2>/dev/null | head -c 40) == "$ver" ]] && { echo "$url"; return 0; }
    done
  done
  return 1; }
set_admin_password(){
  local ini=$1 pw="" again="" typed=1 hash
  command -v php >/dev/null || { bad "  php missing - change the webmail admin password by hand"; return; }
  if [[ -t 0 ]] && ! ((NO_ROTATE)); then
    while :; do
      read -rsp "  new WEBMAIL ADMIN password (blank = generate): " pw </dev/tty; echo >/dev/tty
      [[ -z $pw ]] && break
      pw_ok "$pw" >/dev/null || { echo "  [!] $(pw_ok "$pw")" >/dev/tty; continue; }
      read -rsp "  confirm: " again </dev/tty; echo >/dev/tty
      [[ $pw == "$again" ]] && break; echo "  [!] didn't match" >/dev/tty
    done
  fi
  [[ -z $pw ]] && { pw=$(genpw)$(genpw | head -c 2); typed=0; }
  hash=$(RL_PW="$pw" php -r 'echo password_hash(getenv("RL_PW"), PASSWORD_DEFAULT);')
  [[ $hash == \$2* || $hash == \$argon* ]] || { bad "  could not hash the admin password - unchanged"; return; }
  ini_set "$ini" security admin_password "\"$hash\""
  ( umask 077; printf 'webmail admin (%s): %s\n' "$ini" "$( ((typed)) && echo '(typed by you)' || echo "$pw")" >> "$BK/webmail-admin.txt" )
  ((typed)) && ok "  webmail admin password replaced (yours)" || ok "  webmail admin password replaced - saved in $BK/webmail-admin.txt"
}
WM_DATAS=(); WM_EXPOSED=(); WM_LOGS=()
webmail(){   # $1 = audit|harden
  local act=$1 cfgs=() c ini CFG DATA WEBROOT APP VER url ap apw key d dom ih ip is sh sp ss sa need r caps auth SW WU WG f
  mapfile -t cfgs < <(find ${WMPATH:-/var/www /srv /usr/share/nginx /usr/share/webapps /opt} -maxdepth 9 -type d -path '*/_data_/_default_' 2>/dev/null)
  ((${#cfgs[@]})) || { warn "no RainLoop/SnappyMail install found${WMPATH:+ under $WMPATH}"; return 0; }
  for CFG in "${cfgs[@]}"; do
    ini=$CFG/configs/application.ini; DATA=${CFG%/_data_/_default_}; WEBROOT=$(dirname "$DATA")
    APP=rainloop; [[ -d $WEBROOT/snappymail ]] && APP=snappymail; [[ -d $WEBROOT/$APP ]] || WEBROOT=""
    WM_DATAS+=("$(readlink -f "$DATA")")
    VER=$(head -c 20 "$DATA/VERSION" 2>/dev/null)
    hdr "Webmail: $APP ${VER:-?}  (data: $DATA)"
    [[ $APP == rainloop ]] && warn "RainLoop is abandoned - its unpatched CVEs are handled by mail_cve.sh"
    if url=$(exposure_test "$DATA"); then bad "data folder (config, admin hash, contacts) is WEB-READABLE: $url"; r=${url#http*://127.0.0.1}; r=${r%/_data_/*}; WM_EXPOSED+=("${r%/VERSION}")
    else ok "data folder not served over HTTP"; fi
    ap=$(ini_get "$ini" security allow_admin_panel); apw=$(ini_get "$ini" security admin_password); key=$(ini_get "$ini" security admin_panel_key)
    if [[ ! -f $ini ]]; then bad "no application.ini: running on DEFAULTS (admin panel ON, admin/12345)"; ap="On"; apw="12345"; key="admin"; fi
    [[ $apw == 12345 ]] && bad "admin password is the default 12345 -> /?${key:-admin} = full webmail takeover"
    [[ ${ap:-On} =~ ^(On|on|1|true)$ ]] && warn "admin panel enabled at /?${key:-admin}" || ok "admin panel disabled"
    [[ -f $CFG/admin_password.txt ]] && bad "SnappyMail initial admin password file present: $CFG/admin_password.txt"
    # webshell / tamper hunt (RainLoop ships harmless index.php/SALT.php stubs in data/)
    find "$DATA" -name '*.php' ! -name SALT.php ! -path '*/plugins/*' 2>/dev/null | while IFS= read -r f; do
      [[ $(basename "$f") == index.php ]] && [[ $(wc -c < "$f") -lt 200 ]] && continue
      bad "PHP in data folder (webshell?): $f"; done
    [[ -n $WEBROOT ]] && grep -rlE 'eval\(\s*(base64_decode|gzinflate|str_rot13|\$_(POST|GET|REQUEST|COOKIE))|(system|shell_exec|passthru|popen|proc_open|exec)\(\s*\$_(GET|POST|REQUEST|COOKIE)' \
      --include='*.php' "$WEBROOT" 2>/dev/null | grep -v "/$APP/v/" | sed "s/^/${R}[!]${N} webshell pattern: /"
    # webmail -> IMAP/SMTP: works? encrypted? switch to STARTTLS only when proven to work
    SW=0
    for d in "$CFG"/domains/*.ini; do
      [[ -f $d ]] || continue; dom=$(basename "$d" .ini)
      grep -qsw "$dom" "$CFG/domains/disabled" && continue
      ih=$(ini_get "$d" "" imap_host); ip=$(ini_get "$d" "" imap_port); is=$(ini_get "$d" "" imap_secure)
      sh=$(ini_get "$d" "" smtp_host); sp=$(ini_get "$d" "" smtp_port); ss=$(ini_get "$d" "" smtp_secure); sa=$(ini_get "$d" "" smtp_auth)
      [[ -z $ih ]] && continue
      if ! islocal "$ih"; then warn "  domain $dom points off-box ($ih) - shipped example? delete $d unless it is yours"; continue; fi
      echo "  domain $dom: IMAP $ih:$ip [${is:-None}]  SMTP $sh:$sp [${ss:-None}] auth=${sa:-Off}"
      need=0
      if [[ ${is:-None} == None ]]; then
        r=$(imap_plain_probe "$ih" "$ip")
        if [[ -z $r ]]; then bad "  IMAP $ih:$ip unreachable - webmail login BROKEN"
        elif grep -qiE 'PRIVACYREQUIRED|disallowed|LOGINDISABLED' <<<"$r"; then bad "  IMAP refuses cleartext -> webmail must use STARTTLS"; need=1
        else ok "  IMAP over loopback (not sniffable)"; ((FORCE_TLS)) && need=1; fi
      elif [[ $is == SSL ]]; then tls_ok ssl "$ih" "$ip" && ok "  IMAP implicit TLS works" || bad "  IMAP SSL FAILS"
      else tls_ok imap "$ih" "$ip" && ok "  IMAP STARTTLS works" || bad "  IMAP STARTTLS FAILS"; fi
      if ((need)); then
        if [[ $act == audit ]]; then warn "  harden would switch imap_secure -> TLS"
        elif tls_ok imap "$ih" "$ip"; then ini_set "$d" "" imap_secure '"TLS"'; ok "  imap_secure -> TLS (STARTTLS verified)"; SW=1
        else bad "  STARTTLS to $ih:$ip doesn't work - NOT switching"; fi
      fi
      need=0
      if [[ -n $sh && ${ss:-None} == None ]]; then
        caps=$(smtp_ehlo "$sh" "$sp"); auth=0; [[ ${sa,,} =~ ^(on|1|true|yes)$ ]] && auth=1
        if [[ -z $caps ]]; then bad "  SMTP $sh:$sp unreachable - webmail sending BROKEN"
        elif ((auth)) && ! grep -q AUTH <<<"$caps"; then bad "  SMTP only offers AUTH after TLS -> webmail must use STARTTLS"; need=1
        elif ((FORCE_TLS)); then need=1; fi
        if ((need)); then
          if [[ $act == audit ]]; then warn "  harden would switch smtp_secure -> TLS"
          elif grep -q STARTTLS <<<"$caps" && tls_ok smtp "$sh" "$sp"; then ini_set "$d" "" smtp_secure '"TLS"'; ok "  smtp_secure -> TLS (STARTTLS verified)"; SW=1
          else bad "  SMTP STARTTLS doesn't work - NOT switching"; fi
        fi
      fi
    done
    [[ $act == audit ]] && continue
    # ---- harden this install
    [[ -f $ini ]] || { mkdir -p "$(dirname "$ini")" && : > "$ini" && record "$ini" && ok "created $ini (install had no config)"; }
    if ((KEEP_ADMIN)); then set_opt "$ini" security allow_admin_panel On
      key="adm$(LC_ALL=C tr -dc 'a-z0-9' </dev/urandom | head -c 12)"; set_opt "$ini" security admin_panel_key "\"$key\""; warn "admin panel moved to /?$key"
    else set_opt "$ini" security allow_admin_panel Off; fi
    set_admin_password "$ini"     # replaced even with the panel off, so re-enabling it can't bring 12345 back
    set_opt "$ini" security csrf_protection On
    set_opt "$ini" webmail allow_additional_accounts Off
    set_opt "$ini" debug enable Off
    set_opt "$ini" logs hide_passwords On
    set_opt "$ini" logs auth_logging On
    set_opt "$ini" logs auth_logging_filename '"fail2ban/auth-fail.log"'
    set_opt "$ini" logs auth_logging_format '"[{date:Y-m-d H:i:s}] Auth failed: ip={request:ip} user={imap:login} host={imap:host} port={imap:port}"'
    ((SW)) && { set_opt "$ini" ssl verify_certificate Off; set_opt "$ini" ssl allow_self_signed On; }
    # permissions: data private to the PHP user; code owned by root so a webshell can't be dropped in
    WU=$(stat -c %U "$ini"); WG=$(stat -c %G "$ini")
    [[ $WU == root ]] && { WU=$(ps -eo user=,comm= | awk '$2 ~ /^(php-fpm|apache2|httpd)/ && $1!="root"{print $1; exit}'); WU=${WU:-$WEBUSER}; WG=$(id -gn "$WU" 2>/dev/null); }
    if [[ -n $WU && -n $WG ]]; then
      find "$DATA" ${WEBROOT:+"$WEBROOT/$APP"} ${WEBROOT:+"$WEBROOT/index.php"} -printf '%m %u %g %p\n' 2>/dev/null >> "$BK/webmail-perms.txt"
      chown -R "$WU:$WG" "$DATA"; find "$DATA" -type d -exec chmod 750 {} +; find "$DATA" -type f -exec chmod 640 {} +
      ok "$DATA -> $WU:$WG 750/640"
      if [[ -n $WEBROOT ]]; then
        chown -R root:root "$WEBROOT/$APP"; find "$WEBROOT/$APP" -type d -exec chmod 755 {} +; find "$WEBROOT/$APP" -type f -exec chmod 644 {} +
        grep -qiE 'rainloop|snappymail' "$WEBROOT/index.php" 2>/dev/null && chown root:root "$WEBROOT/index.php" && chmod 644 "$WEBROOT/index.php"
        ok "$WEBROOT/$APP code -> root-owned (PHP user can't modify it)"
      fi
    fi
    f=$CFG/logs/fail2ban/auth-fail.log; mkdir -p "$(dirname "$f")"; touch "$f"; [[ -n $WU ]] && chown -R "$WU:$WG" "$CFG/logs"
    WM_LOGS+=("$f")
  done
}

# ==========================================================================================
# AUDIT MODE - read-only. Diff two runs (before/after, or every 30 min) to spot tampering.
# ==========================================================================================
audit(){
  local p v fvu dpa aac mn rr f
  hdr "Listening mail ports"
  ss -tlnp 2>/dev/null | awk 'NR==1 || /:(25|110|143|465|587|993|995|4190) /'
  if command -v doveconf >/dev/null; then
    hdr "Dovecot (effective settings after all includes)"
    echo "  protocols = $(dc protocols)"
    [[ $(dc ssl) == required ]] && ok "ssl = required" || bad "ssl = $(dc ssl) (want: required)"
    dpa=$(dc disable_plaintext_auth); aac=$(dc auth_allow_cleartext)
    [[ $dpa == yes || $aac == no ]] && ok "cleartext logins refused without TLS" || bad "cleartext logins ALLOWED - passwords sniffable on 110/143"
    v=$(dc ssl_min_protocol); [[ $v =~ TLSv1\.[23] ]] && ok "ssl_min_protocol = $v" || bad "ssl_min_protocol = ${v:-default} (want TLSv1.2)"
    fvu=$(dc first_valid_uid); [[ $fvu =~ ^[0-9]+$ ]] && ((fvu >= 500)) && ok "first_valid_uid = $fvu" || bad "first_valid_uid = ${fvu:-unset} (system accounts can log in)"
    [[ -f /etc/dovecot/local.conf ]] && warn "/etc/dovecot/local.conf exists - loaded LAST, can override hardening; review it"
    find /etc/dovecot -type f -mtime -2 -printf '  [*] changed <2 days: %p\n' 2>/dev/null | grep -v ccdc
  fi
  hdr "Mailbox permissions"
  for p in $(readlink -f /var/mail /var/spool/mail 2>/dev/null | sort -u); do
    [[ -d $p ]] || continue
    find "$p" -maxdepth 0 -perm -o=w -printf "${R}[!]${N} spool dir world-WRITABLE: %p\n"
    find "$p" -mindepth 1 -maxdepth 1 -perm /o=rwx -printf "${R}[!]${N} world-accessible mailbox: %p (%m)\n"
    find "$p" -mindepth 1 -maxdepth 1 -type f -printf '%f %u\n' | awk -v r="$R" -v n="$N" '$1!=$2{print r "[!]" n " mailbox " $1 " owned by " $2}'
  done
  for p in /home/*/Maildir /home/*/mail; do [[ -d $p ]] && find "$p" -maxdepth 0 -perm /o=rwx -printf "${R}[!]${N} world-accessible: %p\n"; done
  if command -v postconf >/dev/null; then
    hdr "Postfix"
    mn=$(postconf -h mynetworks 2>/dev/null); broad "$mn" && bad "mynetworks = $mn - effectively an OPEN RELAY" || ok "mynetworks = $mn"
    rr="$(postconf -h smtpd_relay_restrictions) $(postconf -h smtpd_recipient_restrictions)"
    [[ $rr == *reject_unauth_destination* || $rr == *defer_unauth_destination* ]] && ok "reject_unauth_destination present" || bad "no reject_unauth_destination - possible OPEN RELAY"
    [[ $(postconf -h disable_vrfy_command) == yes ]] && ok "VRFY disabled" || bad "VRFY enabled (user enumeration)"
    [[ $(postconf -h smtpd_tls_auth_only) == yes ]] && ok "AUTH only after TLS" || warn "smtpd_tls_auth_only = no"
    postconf -h smtpd_banner | grep -q mail_version && warn "SMTP banner shows the Postfix version"
  fi
  if [[ -n $EXIM ]]; then
    hdr "Exim"
    exim_relay_open && bad "OPEN RELAY (exim -bh test from 192.0.2.77 accepted outside mail)" || ok "relay denied for outside hosts"
    exim_auth_notls && bad "SMTP AUTH offered before TLS - passwords sniffable" || ok "SMTP AUTH not offered before TLS"
    "$EXIM" -bP smtp_banner 2>/dev/null | grep -q version_number && warn "SMTP banner shows the Exim version"
    [[ -f /etc/exim4/update-exim4.conf.conf ]] && grep -E '^dc_(relay_nets|relay_domains|local_interfaces)' /etc/exim4/update-exim4.conf.conf | sed 's/^/  /'
    v=$("$EXIM" -bpc 2>/dev/null); [[ ${v:-0} -gt 50 ]] && bad "mail queue: $v messages - relay abuse?" || ok "mail queue: ${v:-0} messages"
  fi
  ((DO_WEB)) && webmail audit
  hdr "Mail persistence (red team favourites)"
  [[ -f /etc/aliases ]] && grep -nE '^[^#]*\|' /etc/aliases | sed "s/^/${R}[!]${N} pipe-to-command alias: /"
  [[ -f /etc/aliases ]] && grep -nE '^[^#]*:.*@' /etc/aliases | sed "s/^/${Y}[*]${N} alias forwards off-box: /"
  find /home /root -maxdepth 2 -name .forward 2>/dev/null | while IFS= read -r f; do bad "$f -> $(tr '\n' ' ' < "$f")"; done
  find /home /root /var/vmail /var/lib/dovecot -maxdepth 4 \( -name '*.sieve' -o -name .dovecot.sieve \) 2>/dev/null \
    | while IFS= read -r f; do grep -qiE 'redirect|vnd\.dovecot\.(pipe|execute)' "$f" && bad "sieve redirect/pipe: $f"; done
  hdr "Accounts"
  awk -F: '$3==0 && $1!="root"{print "[!] extra UID 0 account: " $1}' /etc/passwd
  awk -F: '$2==""{print "[!] EMPTY password: " $1}' /etc/shadow
  echo "  login users (rotate these):"; awk -F: '$3>=1000 && $3<65534 && $7 !~ /(nologin|false)$/{printf "    %-18s %s\n", $1, $7}' /etc/passwd
  hdr "Top failed-login sources"
  for f in "$MAILLOG" /var/log/exim4/mainlog /var/log/exim/main.log; do
    [[ -f $f ]] || continue; echo "  $f"
    grep -Ei 'auth failed|authentication failed|authenticator failed|password mismatch' "$f" | grep -oE '(rip=|\[)[0-9]{1,3}(\.[0-9]{1,3}){3}' \
      | tr -d '[' | sed 's/rip=//' | sort | uniq -c | sort -rn | head -n 8 | sed 's/^/    /'
  done
  echo; warn "cleartext tests must run from ANOTHER box: $0 --remote <this-ip> http://<this-ip>/rainloop"
  warn "known CVEs / patch level: ./mail_cve.sh"
}
[[ $MODE == audit ]] && { audit; exit 0; }

# ==========================================================================================
# HARDEN MODE
# ==========================================================================================
# ---- STEP 1: backup everything this run can touch (one folder = one rollback) ------------
BK=/root/ccdc-backups/mail-$TS
mkdir -p "$BK"; chmod 700 /root/ccdc-backups "$BK"
exec > >(tee -a "$BK/harden.log") 2>&1
: > "$BK/added-files.txt"; : > "$BK/services.txt"
hdr "STEP 1  Backup -> $BK"
paths=()
for p in /etc/dovecot /etc/postfix /etc/aliases /etc/aliases.db /etc/exim4 /etc/exim /etc/fail2ban /etc/apache2 /etc/httpd /etc/nginx; do [[ -e $p ]] && paths+=("$p"); done
while IFS= read -r c; do for x in "$c/configs" "$c/domains"; do [[ -e $x ]] && paths+=("$x"); done
done < <(find ${WMPATH:-/var/www /srv /usr/share/nginx /usr/share/webapps /opt} -maxdepth 9 -type d -path '*/_data_/_default_' 2>/dev/null)
tar czpPf "$BK/etc.tgz" "${paths[@]}" 2>/dev/null; ok "saved: ${paths[*]}"
for d in /var/mail /var/spool/mail; do [[ -e $d ]] && find -H "$d" -maxdepth 1 -printf '%m %u %g %p\n'; done > "$BK/spool-perms.txt"

# ---- STEP 2: Dovecot - TLS required, no cleartext logins, TLS 1.2+, no system-account logins
# One drop-in (conf.d/99-ccdc-hardening.conf, loaded last of conf.d). Dovecot 2.3 and 2.4 name
# settings differently; both handled. No cert = make a self-signed one (ssl=required needs it).
if command -v doveconf >/dev/null; then
  hdr "STEP 2  Dovecot"
  VER=$(dovecot --version | awk '{print $1}'); MAJ=${VER%%.*}; MIN=$(cut -d. -f2 <<<"$VER")
  is24=0; (( MAJ > 2 || (MAJ == 2 && MIN >= 4) )) && is24=1
  DROP=/etc/dovecot/conf.d/99-ccdc-hardening.conf
  rm -f "$DROP"; record "$DROP"; touched dovecot
  cur=$(dc protocols); newp=$cur
  if [[ -n $DISABLE ]]; then newp=$(sed -E "s/(^| )$DISABLE( |$)/ /g" <<<"$cur" | xargs)
    [[ $newp =~ (imap|pop3) ]] || { bad "disabling $DISABLE would leave no IMAP/POP3 - skipped"; newp=$cur; }; fi
  if ((is24)); then cert=$(dc ssl_server_cert_file); key=$(dc ssl_server_key_file); else cert=$(dc ssl_cert); key=$(dc ssl_key); fi
  cert=${cert#<}; key=${key#<}; CERTLINES=""
  if [[ ! -s $cert || ! -s $key ]]; then
    warn "no usable TLS certificate - generating a self-signed one"
    mkdir -p /etc/dovecot/private
    openssl req -x509 -nodes -newkey rsa:2048 -days 365 -subj "/CN=$(hostname -f 2>/dev/null || hostname)" \
      -keyout /etc/dovecot/private/ccdc.key -out /etc/dovecot/private/ccdc.pem 2>/dev/null; chmod 600 /etc/dovecot/private/ccdc.key
    record /etc/dovecot/private/ccdc.key; record /etc/dovecot/private/ccdc.pem
    if ((is24)); then CERTLINES=$'ssl_server_cert_file = /etc/dovecot/private/ccdc.pem\nssl_server_key_file = /etc/dovecot/private/ccdc.key'
    else CERTLINES=$'ssl_cert = </etc/dovecot/private/ccdc.pem\nssl_key = </etc/dovecot/private/ccdc.key'; fi
  fi
  FVU=1000; mu=$(dc mail_uid)   # virtual-mail setups run as a low uid; don't lock those out
  if [[ -n $mu ]]; then muid=$(id -u "$mu" 2>/dev/null || echo "$mu"); [[ $muid =~ ^[0-9]+$ ]] && ((muid > 0 && muid < 1000)) && FVU=$muid; fi
  {
    echo "# CCDC hardening $TS - delete this file to undo"
    [[ $newp != "$cur" ]] && echo "protocols = $newp"
    if ((ALLOW_PLAIN)); then echo "ssl = yes"; ((is24)) && echo "auth_allow_cleartext = yes" || echo "disable_plaintext_auth = no"
    else echo "ssl = required"; ((is24)) && echo "auth_allow_cleartext = no" || echo "disable_plaintext_auth = yes"; fi
    echo "ssl_min_protocol = TLSv1.2"
    echo "auth_mechanisms = plain login"
    echo "first_valid_uid = $FVU"
    ((is24)) || echo "auth_verbose = yes"
    [[ -n $CERTLINES ]] && echo "$CERTLINES"
  } > "$DROP"; chmod 644 "$DROP"
  if doveconf -n >/dev/null 2>"$BK/doveconf.err" && svc restart dovecot; then
    dove_enforce "$DROP" ssl disable_plaintext_auth auth_allow_cleartext ssl_min_protocol first_valid_uid auth_mechanisms protocols
    ok "Dovecot hardened: ssl=$(dc ssl), min TLS $(dc ssl_min_protocol), first_valid_uid=$(dc first_valid_uid)${DISABLE:+, $DISABLE off}"
  else
    bad "Dovecot rejected the change - reverted:"; cat "$BK/doveconf.err"; mv "$DROP" "$BK/rejected-dovecot.conf"; svc restart dovecot
  fi
  ((ALLOW_PLAIN)) && warn "--allow-plaintext: passwords still cross 110/143 in cleartext - rotate often"
else warn "Dovecot not installed - skipped"; fi

# ---- STEP 3: mailboxes readable only by their owner ----------------------------------------
hdr "STEP 3  Mailbox permissions"
for d in $(readlink -f /var/mail /var/spool/mail 2>/dev/null | sort -u); do
  [[ -d $d ]] || continue
  chown root:mail "$d"; chmod 2775 "$d"; find "$d" -mindepth 1 -maxdepth 1 -type f -exec chmod o-rwx,ug-x {} +
  ok "$d -> 2775 root:mail, mailboxes not world-readable"
done
while IFS=: read -r _ _ uid _ _ home _; do ((uid >= 1000 && uid < 65534)) || continue
  for m in "$home/Maildir" "$home/mail"; do [[ -d $m ]] && chmod -R go-rwx "$m" && ok "$m -> owner only"; done
done < /etc/passwd
[[ -d /var/vmail ]] && chmod -R o-rwx /var/vmail && ok "/var/vmail -> no world access"

# ---- STEP 4a: Postfix - no open relay, no VRFY, TLS 1.2+, AUTH only after TLS, no version --
if command -v postconf >/dev/null; then
  hdr "STEP 4  Postfix"
  pc(){ postconf -e "$1" && ok "$1"; }
  pc "smtpd_relay_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination"
  mn=$(postconf -h mynetworks)
  if ((LOCK_RELAY)) || broad "$mn"; then pc "mynetworks = 127.0.0.0/8 [::ffff:127.0.0.0]/104 [::1]/128"; warn "mynetworks was: $mn"
  else warn "mynetworks = $mn left alone (--lock-relay = localhost only)"; fi
  pc "disable_vrfy_command = yes"; pc "smtpd_helo_required = yes"; pc 'smtpd_banner = $myhostname ESMTP'
  pc "smtpd_tls_protocols = !SSLv2, !SSLv3, !TLSv1, !TLSv1.1"; pc "smtpd_tls_mandatory_protocols = !SSLv2, !SSLv3, !TLSv1, !TLSv1.1"
  if [[ -s $(postconf -h smtpd_tls_cert_file) ]]; then
    [[ $(postconf -h smtpd_tls_security_level) =~ ^(|none)$ ]] && pc "smtpd_tls_security_level = may"
    pc "smtpd_tls_auth_only = yes"
  else warn "no Postfix TLS certificate - STARTTLS not enabled"; fi
  if postfix check 2>"$BK/postfix.err"; then svc reload postfix || svc restart postfix; touched postfix; ok "Postfix reloaded"
  else bad "postfix check failed - restoring main.cf"; cat "$BK/postfix.err"; tar xzpPf "$BK/etc.tgz" /etc/postfix/main.cf; svc restart postfix; fi
fi

# ---- STEP 4b: Exim - close an open relay, STARTTLS, AUTH only after TLS, hide version -------
# Debian/Ubuntu: settings live in update-exim4.conf.conf + exim4.conf.localmacros (applied with
# update-exim4.conf). RHEL: one exim.conf file. Proof = exim -bh, a simulated outside session.
if [[ -n $EXIM ]]; then
  hdr "STEP 4  Exim"
  CHG=0
  if [[ -f /etc/exim4/update-exim4.conf.conf ]] && command -v update-exim4.conf >/dev/null; then
    UC=/etc/exim4/update-exim4.conf.conf; LM=/etc/exim4/exim4.conf.localmacros
    rn=$(sed -n "s/^dc_relay_nets='\(.*\)'/\1/p" "$UC"); rd=$(sed -n "s/^dc_relay_domains='\(.*\)'/\1/p" "$UC")
    if ((LOCK_RELAY)) || broad "$rn"; then sed -i "s/^dc_relay_nets=.*/dc_relay_nets=''/" "$UC"; ok "dc_relay_nets: '$rn' -> '' (localhost only)"; CHG=1
    else warn "dc_relay_nets='$rn' left alone (--lock-relay = localhost only)"; fi
    [[ $rd == *'*'* ]] && { sed -i "s/^dc_relay_domains=.*/dc_relay_domains=''/" "$UC"; ok "dc_relay_domains '$rd' -> ''"; CHG=1; }
    [[ -e $LM ]] || record "$LM"
    if ! grep -qsE '^\s*MAIN_TLS_ENABLE' "$LM" /etc/exim4/conf.d/main/* 2>/dev/null; then
      if [[ ! -s /etc/exim4/exim.crt || ! -s /etc/exim4/exim.key ]]; then
        openssl req -x509 -nodes -newkey rsa:2048 -days 365 -subj "/CN=$(hostname -f 2>/dev/null || hostname)" \
          -keyout /etc/exim4/exim.key -out /etc/exim4/exim.crt 2>/dev/null
        chown root:Debian-exim /etc/exim4/exim.key /etc/exim4/exim.crt; chmod 640 /etc/exim4/exim.key
        record /etc/exim4/exim.key; record /etc/exim4/exim.crt
      fi
      echo "MAIN_TLS_ENABLE = yes" >> "$LM"; ok "STARTTLS enabled"; CHG=1
    fi
    # (Debian's template only mentions MAIN_SMTP_BANNER in a comment, so set the option itself;
    #  localmacros is inserted into the main section, where a plain option line is valid)
    if ! grep -qsE '^\s*smtp_banner' "$LM"; then echo 'smtp_banner = $smtp_active_hostname ESMTP' >> "$LM"; ok "SMTP banner no longer shows the Exim version"; CHG=1; fi
    if grep -qsE '^\s*AUTH_SERVER_ALLOW_NOTLS_PASSWORDS' "$LM" /etc/exim4/conf.d/main/* 2>/dev/null; then
      if ((EXIM_TLS_AUTH)); then sed -i 's/^\(\s*AUTH_SERVER_ALLOW_NOTLS_PASSWORDS\)/# CCDC \1/' "$LM" /etc/exim4/conf.d/main/* 2>/dev/null; ok "SMTP AUTH now requires STARTTLS"; CHG=1
      else bad "AUTH_SERVER_ALLOW_NOTLS_PASSWORDS: SMTP passwords allowed in cleartext (fix: --exim-tls-auth-only)"; fi
    fi
    apply_exim(){ update-exim4.conf; }
  else
    CF=$("$EXIM" -bV 2>/dev/null | awk '/^Configuration file is/{print $NF; exit}')
    apply_exim(){ true; }
    if [[ -f $CF ]]; then
      rfh=$(sed -n 's/^\s*hostlist\s\+relay_from_hosts\s*=\s*//p' "$CF" | head -n1); rtd=$(sed -n 's/^\s*domainlist\s\+relay_to_domains\s*=\s*//p' "$CF" | head -n1)
      if ((LOCK_RELAY)) || broad "$rfh"; then sed -i 's/^\(\s*hostlist\s\+relay_from_hosts\s*=\).*/\1 <; 127.0.0.1 ; ::1/' "$CF"; ok "relay_from_hosts '$rfh' -> localhost"; CHG=1
      else warn "relay_from_hosts = $rfh left alone"; fi
      [[ $rtd == *'*'* ]] && { sed -i 's/^\(\s*domainlist\s\+relay_to_domains\s*=\).*/\1/' "$CF"; ok "relay_to_domains '$rtd' -> empty"; CHG=1; }
      if grep -qE '^\s*smtp_banner\s*=.*version_number' "$CF"; then sed -i 's/^\(\s*smtp_banner\s*=\).*/\1 ${primary_hostname} ESMTP/' "$CF"; ok "SMTP banner version hidden"; CHG=1; fi
    else warn "Exim config file not found - relay settings not edited"; fi
  fi
  if ((CHG)); then
    touched "$EXIMSVC"
    if apply_exim && "$EXIM" -bV >/dev/null 2>"$BK/exim.err" && svc restart "$EXIMSVC"; then ok "Exim config valid, restarted"
    else bad "Exim rejected the change - restoring"; cat "$BK/exim.err"; tar xzpPf "$BK/etc.tgz" /etc/exim4 /etc/exim 2>/dev/null; apply_exim; svc restart "$EXIMSVC"; fi
  fi
  exim_relay_open && bad "Exim STILL relays for outside hosts - an ACL accepts it; review acl_check_rcpt" || ok "open-relay test (exim -bh from outside): denied"
  exim_auth_notls && warn "Exim offers AUTH before TLS (passwords sniffable on 25/587)"
fi

# ---- STEP 5: webmail (after the mail servers, so its IMAP/SMTP path is re-tested against them)
((DO_WEB)) && webmail harden

# ---- STEP 6: web server - deny the webmail data folder and hide versions -------------------
if ((DO_WEB)) && ((${#WM_DATAS[@]})); then
  hdr "STEP 6  Web server"
  if pgrep -x apache2 >/dev/null || pgrep -x httpd >/dev/null; then
    # zz- loads last: for ServerTokens the last value wins (Ubuntu's security.conf says "OS")
    if [[ -d /etc/apache2/conf-available ]]; then AC=/etc/apache2/conf-available/zz-ccdc-mail.conf; else AC=/etc/httpd/conf.d/zz-ccdc-mail.conf; fi
    record "$AC"
    { echo "# CCDC $TS - block webmail data folders, hide version"
      for d in "${WM_DATAS[@]}"; do printf '<Directory "%s">\n    Require all denied\n</Directory>\n' "$d"; done
      printf 'ServerTokens Prod\nServerSignature Off\nTraceEnable Off\n'; } > "$AC"
    [[ $WEBSVC == apache2 ]] && a2enconf -q zz-ccdc-mail >/dev/null && record /etc/apache2/conf-enabled/zz-ccdc-mail.conf
    if apachectl configtest >/dev/null 2>&1; then svc reload "$WEBSVC" || svc restart "$WEBSVC"; touched "$WEBSVC"; sleep 1; ok "data folder denied, ServerTokens Prod ($AC)"
    else bad "apachectl configtest failed - reverted"; [[ $WEBSVC == apache2 ]] && a2disconf -q zz-ccdc-mail >/dev/null; rm -f "$AC"; fi
  elif pgrep -x nginx >/dev/null; then
    bad "nginx ignores RainLoop's .htaccess. Add inside the webmail server{} block, then nginx -t && systemctl reload nginx:"
    for r in "${WM_EXPOSED[@]:-/rainloop/data}"; do echo "    location ^~ $r/ { deny all; return 403; }"; done
    echo "    server_tokens off;"
  else warn "no running Apache/nginx found"; fi
  for d in "${WM_DATAS[@]}"; do url=$(exposure_test "$d") && bad "STILL web-readable: $url" || ok "data folder blocked: $d"; done
fi

# ---- STEP 7: fail2ban - one jail file for every mail service; SECCDC infra never banned -----
if ((F2B)); then
  hdr "STEP 7  fail2ban"
  if ! command -v fail2ban-client >/dev/null && ((INSTALL)); then
    warn "installing fail2ban via $PKG"
    case $PKG in
      apt-get) DEBIAN_FRONTEND=noninteractive timeout 180 apt-get install -y fail2ban >/dev/null 2>&1 ;;
      *) timeout 180 "$PKG" install -y fail2ban >/dev/null 2>&1 || { "$PKG" install -y epel-release >/dev/null 2>&1 && timeout 180 "$PKG" install -y fail2ban >/dev/null 2>&1; } ;;
    esac
  fi
  if command -v fail2ban-client >/dev/null; then
    # Read the journal only when systemd is really running; otherwise read the log FILES (a jail
    # whose backend can't start stops fail2ban loading ANY jail, so this choice matters).
    if [[ -d /run/systemd/system ]] && [[ ! -f $MAILLOG ]]; then BL='backend  = systemd'
    else touch "$MAILLOG"; BL=$'backend  = auto\nlogpath  = '"$MAILLOG"; fi
    EXLOG=/var/log/exim4/mainlog; [[ $DISTRO == rhel ]] && EXLOG=/var/log/exim/main.log
    J=/etc/fail2ban/jail.d/ccdc-mail.local; FF=/etc/fail2ban/filter.d/ccdc-webmail.conf; record "$J"
    jail(){ printf '[%s]\nenabled  = true\n%s\nmaxretry = 5\nfindtime = 600\nbantime  = 1800\nignoreip = 127.0.0.1/8 ::1 %s %s\n\n' "$1" "$2" "$INFRA" "$IGNORE"; }
    JAILS=()
    {
      echo "# CCDC mail jails $TS"
      command -v dovecot >/dev/null && { jail dovecot "$BL"; JAILS+=(dovecot); }
      command -v postconf >/dev/null && { jail postfix "$BL"; jail postfix-sasl "$BL"; JAILS+=(postfix postfix-sasl); }
      [[ -n $EXIM ]] && { jail exim $'backend  = auto\nlogpath  = '"$EXLOG"; JAILS+=(exim); }
      if ((${#WM_LOGS[@]})); then
        printf '[Definition]\nfailregex = ^\\[[^]]*\\] Auth failed: ip=<HOST> user=\nignoreregex =\n' > "$FF"; record "$FF"
        jail ccdc-webmail "$(printf 'filter   = ccdc-webmail\nport     = http,https\nbackend  = auto\nlogpath  = %s' "${WM_LOGS[*]}")"; JAILS+=(ccdc-webmail)
      fi
    } > "$J"
    if fail2ban-client -t >/dev/null 2>"$BK/f2b.err"; then
      touched fail2ban; svc enable fail2ban; svc restart fail2ban; sleep 3
      if ! fail2ban-client ping >/dev/null 2>&1; then
        bad "fail2ban did not start - last error:"; grep -E 'ERROR' /var/log/fail2ban.log 2>/dev/null | tail -n1 | cut -c1-200
        warn "often another jail (e.g. sshd on systemd) failing - fix it, then: systemctl restart fail2ban"
      else
        F2BFAIL=0
        for j in "${JAILS[@]}"; do fail2ban-client status "$j" >/dev/null 2>&1 && ok "jail $j active" || { bad "jail $j NOT active"; F2BFAIL=1; }; done
        ((F2BFAIL)) && { warn "cause (fail2ban.log):"; grep 'ERROR' /var/log/fail2ban.log 2>/dev/null | tail -n2 | cut -c1-160 | sed 's/^/    /'
                         warn "a broken jail elsewhere (often sshd) stops all jails loading - fix it, then systemctl restart fail2ban"; }
      fi
      warn "never banned: $INFRA $IGNORE"
    else bad "fail2ban rejected the config - reverted"; grep -iE 'error|exception' "$BK/f2b.err" | head -n3; rm -f "$J" "$FF"; fi
  else bad "fail2ban unavailable - skipped"; fi
fi

# ---- STEP 8: result, then new passwords ----------------------------------------------------
hdr "Result"
ss -tlnp 2>/dev/null | awk 'NR==1 || /:(25|110|143|465|587|993|995|4190) /'
echo; ok "Backup + log: $BK      Undo: sudo $0 --rollback $BK"
warn "NEXT: 1) log in to webmail as a scored user, read + send a message  2) check the scoreboard"
warn "      3) from another box: $0 --remote <this-ip> http://<this-ip>/rainloop  4) sudo ./mail_cve.sh"
offer_passwords
