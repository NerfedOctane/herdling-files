#!/bin/bash
# Rotates passwords and clears SSH authorized_keys for every user with a login
# shell on this system, except the users listed in an exclusion file.
#
# Usage: sudo ./credentialRotateExclude.sh <exclude_list.txt>
#
#   exclude_list.txt - users to NOT touch, one per line
#
# Blank lines and lines starting with # are ignored, and Windows (CRLF) line
# endings are handled. root and blackteam_adm are always excluded, even if they
# are missing from the file. Only accounts whose shell ends in "sh" (bash, sh,
# zsh, dash, ...) are changed, so service accounts with nologin/false shells are
# left alone. The root password is changed separately at the end; you will be
# prompted for it.

defaultExclude=(
    "blackteam_adm"
    "root"
)

if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root." >&2
    exit 1
fi

if [[ $# -ne 1 ]]; then
    echo "Usage: $0 <exclude_list.txt>" >&2
    exit 1
fi

excludeFile="$1"
if [[ ! -f "$excludeFile" || ! -r "$excludeFile" ]]; then
    echo "Cannot read file: $excludeFile" >&2
    exit 1
fi

# Print the usernames in a file, one per line, skipping blanks and comments
readUserFile() {
    local line name
    while IFS= read -r line || [[ -n "$line" ]]; do
        # Usernames can't contain whitespace, so strip all of it (including CR from CRLF files)
        name="${line//[[:space:]]/}"
        [[ -z "$name" || "$name" == \#* ]] && continue
        echo "$name"
    done < "$1"
}

declare -A excluded
for u in "${defaultExclude[@]}"; do
    excluded["$u"]=1
done
while IFS= read -r u; do
    excluded["$u"]=1
done < <(readUserFile "$excludeFile")

# Everyone with a login shell who isn't excluded
declare -A seen
targets=()
while IFS=: read -r username _ _ _ _ _ shell; do
    [[ -z "$username" || -n "${seen[$username]}" ]] && continue
    seen["$username"]=1
    [[ -n "${excluded[$username]}" ]] && continue
    [[ "$shell" == *sh ]] || continue
    targets+=("$username")
done < <(getent passwd)

hostname=$(hostname)

echo "Users that will NOT be touched (${#excluded[@]}):"
printf '    %s\n' "${!excluded[@]}" | sort
echo
echo "Users that WILL be changed on $hostname (${#targets[@]}):"
printf '    %s\n' "${targets[@]}"
echo

if [[ ${#targets[@]} -eq 0 ]]; then
    echo "No users to change. Exiting..."
    exit 0
fi

keyDir="/etc/ssh/shared_keys"
mkdir -p "$keyDir"
chmod 700 "$keyDir"

sshKey="$keyDir/shared_key"
if [ ! -f "$sshKey" ]; then
    if ssh-keygen -t rsa -b 4096 -f "$sshKey" -N '' -q; then
        echo "Shared SSH key pair generated."
    else
        echo "WARNING: Failed to generate shared SSH key pair."
    fi
else
    echo "Shared SSH key pair already exists."
fi

echo "Enter the new passphrase for the users listed above (Ctrl+C to cancel):"
read -rs sharedPassphrase
echo
echo "Confirm the passphrase:"
read -rs confirmPassphrase
echo

if [[ -z "$sharedPassphrase" ]]; then
    echo "Passphrase cannot be empty. Exiting..."
    exit 1
fi

if [[ "$sharedPassphrase" != "$confirmPassphrase" ]]; then
    echo "Passphrases do not match. Exiting..."
    exit 1
fi
unset confirmPassphrase

changed=0
failed=0

for username in "${targets[@]}"; do
    IFS=: read -r _ _ _ gid _ home _ <<< "$(getent passwd "$username")"

    if echo "$username:$sharedPassphrase" | chpasswd; then
        echo "Password changed for $username"
    else
        echo "Failed to change password for $username"
        failed=$((failed + 1))
        continue
    fi
    changed=$((changed + 1))

    # Don't create .ssh in / or in a home directory that doesn't exist
    if [[ -z "$home" || "$home" == "/" || ! -d "$home" ]]; then
        echo "No usable home directory for $username, authorized_keys not touched"
        continue
    fi

    userSshDir="$home/.ssh"
    if [[ -L "$userSshDir" ]] || [[ -e "$userSshDir" && ! -d "$userSshDir" ]]; then
        echo "WARNING: $userSshDir is a symlink or not a directory, authorized_keys not touched"
        continue
    fi

    mkdir -p "$userSshDir"
    chown "$username":"$gid" "$userSshDir"
    chmod 700 "$userSshDir"

    # Remove first so a planted symlink can't redirect the write to another file
    rm -f "$userSshDir/authorized_keys"
    install -m 600 -o "$username" -g "$gid" /dev/null "$userSshDir/authorized_keys"
    echo "Cleared authorized_keys for $username."
done

unset sharedPassphrase

echo
echo "Summary: $changed password(s) changed, $failed failed."

# Changing root user password
echo "Now changing the root password:"
passwd root

echo "Script completed."
