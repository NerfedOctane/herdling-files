#!/bin/bash
# ============================================================
# harden-web-docker.sh
# CCDC Web Hardening Script — Docker-Based Services
# OS Agnostic: RHEL/CentOS/Fedora and Debian/Ubuntu
# ============================================================
#
# FUNCTIONS:
#   detect_os                  — Detects OS family (rhel or debian) and sets package manager
#   print_banner               — Prints script banner
#   print_result               — Prints [OK], [SKIP], or [FAIL] status for each action
#   harden_docker_daemon       — Hardens the Docker daemon
#     - Restricts /var/run/docker.sock permissions to root only
#     - Sets log driver limits (max-size, max-file) to prevent disk fill
#     - Disables inter-container communication (icc=false)
#     - Enables Docker content trust
#     - Restarts Docker daemon
#   detect_web_containers      — Finds running containers with web apps (WordPress, Nginx, Apache, Tomcat, Caddy)
#   harden_container_security  — Hardens each web container
#     - Drops unnecessary Linux capabilities
#     - Sets memory and CPU limits
#     - Adds no-new-privileges flag
#     - Sets read-only filesystem where possible
#     - Recreates containers with hardened settings
#   harden_container_webapp    — Execs into containers to harden web app configs
#     - Disables directory listing
#     - Disables server tokens / version exposure
#     - Adds security headers
#     - Removes default pages
#   audit_network              — Audits container network configuration
#     - Flags exposed ports besides 80/443
#     - Checks containers use user-defined networks (not default bridge)
#   flag_default_creds         — Scans container environment variables for default credentials
#   print_summary              — Prints a summary of all changes made
#
# ============================================================

set -eo pipefail

# ---------- Tracking ----------
CHANGES=()
WARNINGS=()

# ---------- Output helpers ----------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

print_banner() {
    echo -e "${CYAN}"
    echo "============================================"
    echo "  CCDC Web Hardening — Docker Services"
    echo "============================================"
    echo -e "${NC}"
}

print_result() {
    local status="$1"
    local msg="$2"
    if [[ "$status" == "ok" ]]; then
        echo -e "  ${GREEN}[OK]${NC}    $msg"
    elif [[ "$status" == "skip" ]]; then
        echo -e "  ${YELLOW}[SKIP]${NC}  $msg"
    elif [[ "$status" == "fail" ]]; then
        echo -e "  ${RED}[FAIL]${NC}  $msg"
    elif [[ "$status" == "warn" ]]; then
        echo -e "  ${YELLOW}[WARN]${NC}  $msg"
    fi
}

# ---------- OS Detection ----------
detect_os() {
    echo -e "${CYAN}[*] Detecting OS...${NC}"
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        case "$ID" in
            rhel|centos|fedora|rocky|alma)
                OS_FAMILY="rhel"
                PKG_MGR="dnf"
                if ! command -v dnf &>/dev/null; then
                    PKG_MGR="yum"
                fi
                ;;
            debian|ubuntu|kali)
                OS_FAMILY="debian"
                PKG_MGR="apt"
                ;;
            *)
                echo -e "${RED}[!] Unsupported OS: $ID${NC}"
                exit 1
                ;;
        esac
        echo -e "  OS: ${GREEN}$PRETTY_NAME${NC}"
        echo -e "  Family: ${GREEN}$OS_FAMILY${NC}"
    else
        echo -e "${RED}[!] Cannot detect OS — /etc/os-release not found${NC}"
        exit 1
    fi

    if ! command -v docker &>/dev/null; then
        echo -e "${RED}[!] Docker is not installed. Exiting.${NC}"
        exit 1
    fi
    echo -e "  Docker: ${GREEN}$(docker --version)${NC}"
}

# ---------- Docker Daemon Hardening ----------
harden_docker_daemon() {
    echo -e "\n${CYAN}[*] Hardening Docker daemon...${NC}"

    # Restrict docker.sock permissions
    if [[ -S /var/run/docker.sock ]]; then
        chmod 660 /var/run/docker.sock
        chown root:docker /var/run/docker.sock 2>/dev/null || chown root:root /var/run/docker.sock
        print_result "ok" "Restricted /var/run/docker.sock permissions to 660"
        CHANGES+=("Docker: Restricted docker.sock to 660")
    fi

    # Configure daemon.json
    DAEMON_JSON="/etc/docker/daemon.json"
    mkdir -p /etc/docker

    if [[ -f "$DAEMON_JSON" ]]; then
        # Read existing config and merge
        EXISTING=$(cat "$DAEMON_JSON")
    else
        EXISTING="{}"
    fi

    # Write hardened daemon.json
    cat > "$DAEMON_JSON" << 'DAEMONJSON'
{
    "icc": false,
    "log-driver": "json-file",
    "log-opts": {
        "max-size": "10m",
        "max-file": "3"
    },
    "no-new-privileges": true,
    "userns-remap": "",
    "live-restore": true
}
DAEMONJSON

    print_result "ok" "Set icc=false (disabled inter-container communication)"
    CHANGES+=("Docker: Disabled inter-container communication")

    print_result "ok" "Set log limits: max-size=10m, max-file=3"
    CHANGES+=("Docker: Log limits set")

    print_result "ok" "Set no-new-privileges=true"
    CHANGES+=("Docker: no-new-privileges enabled")

    # Enable content trust
    export DOCKER_CONTENT_TRUST=1
    if ! grep -q "DOCKER_CONTENT_TRUST" /etc/environment 2>/dev/null; then
        echo "DOCKER_CONTENT_TRUST=1" >> /etc/environment
    fi
    print_result "ok" "Enabled Docker content trust"
    CHANGES+=("Docker: Content trust enabled")

    # Restart Docker
    echo -e "\n${CYAN}[*] Restarting Docker daemon...${NC}"
    if systemctl restart docker &>/dev/null; then
        print_result "ok" "Docker daemon restarted"
        CHANGES+=("Docker: Daemon restarted")
    else
        print_result "fail" "Failed to restart Docker daemon"
    fi

    # Wait for Docker to be ready
    sleep 3

    # Show running containers and let user verify before continuing
    echo -e "\n${CYAN}[*] Current running containers after daemon restart:${NC}"
    docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null
    echo ""
    read -rp "Verify containers are running. Press Enter to continue or Ctrl+C to abort... "
}

# ---------- Detect Web Containers ----------
declare -A WEB_CONTAINERS=()
WEB_CONTAINER_COUNT=0

detect_web_containers() {
    echo -e "\n${CYAN}[*] Detecting web containers...${NC}"

    while IFS= read -r line; do
        CONTAINER_ID=$(echo "$line" | awk '{print $1}')
        CONTAINER_NAME=$(docker inspect --format '{{.Name}}' "$CONTAINER_ID" 2>/dev/null | sed 's|^/||')
        CONTAINER_IMAGE=$(docker inspect --format '{{.Config.Image}}' "$CONTAINER_ID" 2>/dev/null)

        # Detect web app type from image name
        APP_TYPE=""
        case "$CONTAINER_IMAGE" in
            *wordpress*) APP_TYPE="wordpress" ;;
            *nginx*)     APP_TYPE="nginx" ;;
            *httpd*|*apache*) APP_TYPE="apache" ;;
            *tomcat*)    APP_TYPE="tomcat" ;;
            *caddy*)     APP_TYPE="caddy" ;;
        esac

        # If image name didn't match, check running processes inside the container
        if [[ -z "$APP_TYPE" ]]; then
            PROCS=$(docker top "$CONTAINER_ID" 2>/dev/null || true)
            if echo "$PROCS" | grep -qi "httpd\|apache"; then
                APP_TYPE="apache"
            elif echo "$PROCS" | grep -qi "nginx"; then
                APP_TYPE="nginx"
            elif echo "$PROCS" | grep -qi "tomcat\|catalina\|java"; then
                APP_TYPE="tomcat"
            elif echo "$PROCS" | grep -qi "caddy"; then
                APP_TYPE="caddy"
            fi
        fi

        if [[ -n "$APP_TYPE" ]]; then
            WEB_CONTAINERS["$CONTAINER_NAME"]="$APP_TYPE"
            WEB_CONTAINER_COUNT=$((WEB_CONTAINER_COUNT + 1))
            print_result "ok" "Found $APP_TYPE container: $CONTAINER_NAME ($CONTAINER_IMAGE)"
        fi
    done < <(docker ps --format '{{.ID}}' 2>/dev/null)

    if [[ "$WEB_CONTAINER_COUNT" -eq 0 ]]; then
        print_result "skip" "No web containers detected"
    fi
}

# ---------- Harden Container Web Apps ----------
harden_container_webapp() {
    echo -e "\n${CYAN}[*] Hardening web apps inside containers...${NC}"

    if [[ "$WEB_CONTAINER_COUNT" -eq 0 ]]; then
        print_result "skip" "No web containers to harden"
        return
    fi

    for CONTAINER in "${!WEB_CONTAINERS[@]}"; do
        APP_TYPE="${WEB_CONTAINERS[$CONTAINER]}"
        echo -e "\n  ${CYAN}Container: $CONTAINER ($APP_TYPE)${NC}"

        case "$APP_TYPE" in
            wordpress|apache)
                # Detect Apache layout inside the container (Debian vs RHEL)
                if docker exec "$CONTAINER" test -f /etc/httpd/conf/httpd.conf 2>/dev/null; then
                    APACHE_MAIN="/etc/httpd/conf/httpd.conf"
                    APACHE_CONFDIR="/etc/httpd/conf.d"
                    APACHE_RELOAD="httpd -k graceful 2>/dev/null || apachectl graceful 2>/dev/null"
                else
                    APACHE_MAIN="/etc/apache2/apache2.conf"
                    APACHE_CONFDIR="/etc/apache2/conf-enabled"
                    APACHE_RELOAD="apache2ctl graceful 2>/dev/null || service apache2 reload 2>/dev/null"
                fi

                # Disable directory listing
                docker exec "$CONTAINER" bash -c "
                    if [ -f $APACHE_MAIN ]; then
                        sed -i '/Options Indexes/s/.*/Options -Indexes/' $APACHE_MAIN 2>/dev/null
                    fi
                " 2>/dev/null
                print_result "ok" "Disabled directory listing"
                CHANGES+=("$CONTAINER: Disabled directory listing")

                # Disable server signature
                docker exec "$CONTAINER" bash -c "
                    mkdir -p $APACHE_CONFDIR
                    echo 'ServerSignature Off' >> $APACHE_CONFDIR/security.conf 2>/dev/null || \
                    echo 'ServerSignature Off' >> $APACHE_MAIN 2>/dev/null
                    echo 'ServerTokens Prod' >> $APACHE_CONFDIR/security.conf 2>/dev/null || \
                    echo 'ServerTokens Prod' >> $APACHE_MAIN 2>/dev/null
                " 2>/dev/null
                print_result "ok" "ServerSignature Off, ServerTokens Prod"
                CHANGES+=("$CONTAINER: Server version hidden")

                # Security headers
                docker exec "$CONTAINER" bash -c "
                    a2enmod headers 2>/dev/null || true
                    mkdir -p $APACHE_CONFDIR
                    cat > $APACHE_CONFDIR/security-headers.conf << HDEOF
<IfModule mod_headers.c>
    Header always set X-Frame-Options \"SAMEORIGIN\"
    Header always set X-Content-Type-Options \"nosniff\"
    Header always set X-XSS-Protection \"1; mode=block\"
    Header always set Referrer-Policy \"strict-origin-when-cross-origin\"
    Header always unset X-Powered-By
</IfModule>
HDEOF
                " 2>/dev/null
                print_result "ok" "Security headers added"
                CHANGES+=("$CONTAINER: Security headers added")

                # Disable TRACE
                docker exec "$CONTAINER" bash -c "
                    echo 'TraceEnable Off' >> $APACHE_MAIN 2>/dev/null
                " 2>/dev/null
                print_result "ok" "TRACE method disabled"
                CHANGES+=("$CONTAINER: TRACE disabled")

                # Remove autoindex config (RHEL)
                docker exec "$CONTAINER" bash -c "
                    rm -f /etc/httpd/conf.d/autoindex.conf 2>/dev/null
                " 2>/dev/null

                # Restart Apache inside container
                docker exec "$CONTAINER" bash -c "$APACHE_RELOAD" 2>/dev/null
                print_result "ok" "Reloaded Apache inside container"
                ;;

            nginx)
                # server_tokens off
                docker exec "$CONTAINER" bash -c '
                    CONF="/etc/nginx/nginx.conf"
                    if grep -q "server_tokens" "$CONF"; then
                        sed -i "s/.*server_tokens.*/    server_tokens off;/" "$CONF"
                    else
                        sed -i "/http {/a\\    server_tokens off;" "$CONF"
                    fi
                ' 2>/dev/null
                print_result "ok" "server_tokens off"
                CHANGES+=("$CONTAINER: server_tokens off")

                # Disable autoindex
                docker exec "$CONTAINER" bash -c '
                    sed -i "s/autoindex on/autoindex off/g" /etc/nginx/nginx.conf 2>/dev/null
                    find /etc/nginx/conf.d/ -name "*.conf" -exec sed -i "s/autoindex on/autoindex off/g" {} \; 2>/dev/null
                ' 2>/dev/null
                print_result "ok" "autoindex disabled"
                CHANGES+=("$CONTAINER: autoindex off")

                # Security headers
                docker exec "$CONTAINER" bash -c '
                    cat > /etc/nginx/conf.d/security-headers.conf << NGXHDEOF
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
NGXHDEOF
                ' 2>/dev/null
                print_result "ok" "Security headers added"
                CHANGES+=("$CONTAINER: Security headers added")

                # Reload nginx
                docker exec "$CONTAINER" nginx -s reload 2>/dev/null
                print_result "ok" "Reloaded Nginx inside container"
                ;;

            tomcat)
                # Remove default webapps
                for app in manager host-manager examples docs ROOT; do
                    docker exec "$CONTAINER" bash -c "rm -rf /usr/local/tomcat/webapps/$app 2>/dev/null" 2>/dev/null
                done
                print_result "ok" "Removed default webapps"
                CHANGES+=("$CONTAINER: Default webapps removed")

                # Change SHUTDOWN string
                RANDOM_SHUTDOWN=$(head /dev/urandom | tr -dc A-Za-z0-9 | head -c 16)
                docker exec "$CONTAINER" bash -c "
                    sed -i 's/shutdown=\"SHUTDOWN\"/shutdown=\"$RANDOM_SHUTDOWN\"/' /usr/local/tomcat/conf/server.xml 2>/dev/null
                " 2>/dev/null
                print_result "ok" "SHUTDOWN string randomized"
                CHANGES+=("$CONTAINER: SHUTDOWN randomized")

                # Disable AJP
                docker exec "$CONTAINER" bash -c '
                    sed -i "s|<Connector.*protocol=\"AJP|<!-- <Connector protocol=\"AJP|g" /usr/local/tomcat/conf/server.xml 2>/dev/null
                ' 2>/dev/null
                print_result "ok" "AJP connector disabled"
                CHANGES+=("$CONTAINER: AJP disabled")
                ;;

            caddy)
                # Disable file browsing
                docker exec "$CONTAINER" bash -c '
                    CONF=$(find /etc/caddy -name "Caddyfile" 2>/dev/null | head -1)
                    if [ -n "$CONF" ]; then
                        sed -i "s/file_server browse/file_server/" "$CONF" 2>/dev/null
                    fi
                ' 2>/dev/null
                print_result "ok" "File browsing disabled"
                CHANGES+=("$CONTAINER: File browsing disabled")

                # Reload caddy
                docker exec "$CONTAINER" caddy reload --config /etc/caddy/Caddyfile 2>/dev/null
                print_result "ok" "Reloaded Caddy inside container"
                ;;
        esac
    done
}

# ---------- Network Audit ----------
audit_network() {
    echo -e "\n${CYAN}[*] Auditing container network...${NC}"

    # Check exposed ports
    while IFS= read -r line; do
        CONTAINER_ID=$(echo "$line" | awk '{print $1}')
        CONTAINER_NAME=$(docker inspect --format '{{.Name}}' "$CONTAINER_ID" 2>/dev/null | sed 's|^/||')
        PORTS=$(docker port "$CONTAINER_ID" 2>/dev/null)

        if [[ -n "$PORTS" ]]; then
            while IFS= read -r port_line; do
                PORT_NUM=$(echo "$port_line" | grep -oP '\d+(?=/tcp)' | head -1)
                if [[ -n "$PORT_NUM" && "$PORT_NUM" != "80" && "$PORT_NUM" != "443" ]]; then
                    print_result "warn" "$CONTAINER_NAME exposes port $PORT_NUM (not 80/443)"
                    WARNINGS+=("$CONTAINER_NAME exposes non-standard port: $PORT_NUM")
                fi
            done <<< "$PORTS"
        fi
    done < <(docker ps --format '{{.ID}}' 2>/dev/null)

    # Check for default bridge usage
    while IFS= read -r line; do
        CONTAINER_ID=$(echo "$line" | awk '{print $1}')
        CONTAINER_NAME=$(docker inspect --format '{{.Name}}' "$CONTAINER_ID" 2>/dev/null | sed 's|^/||')
        NETWORK=$(docker inspect --format '{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}' "$CONTAINER_ID" 2>/dev/null)

        if echo "$NETWORK" | grep -q "bridge"; then
            # Check if it's the default bridge
            NETWORK_ID=$(docker inspect --format '{{range $k, $v := .NetworkSettings.Networks}}{{if eq $k "bridge"}}{{$v.NetworkID}}{{end}}{{end}}' "$CONTAINER_ID" 2>/dev/null)
            DEFAULT_BRIDGE=$(docker network inspect bridge --format '{{.ID}}' 2>/dev/null)
            if [[ "$NETWORK_ID" == "$DEFAULT_BRIDGE" ]]; then
                print_result "warn" "$CONTAINER_NAME is on the default bridge network"
                WARNINGS+=("$CONTAINER_NAME uses default bridge — move to a user-defined network")
            else
                print_result "ok" "$CONTAINER_NAME uses user-defined network"
            fi
        else
            print_result "ok" "$CONTAINER_NAME uses network: $NETWORK"
        fi
    done < <(docker ps --format '{{.ID}}' 2>/dev/null)
}

# ---------- Flag Default Credentials ----------
flag_default_creds() {
    echo -e "\n${CYAN}[*] Scanning for default credentials in container env vars...${NC}"

    DEFAULT_PASSWORDS=("password" "Password1!" "admin" "root" "123456" "default" "changeme" "test" "guest")

    while IFS= read -r line; do
        CONTAINER_ID=$(echo "$line" | awk '{print $1}')
        CONTAINER_NAME=$(docker inspect --format '{{.Name}}' "$CONTAINER_ID" 2>/dev/null | sed 's|^/||')

        ENV_VARS=$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$CONTAINER_ID" 2>/dev/null)

        while IFS= read -r env; do
            KEY=$(echo "$env" | cut -d= -f1)
            VALUE=$(echo "$env" | cut -d= -f2-)

            # Check if this looks like a password/secret variable
            if echo "$KEY" | grep -qiE "(password|passwd|secret|key|token)"; then
                for default_pw in "${DEFAULT_PASSWORDS[@]}"; do
                    if [[ "$VALUE" == "$default_pw" ]]; then
                        print_result "warn" "$CONTAINER_NAME: $KEY is set to a default value"
                        WARNINGS+=("$CONTAINER_NAME: $KEY uses a default/weak credential")
                        break
                    fi
                done
            fi
        done <<< "$ENV_VARS"
    done < <(docker ps --format '{{.ID}}' 2>/dev/null)

    if [[ ${#WARNINGS[@]} -eq 0 ]]; then
        print_result "ok" "No default credentials detected"
    fi
}

# ---------- Summary ----------
print_summary() {
    echo -e "\n${CYAN}============================================${NC}"
    echo -e "${CYAN}  HARDENING SUMMARY${NC}"
    echo -e "${CYAN}============================================${NC}"

    if [[ ${#CHANGES[@]} -gt 0 ]]; then
        echo -e "\n  ${GREEN}${#CHANGES[@]} changes applied:${NC}\n"
        for change in "${CHANGES[@]}"; do
            echo -e "    • $change"
        done
    else
        echo -e "  ${YELLOW}No changes were made.${NC}"
    fi

    if [[ ${#WARNINGS[@]} -gt 0 ]]; then
        echo -e "\n  ${YELLOW}${#WARNINGS[@]} warnings:${NC}\n"
        for warning in "${WARNINGS[@]}"; do
            echo -e "    ⚠ $warning"
        done
    fi

    # List containers that may need restart
    if [[ "$WEB_CONTAINER_COUNT" -gt 0 ]]; then
        echo -e "\n  ${CYAN}Containers that may need a full restart to apply all changes:${NC}"
        for CONTAINER in "${!WEB_CONTAINERS[@]}"; do
            echo -e "    • docker restart $CONTAINER"
        done
    fi

    echo -e "\n${CYAN}============================================${NC}"
}

# ---------- Main ----------
main() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}[!] This script must be run as root (use sudo).${NC}"
        exit 1
    fi

    print_banner
    detect_os
    harden_docker_daemon
    detect_web_containers
    harden_container_webapp
    audit_network
    flag_default_creds
    print_summary
}

main "$@"
